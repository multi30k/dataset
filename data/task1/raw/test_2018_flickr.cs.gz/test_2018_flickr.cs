Mladý muž se účastní závodu, zatímco ten, který jej zaznamenává, se usmívá. 
Muž se škrábe vzadu na krku, zatímco hledá knihu v knihkupectví. 
Osoba s brýlemi a čepicí sáňkuje. 
Dívka v růžovém kabátě a květovaných galoších sjíždí z kopce. 
Tři dívky stojí před oknem budovy. 
dva psi si hrají se stejným klackem v tlamách
Pohled zespoda na lidi, kteří jsou zavěšeni v houpačkách na kolotoči. 
Černobílá fotografie dvou lidí, kteří se dívají na krásný obraz
Muž oblečený v černém přechází přes ulici a křičí
Dítě sedí na rušné ulici. 
15 velkých psů, kteří si hrají na oploceném dvorku u domu. 
Typický výjev z rušné ulice před červeně natřenou budovou.
Člověk venčí černého psa na vodítku, zatímco žlutý pes je na volno. 
Pes leží venku na dřevěné lavičce vedle sochy psa a žlutého tenisového míčku, který leží na zemi. 
Muž jede na kole s dítětem. 
Velký hnědý pes a malý bílý pes, kteří si hrají s létajícím talířem v tlamách. 
Čtyři děti sedí u zdi a baví se, zatímco dva dospělí muži civí do prostoru. 
Tři dívky sedí a baví se, zatímco dva chlapci pózují na fotografii. 
Domek plavčíka na písku v zamračeném dni. 
Mladá dívka, která se dívá do telefonu, zatímco chlapec za ní hledí přímo do fotoaparátu. 
Pohled z výšky na lidi, kteří jdou vedle pláže.
Pes čůrá na sochu psa v zahradě. 
Hnědý pes s konvičkou na čumáku
Afroameričan hraje na kytaru a zpívá na veřejném prostranství. 
Mladá dívka tancuje na pódiu a její modrá sukně se točí.
Obrázek čtyř žen, které tančí v šatech před skupinou lidí. 
Žena stojí na nástupiště metra a čeká na vlak. 
Dvě dívky venku v kabátech jedí zmrzlinu. 
černobílý snímek muže, který si bere noviny na ulici ve městě
Dav stojí venku a drží nahoře své telefony
Obrázek psa, který běží okolo stromu v zalesněné oblasti. 
Toto je obrázek muže a ženy, kteří jdou po pláži naproti palmám. 
Malá holčička, která drží nápis:"TENHO EM MIM TODOS OS SONHOS DO MUNDO", sedí muži na ramenou. 
Světle hnědý pes tahá za hadici od vysavače. 
Dívka a chlapec pózují na fotografii, v pozadí sedí dáma a několik lidí stojí
Dva lidé pracují na složité soše z písku ve tvaru muže. 
Černobílá fotografie chlapce uprostřed ulice
Mladá dívka v bílém kabátu tleská a zřejmě je nadšená nebo šťastná. 
Pes skáče po hračce, kterou drží žena.
Bílý pes s hnědými skvrnami hrabe packami v písku
Kočka nebo pes se snaží hrát na piano. 
dítě v klobouku s modrou krempou intenzivně pozoruje cosi skrz plot. 
Obrázek malé holčičky, která se opírá o postel svých rodičů, zatímco se na sebe dívá do zrcátka. 
Černošská dívka visí vzhůru nohama a své malé copánky tahá po zemi. 
černobílý obrázek ženy v kavárně a s odrazem auta ve výloze
Černý pes, který vychází z vody drží v tlamě hračku.
Dívky mají lízátka a pláštěnky přes kostýmy.
Muž na ulici, který drží megafon a mluví do něj
Šest dětí různých ras stojí před dřevěným plotem
Dítě je celé oblečeno v bílém a obličej má namalovaný na bílo. 
Muž ve žlutém cyklistickém tričku a slunečních brýlích jde po ulici. 
Pes odpočívá v trávě, zatímco se na něj dívá panička. 
Žena se směje a objímá svého psa, zatímco oba sedí na trávníku.
Rozmazaný snímek někoho, kdo prochází terminálem. 
Blonďaté bělošské dítě s rukama v bok
Pět bílých štěňat se choulí k sobě, jeden olizuje druhému čumák. 
Spokojené štěně na vrchu červeného vlaku.
Černý pes s nataženýma předníma nohama a se žlutým obinadlem na jedné z nich. 
Mladá dívka zavírá oči, aby si užila hudbu kytaristy na jevišti.
Černobílá fotografie ženy s kytarou doprovázené přítelem
Žena, která se dívá do svého telefonu a muž vedle ní pije z láhve. 
Černobílý obrázek tří mužů, kteří jedou na kole po ulici ve městě.
Hnědý pes nese na zádech tašku, uvnitř které je štěně
Tři mladí lidé s kytarou odpočívají na vrcholu hory
Malá dívka a starý muž dělají akrobatickou piruetu před davem lidí na ulici
světle hnědý pes se cáká ve vodě
Malý pes ve velkém výskoku, aby chytil míček
Dva muži jsou na loďce s chlapce, co sedí na přídi a drží lahev.
černobílý obrázek dívky, která visí vzhůru nohama a dává palce nahoru
Muž s bradkou, který drží kelímek, je zachycen skrze okno, zatímco muž v pozadí si čte noviny. 
Pět mladých dětí dělá rukama tvar srdce.
Velký bílý pes se snaží dostat z vody v jezeře na dřevěné molo.
Černobílý obrázek malého chlapce, který jede na velkém kole po trávě. 
Dvě mladé ženy zastavují vedle zdi, aby se podívaly na mobilní telefon.  
Dav shromážděný ve městě má deštníky a igelitová poncha, aby se ochránil před deštěm. 
Člověk, který skáče z vysokého útesu do řeky pod ním. 
Muž sjíždí na raftu peřeje na řece
Dvě děti skáčou a běží dolů z kopce.
Mladé dítě s červeným svetrem skáče na chodníku přes švihadlo. 
Člověk za okenním parapetem, který nabízí lihoviny, a osoba, která stojí před otevřeným oknem. 
Velký bílý pes stojí na dřevěném mole a dívá se na kachnu, která plavá v jezeře. 
Pes ve vodě, který má výhled na západ slunce. 
bílý pes žvýká prázdnou plastovou láhev, zatímco stojí ve vodě
Dívka sedí na trávníku vedle bílého psa. 
Dívka s neobvyklou maskou na obličeji a s dalšími lidmi za ní. 
Žena drží obličej svého psa před svým obličejem a chystá se ho políbit.
Skupina členů argentinského policejního sboru v černobílém.
Někdo skáče z velkého útesu do horského jezera. 
Malíř maluje větší verzi obrázku. 
Muž a žena se dívají na letáky nalepené na skle. 
černobílý snímek plážového domku na písku se skupinou lidí v pozadí.
Dítě, které má na sobě plavecké brýle, stojí před obchodem U-Haul. 
Stará žena v teplé bundě jí z talířku na klíně. 
Člověk začíná sestupovat po schodech v metru v cizí zemi. 
Holčička na hřišti má na sobě barevné šaty.
Člověk s roztaženýma rukama má na sobě zelenožlutý kostým papouška. 
Muž, který jde sám před kostelem. 
Muž hraje na kytaru a pije malou kávu. 
Muž, který jde dolů podchodem ve městě
Muž jde po špinavé cestě podél silnice.
Žena a její pes jdou po břehu jezera
Pár starých mužů, kteří sedí na chodníku s nějakými krabicemi a taškami. 
Skupina lidí a psů v parku. 
Dvě ženy vstupují se svým psem na dvorek
Psi na sebe skáčou na pláži vedle muže v průzračné modré vodě.
Tyto lidi se osvěžují hraním v městské fontáně. 
Skupina mladých dívek v oranžovofialových úborech, které předvádí vystoupení. 
Dva psi plavou v laguně s něčím v tlamách
Roztleskávačka v černooranžovém je vyzdvihována do vzduchu dalšími roztleskávačkami. 
Pohled ze shora na lidi, kteří jdou po dlážděném chodníku a na muže, který stojí u pestrobarevných modlitebních rohoží. 
Několik dětí sleduje, jak někdo honí po chodníku míč. 
Pes líže obličej muže, který má brýle na hlavě. 
Člověk v modročerveném oblečení stojí na písku u vody.
Mladá blonďatá žena oblečená do úboru předvádí na fotbalovém hřišti sestavu s hůlkou. 
Muž sedí na židli na břehu vody s rybářským prutem. 
Dítě s rukou nahoře má na sobě leopardí masku
Panička, která stojí, a její hnědý pes běží k ní. 
Žena se psem na vodítku na břehu rybníka. 
Hnědý pes sedí vedle muže, který se ohýbá pod vánoční stromek. 
Muž a žena sedí na lavičce v parku a dívají se na jiného muže a ženu, kteří prochází okolo. 
Světle hnědý pes na vodítku jde přes kovovou mříž uprostřed dřevěného chodníku pokrytého listy. 
Toto je obrázek dívky, která se dívá doprava a má zvednuté tři prsty.
Chlapec v klobouku sedí na jezdící hračce ve tvaru kachny. 
Žena, která fotografuje dvě ženy, v pozadí s budovou asijské architektury
Člověk oblečený v bílém motokrosovém vybavení sedí na bílé čtyřkolce a za ním je malebný výhled na hory.
Chlapec v bílé bundě stojí sám u brány.
Žena se sluchátky jde po chodníku obklopeném stromy. 
Rybář připravuje rybu za pultem s rybami určenými k prodeji. 
Žena, která vzala svého psa na procházku podél řeky v lese. 
Vestibul autobusové zastávky na městské ulici, s popraškem sněhu a lidmi, kteří jdou okolo. 
tři muži hrají na koncertě, jeden má masku koně
Žena v autobusu, která si rukou podpírá bradu a má zavřené oči. 
malá blonďatá dívka se žlutými punčochami, růžovou sukní a zeleným tričkem při skupinové aktivitě
Mladá dívka pózuje ženě, která kreslí její karikaturu. 
Černobílý výjev ženy, která sedí na lavičce u vody a drží vodítko svého psa. 
Černobílý pohled na osobu, která jde podél velké zdi
Žena v černé róbě nakupuje jídlo u stánku s ovocem a zeleninou. 
Banány a další plodiny jsou vystaveny na prodej na venkovním trhu. 
Několik turistů prochází velmi pěkným obloukem za deštivého dne. 
Policejní pes trpělivě čeká u chodníku vedle muže v gumových botách a v helmě. 
Kočka popadá člověka za nohu a kouše do ní
Osoba sedí se skříženýma rukama s krysou vedle sebe.
Malý hnědooký černý pes, ozdobený bílou santa clausovskou čepicí lemovanou kožešinou, sedí na dřevěné podlaze a hledí napravo od něj.  
Žena, která drží novorozené dítě, sedí na gauči s mužem držícím psa, který si novorozence prohlíží.  
Štěrková ulička s přerostlou trávou okolo ošuntělých budov
dva lidé jdou po ulici okolo odpadkového koše
Černobílý obrázek muže sedícího na zídce a malého chlapce stojícího vedle něj.
Černý pes s hračkou v tlamě jde ve vodě.
Černé štěně se zlatou známkou jde po otiscích pneumatik ve sněhu. 
Černobílý snímek chlapce do deseti let věku, který stojí vedle schodiště a dívá se skrz zábradlí do fotoaparátu. 
Dvě ženy sedí a muž s fotoaparátem stojí vedle nich
Dvě ženy jdou po ulici se spojenými pažemi. 
Muž klečí se skloněnou hlavou v temném pokoji osvětleném dvěma malými světly na každé straně. 
Obrázek psa, který sedí a dívá se na někoho, kdo jej fotografuje. 
Muž s kšiltovkou sedí na zemi. 
Několik lidí, kteří si prohlíží vzorky látek visící v dlouhé řadě. 
Bílý pes s hnědým obličejem sedí na cihlovém chodníku. 
Osoba se drží madla u pohyblivého chodníku. 
Člověk v kabátu a šále píše do otevřené knihy. 
Barevný pár, nejspíše v zábavním parku
Mladá žena s culíkem a v bundě stojí v metru u zdi se zkříženýma rukama. 
3 psi, dva černí boxeři a jeden malý světle hnědý pes, kteří si hrají ve sněhu. 
Hnědý pes se chystá kousnout černobílého psa. 
Pes vyskakuje, aby se podíval přes betonovou zeď. 
Buldog sedí na židli u stolu s oranžovým kávovým šálkem.
Blonďatá žena otevírá skleněné dveře obchodu. 
Člověk a černý pes sedící před televizorem. 
Muž stojí v uličce mezi řadami prázdných kostelních lavic.
Žena v květované sukni se třemi dětmi jde směrem k ženě a chlapci. 
Pes se potuluje před budovou bez vodítka. 
Žena, která má kostkovaný kabát a drží peněženku. 
Červený VW "brouk" stojí v popředí festivalu. 
Muž a tři ženy sedí na bílé lavičce, dvě z nich se baví mezi sebou. 
Žena jde s rukou okolo dítěte. 
Dva stavební dělníci, kteří se opírají o materiál a baví se. 
skupina tří mužů a jedné ženy, kteří jdou po schodech z podchodu
Muž a žena, kteří se drží za ruce. 
Skupina žen a mladých dívek na chodníku s rukou nahoře ve stylu flamenca.
Jeden člověk běží směrem ke druhému u velkého památníku. 
Dvě děti v zimním oblečení, které pózují na černobílý snímek 
Několik chodců sedí, stojí a prochází se po náměstí ve městě, v popředí je postarší muž. 
černobílý obrázek chlápka na lavičce, který pije pivo z láhve.
Mladá žena s květy ve vlasech pózuje v dlouhých červených šatech s průhlednou sukní. 
Návnada v podobě černého ptáka je zaklesnutá v pleťovém plotě.
Středně velký pták sedí na drátěném plotu pokrytým břečťanem. 
pohled shora na muže, který si čte u stolu časopis
Obrázek tří dětí s pomalovanými obličeji, které pózují na fotografii. 
Žlutý labrador se chystá zvednout vajíčko z trávy. 
Venkovní pohled na kameny, malou vodní hladinu a most v pozadí. 
dvě ženy jdou za zamračeného dusného dne po nehezké městské části.
Muž sedí a drží sportovní kočárek, ve kterém je středně velký chlupatý pes. 
Muž v tmavých šortkách, který prochází okolo jiného muže v červeném tričku. 
Dívka v džínové bundě hraje na kytaru a zpívá do mikrofonu. 
Čtyři lidé na vrchu schodiště, jede jde po schodech.
Černobílý obrázek dětí, které běží dolů po schodech před svou matkou. 
Dáma prochází okolo domu, který je částečně zastíněn. 
Malé dítě v čepici drží lopatku a někdo jej drží za ruku. 
Mladý chlapec a muž na palubě lodi venku na slunci. 
Dvě dívky, jedna s kloboukem, druhá se slunečními brýlemi. 
Černobílá fotografie muže a jeho ženy vedle auta
Žena v červeném kabátu jde po ulici vedle budovy. 
Muž stojí na konci mostu a pod velkými stromy.
Jedná se o okno v betonové zdi a muž, který prochází po druhé straně.
stará žena stojí na ulici (černobílá fotografie)
Mladý muž, který vypadá, že se nachází uprostřed vodní bitvy v bazénu. 
Tato roztomilá malá holčička se na někoho dívá, pravděpodobně na svou matku. 
Mladá dívka oděná v kabátu a čepici stojí na chodníku a za ní prochází jiní lidé. 
Malá holčička s brýlemi a v zimním oblečení, která je obklopena několika lidmi v zimních oděvech. 
Černobílý obrázek muže, který sedí u okna. 
Mladý chlapec v čepici je vedle auta ve městě
Mladý chlapec stojí vedle ulice, černobíle zabarvené. 
Černobílý pes si vytřepává vodu z kožichu. 
Muž vesluje po vodě na svém člunu se žlutými vesly.
Několik mladých dívek předvádí na jevišti taneční vystoupení. 
Muž v kabátu jde okolo červeného nápisu. 
Dítě se žlutými sluchátky pozoruje představení. 
Hnědý pes skáče do vzduchu, aby chytil žlutou hračku. 
Jedna dívka v červenočerných šatech, jiná v bílých šatech. 
skupina malých holčiček na narozeninové oslavě, jedna dívka říká něco druhé
Zápas mužského rugby, při kterém jeden muž hází s jiným
Hráč rugby v modrém běží s míčem, zatímco jej ostatní hráči obklopují. 
Žena v modrých plavkách, která si namáčí vlasy v řece
Malá holčička jí malý kousek jídla, jiná dívka má hlavu položenou na ruce a sleduje ji. 
Hráči póla pobízí své koně, aby se dostali k míči jako první.
Lidé hrají polo s pěti lidmi na koních v akci. 
Žena v modrých šatech stojí na chodníku před obchodem poblíž schodů. 
Dvě dívky v kravatách a v košilích s límečky se drží za ruce. 
Tři lidé se surfy na kraji pláže
Žena je na hoře a před sebou má krásnou pláž. 
Žena s kudrnatými vlasy v modré bundě prochází po chodníku okolo výlohy obchodu. 
Dvě ženy jdou ve městě po mokré zemi
Dva lidé stojí venku u velké bílé budovy s výhledem na město. 
muž ve vodě na malé plachetnici
Chlupatý hnědobílý pes skáče přes překážkovou dráhu. 
Pět zeber, které běží před leopardem
Špinavý jezdec ve žlutomodrém jede po trati. 
Dva lidé jedou na špinavých motorkách a skáčou do vzduchu. 
Barevný pták chytá při výskoku z vody červenou rybu.
vypadá to jako rodinná večeře, a mladý chlapec se dívá na fotografa
Žena a dva muži stojí na rohu ulice
Muž sbírá věci z ulice pro svou potřebu
Sportovec běžící v závodu plnou rychlostí
Dvě dívky a pes sedí a hrají si na kameni u řeky. 
Velmi atletická boxerka udeřuje do pytle
Chlapec ve žlutém tričku, který dělá triky na skateboardu. 
Muž čeká a dívá se, jak okolo projíždí vlak. 
Černobílá fotografie ženy, která telefonuje, a malé dívky vedle ní, na procházce ve městě. 
Skupina mužů na kolech závodí na ulici. 
Lidé jedou během závodu na kolech po silnici. 
Muž v bezpečnostní helmě, modrém tričku a s černým batohem, jede na kole skrze vzrostlou vegetaci v oblasti zalesněné bílými břízami. 
Muž a dvě malé děti, kteří se baví na pláži, na vodě je několik plachetnic. 
Vydra plave ve vodě a všude okolo jsou bublinky.
Tři lidé, kteří se drží, zatímco jedou po jezeře na nafukovací duši. 
Dívka v puntíkovaném tričku, která si hraje ve vodní spršce. 
lidé jedou na kole po větrné silnici vedle hory.
Pohled zespodu na cyklistu, který projíždí zatáčkou. 
Dvě ženy, které sedí u stolku v kavárně na kraji chodníku, se smějí, jedna pije ledovou kávu a druhá se dívá do svého telefonu. 
Pohled na nádherného ptáka ve volném pádu
Muž s bílou helmou jede po trati ve starém závodním autě. 
Muž skáče vajíčkem do vody. 
Stará fotografie, která zachycuje lidi sedící na kraji ulice
Žena v černých kalhotách a tričku pózuje. 
Cyklista na kole s cyklistickou výbavou jede po silnici podle žluté čáry.
Žena vyskočí do vzduchu, zatímco skupina dalších dívek za ní tancuje. 
Žena ve žlutém vršku a v černých šortkách surfuje na bílém prkně po vysoké vlně.
Cyklisté se účastní nějakého závodu v parku s několika vysokými městskými budovami v pozadí. 
Několik raftů plně naložených lidmi proplouvá úzkým místem na řece.
Čtyři cyklisté jedou v řadě. 
Tři cyklisté projíždí po pěšině skrze svěží zelený les. 
Mladý muž kolem sebe cáká vodu během toho co na svém surfu chytá vlnu.
nadhazovač Jays se chystá nadhodit míček pálkaři.
pes skáče s otevřenou hubou přes překážku na veletrhu, zatímco jej sledují lidé. 
Pohled ve výšce očí na dívky, které se drží za ruce v kroužku. 
Malý chlapec pózuje na schodech na fotografii
Muž z Uruguaye, který běží parkem, je součástí závodu nebo maratonu. 
Obrázek kapely na pódiu, která vystupuje před publikem. 
dívka skáče ze surfu do oceánu.
Cyklistický závod v ulici města ve vedení s mužem v červeném dresu, který projíždí zatáčkou. 
žena v bikinách surfuje za slunného dne
závodnice hrají zápas venkovního hokeje
Fotbalista se snaží dostat míč pod kontrolu, zatímco obránce se jej snaží získat. 
Tento surfař se snaží vyvarovat pádu. 
Muž přikrčený ve  vodě na surfovém prkně, zatímco jede na vlně. 
Muž v zeleném tričku drží dítě na hladině. 
Surfař skáče na vlnách.
Fotbalisté hrají školní zápas ve zlatomodrých dresech proti bíločerným. 
Člověk přistává s padákem na zem. 
Větrné mlýny, které jsou rozsvíceny na tmavé cestě. 
Černoška oblečená v bílém, která bojuje s běloškou oblečenou v modrém. 
Dva fotbaloví hráči v rozdílných dresech bojují o míč
Pohled zespodu na dva cyklisty, kteří závodí v zatáčce. 
Šest mužů, kteří jedou v řadě na kolech. 
Dva cyklisté na kolech, jeden má na sobě červené tričko a helmu, druhý má zelené tričko a helmu.
Muž, který řídí zelené závodní auto označené číslem 5
Dívky, které hrají volejbal, oslavují, zatímco je povzbuzují fanoušci. 
fotbalový zápas, hráč v červeném se chystá sebrat míč hráči v zeleném. 
Fotbalista dělá rychlý pohyb proti svému soupeři. 
Dvě mladé ženy z konkurenčních týmů hrají pozemní hokej. 
Fotbalista v šedém úspěšně vystřelil na branku při hře. 
Obrázek muže, který při baseballu odpaluje pálkou, zatímco jej pozorují lidé. 
Chlapec a japonská dívka jedou v autobuse s taškami na klíně. 
Krásný ohňostroj uprostřed noci, s věží vzadu. 
Skupina kluků s kamerami a rukama ve vzduchu. 
mladý muž skáče na rampě na koloběžce
muž na horském kole
Dívky v černých úborech tancují na pódiu.
Muž vychází z jeskyně na pláž. 
Muž běží do vln oceánu se surfovým prknem. 
Skupina mužů v plavkách se dívá na vodu a na kameny. 
Pták letí z vody s rybou v zobáku.
Oranžovobílý starý model dodávky volkswagen na silnici, který je plný lidí
Muž začíná baseballový zápas nadhozem před mnoha diváky.
Černobílá fotografie muže, který jde po pláži s balonem
Člověk na černožlutém vodním skútru, s loděmi v pozadí. 
Několik dětí se shlukuje okolo muže, který natírá zeď.
Modrozelená rozbouřená voda s černočerveným motorovým člunem v pozadí a červenou bójkou.
Tři lidé hrají fotbal, dva ve fialovém, další, který drží míč, je v bílém. 
Toto je obrázek dvou kolibříků sedících na vrcholu květiny.
Velký člun pluje po hladině, v pozadí jsou přepravní kontejnery a stromy. 
Muž stojí s nohou na zábradlí a dívá se na vodu. 
Mladý člověk předvádí za slunečného dne na svém kole BMX kousek na BMX dráze.
Velký černý kůň stojí před dvěma kyblíky. 
Pes běží na břehu pláže
Fotbalista v červeném hází míč, zatímco jiný hráč běží směrem k němu. 
Žena oblečená ve starodávných šatech sedí u stolu s knihou v pokoji se žlutou tapetou.
Skupina lidí si rozjímá při západu slunce.
muž v tlustém ochranném oblečení stojí nad psem
obrácený obraz chlápka jedoucího na kole jehož odraz však vypadá jako normální osoba jedoucí na kole.
lodě na vodě s městem v pozadí
Mladý chlapec v modré košili vykukuje z otevřeného okna modrobílého autobusu. 
Muž v džínách a černém kovbojském klobouku sprintuje směrem k budově.  
Obrázek muže, který sedí na koni a drží se jej, zatímco vyhazuje a skáče. 
Dva hráči ve žlutých dresech hrají se dvěma hráči v bílých dresech. 
Toto je černobílý obrázek člověka na kole, který jede nahoru do kopce. 
Turistická stezka na venkově, na kterou mají koně zákaz vstupu. 
Nohy mužů během závodu v botách různých barev. 
Pár žen, které hrají plážový volejbal
Chlapec v ochranném oblečení provádí výskok na kole na prašné trati. 
Dívka z východu, která drží podložku na kreslení, se dívá do dálky. 
Mladý muž surfuje a za ním je velký proud vody. 
Písek na pláži a malé městečko v dálce. 
Návštěvníci koncertu si užívají představení, v jehož pozadí jsou ohňostroje. 
Cyklista jede po travnaté zabahněné cestě.
Surfař jede po vlně podél mola. 
Skupina dívek, které proti sobě hrají volejbal. 
Stíny muže tlačícího kočárek a ženy držící tašku se odráží na nedaleké zdi. 
Na dýňovém poli s vyskládanými balíky slámy je starší chlapec, co má na sobě modré tričko a sedí v malém vozíku mezi dvěma velkými dýněmi a drží těsně menšího chlapce v zeleném tričku u Moore's Pumkpins, což jsou slova napsaná na vozíku.
Muž, který bude při surfování smeten velmi velkou vlnou. 
Cyklisté se sjíždějí, když závodí před fanoušky. 
dav sleduje cyklistický závod a velká norská vlajka plápolá
Tři závodní auta na dráze, jedno je červené, dvě černé. 
Roh ulice a zaparkovaná auta viděna skrze temnou uličku. 
Horské jezero za jasného podzimního dne.
Muž v černém tričku leze na veliký kámen, zatímco jej muž v zeleném tričku jistí. 
Věž majáku z červených cihel.
Zelené dveře, které jsou na konci kamenného schodiště. 
Dvě ženy oslavují volejbalový zápas
Bíločerný skvrnitý pes skáče přes plevel. 
Chlápek a dívka sedí u stolu a pracují na počítačích. 
Spousta koček, které leží před obchodem na schodech a na dlážděném chodníku.
Dva cyklisté a auto jedou po strmé klikatící se silnici obklopené podzimními barvami. 
Volejbalistka Univerzity v Jižním Oregonu, která se chystá odpálit míč během hry. 
Pohled zespoda na velkou elektrickou věž proti oblačné obloze.
Obrázek pěšiny pokryté listím, se stromy nalevo a poli na obou stranách, na podzim. 
Pták se koupe ve staré keramické misce. 
Veliká kapela a její roztleskávačky dělají představení pro svůj tým
Dvě pavoučí sítě na nové dřevěné stavbě.
Žena s červenou taškou sedí naproti jiné ženě s květovanou taškou. 
Tři houby obklopené zeleným břečťanem.
černobílý snímek lidí u venkovních kulatých stolů
Otisk zvířecí tlapky ve sněhu. 
Tři muži jedou na kolech.
Dva fotbalové týmy, které spolu zápasí na hřišti, polovina ve fialových dresech, polovina v bílých.
Roztomilý malý ptáček na větvi stromu
Malé chlupaté zvíře vykukuje zpoza větve stromu. 
Žena, která sedí sama u stolu s tácem jídla, se dívá na něco dolů. 
Přehrada nad malou řekou s nedalekou budovou.
Kolibřík sosá z květiny, zatímco se vznáší ve vzduchu. 
Žena a pes běží přes překážkovou dráhu 
kaskádovitá řeka protínající horu pokrytou borovicemi
Nádherná fotografie vodní hladiny obklopené sněhem 
Několik stanů na poli za hvězdné noci
Člověk nesoucí kyblík prochází vodou. 
Mladá žena nese v ruce bundu a jde po ulici
Pes na chodníku se dívá do fotoaparátu, muž před obchodem píše na tabuli.
Cyklisté jedou z kopce, nad nimi se smráká. 
Otec a jeho syn jedou na koloběžce po silnici
Lidé jedoucí na kolech na silnici vedle půdy pokryté sněhem. 
osamělá žena, která pozoruje pobřeží 
Vyprahlá zem s velkou horou v pozadí. 
Černý pes s klackem v hubě
Los stojí na zasněženém poli nedaleko malé osady.
Dlouhý most přes řeku pod ním. 
Pták posazený na větvi, který jí červené bobule. 
Muž v dálce na sněhu se světlem svítícím na levandulově fialovou oblohu plnou hvězd a na pozadí je malý kopec.
Černobílý obrázek boudy v lesích
Lavička před domem, na kterém visí vinná réva. 
pohled turisty, který se ohlíží zpět na cestu, dívá se na zasněženou krajinu s krásnými jehličnatými stromy.
Dělníci se pokouší vyvěsit neonový nápis. 
Tři lidi sedí v baru a vypadají smutně nebo unaveně. 
Tři lidé na obloze zavěšeni na tenkých drátech. 
Pohled na hornatou krajinu pokrytou sněhem a velký dům s modrou střechou
Muž sedí sám u stolu a dívá se na své účtenky.  
Kamenný oblouk s cestou pod ním a lesem na druhé straně
Obrázek bílé vody v řece, domu v pozadí a vlaku projíždějícího po mostě na kopci. 
Baseballový nadhazovač v zelenobílém dresu nadhazuje míček
Muž jede na koni a vede zástup oslů skalnatou oblastí. 
zlaté listy padají ze stromu na chodník
Muž hraje na piano, zatímco lidé procházejí v pozadí. 
Malý strom, který roste z praskliny ve skále. 
Vozidlo, které řídí muž v červeném tričku, jede přes chudě vypadající oblast. 
Pohled na lidi u stolu a budovu s velkým neonovým poutačem v pozadí. 
Muž se skvělým hárem sám se sebou oslavuje.
Velký zápasník se chystá něčím udeřit svého protivníka.
Dva muži v boxerském ringu, kteří se účastní jakéhosi bojového umění. 
Roztomilý chlapec s čepicí, který se kouká z okna
Pohled na přístav se dvěma loděmi, několika budovami a stromy v dálce. 
Černý pes sedí na sedadle spolujezdce a dívá se z okna. 
Několik lidí, kteří šplhají po zasněženém horském průsmyku. 
Fotografie krásného západu slunce nad mraky obklopených domy
Opuštěná cesta uprostřed pustiny
Pohled zblízka na profil hlavy kolibříka. 
Lidé se vznáší na obloze při západu slunce. 
Lyžař vystupuje po zasněženém kopci. 
Blesk, který v noci udeří doprostřed malé vísky. 
Člověk lyžuje dolů ze strmého kopce obklopeného vysokými stromy. 
Dva bílé čluny stojí na vodní hladině.
Jeden člověk vypadá, že vaří na grilu za bosým mužem, co si povídá a používá tablet na skalní římse za úsvitu, boty a batohy jsou za nimi a mezi nimi je žlutá karimatka.
Pes vchází do zasněžené uličky plné odpadků.
Lyžařka v jasně oranžové bundě jede ze strmé sjezdovky.
Dívčí basketbalový tým se pokouší získat míč svého soupeře. 
Surfař stříká vodu zatímco chytá ve výskoku vlnu.
Muž nese krabice do místnosti, zatímco chlapec zametá ulici. 
Člověk v oranžové bundě leze nahoru do horského kopce. 
Pohled na červenou střechu domu
Odletuje sníh, když lyžař přejíždí vrchol kopce.
Žena v černém lyžařském oblečení jede dolů z kopce. 
Černý a bílý na pláži vedle holčičky a jejího otce.
Letadlo za sebou zanechává dlouhou stopu hned pod měsícem na temně modré obloze. 
Černý pes stojí na zadních, přední tlapy mu drží člověk. 
Skupina mnoha cyklistů, kteří jedou v parku. 
Hnědý pes drží v tlamě fotbalový míč a jde po sněhu. 
Muž v kovbojském klobouku stojí před vývěskou, 
Dva zápasníci uprostřed zápasu v modrobílé aréně. 
Muž rybaří na břehu řeky obklopen spoustou zelených travin
Skupina kovbojů, kteří vedou ulicí dlouhorohé býky.
Člověk sedící na kamenném mole vedle rozlehlé vodní hladiny.
Lidé, kteří běží ve sněhu, a sněhové koule téměř zasáhla muže s fotoaparátem. 
Zástup lidí na sněhu, muž v zelené bundě hází sněhovou kouli. 
Žena předvádí, jak se používá nástěnný postroj, zatímco ji pozorují dva muži a teenager. 
Nádherná fotografie, na které můžeme vidět lavičku a hory v pozadí
fotografie žokejů, kteří závodí na venkovní dostihové dráze
Lidé se prochází po pláži, zatímco slunce zapadá nad vodou. 
Pohled na několik budov se skleněnými okny
Dáma v černých plavkách, která je na pláži se dvěma psy. 
Několik lidí běží ze studené vody.
Žena jde po chodníku ve městě se svým telefonem v ruce
Muž, který se dívá do svého telefonu na schodech ve stanici metra. 
Koně a žokejové běží závod okolo dostihové dráhy. 
Silnice, která vede krajinou s trávou a stromy, za mírně zataženého dne. 
dva psi, hnědý a černý, si hrají a hnědý pes sedí na černém. 
Žena stojí na jedné noze v písku na pláži a před ní stojí muž. 
kluk na skateboardu ve městě, který jede po zábradlí u schodů
Brankář skáče po hlavě po vystřeleném puku, zatímco dva hráči vedle něj zápasí. 
Skupina cyklistů, kteří jedou po silnici obklopené zasněženými poli a horami. 
Postarší žena a pes se prochází po pláži. 
Výjev prázdné ulice vedoucí do centra města. 
Dva velké kamiony na silnici jedou do cíle
Vysoké tenké zelené stromy obklopují dřevěný plot okolo téměř bílého zamrzlého jezera. 
Starobylý kamenný maják stojí na skalnatém pobřeží. 
Malý černobílý pes si hraje ve sněhu. 
Člověk jede na surfovém prkně, na kterém je připevněna plachta. 
Žena a dívka sedí na dvou židlích, jedné zelené a jedné červené
Osamělý lyžař jede z kopce mezi stromy. 
Malý pes si hraje na trávě s prázdnou plastovou láhví 
Žena se pokouší hodit basketbalový míč, zatímco ji pozoruje týmový maskot. 
Jezero s kamenitou cestou podél břehu, se stromy a pohořím v pozadí
Černobílý noční snímek lidí, kteří se prochází s deštníky po pěší zóně ve městě. 
Mladý muž se zastaví, aby zkontroloval svůj mobilní telefon, stejně tak jako žena v pozadí. 
Žena sedí na bílé lavičce, zatímco někdo na kole jede okolo ní. 
muž na trávníku uprostřed výskoku přes modrou pásku
Člověk, který se dívá na tři obrazy, na jednom je květinová kytice a na dalších dvou dívky. 
Šedý obrázek malé holčičky, která běží podél plotu směrem ke skupině lidí v dálce
Osamocený divnotvarý strom přežívá v nížině mezi dvěma kopci.
Světle hnědý pes běží skrze červenou zahnutou rouru. 
Muži v modrých a bílých dresech hrají basketbal. 
Malá holčička, která má růžovou sukni, je na kamenitém povrchu a v pozadí je vodní hladina.
Někdo s párem lyží letí vzduchem. 
Muž, který má na sobě oranžovou čepici a kalhoty a zelenou bundu, snowboarduje dolů ze zasněženého kopce. 
Chatka v lese se sněhem na střeše
Dvě ženy spolu zápasí na žíněnce. 
Žena hází bowlingovou kouli na bowlingovou dráhu. 
Starý hrad s vysokými zdmi a mostem uprostřed věží 
Suchý strom u jezera při západu slunce.
Tři fotografové viděni skrze objektiv dalšího fotografa. 
Muž na motocyklu sleduje auto, které se noří do vody
Strom stojí v popředí malebného obrazu, který zachycuje zasněžené jezero a hory za polojasného dne. 
Dvě ženy se drží za ruce a jdou ve vodě. 
Skupina domů, které jsou postaveny na břehu vody.
Usmívající se mladá žena s ochrannou helmou, tričkem a sportovními kalhotami, jede na kole po kamenité cestě, ohraničené stromy a keři, vedle velkého černého psa, který jde po cestě s vyplazeným jazykem. 
Mladý baseballista odpaluje na hřišti.
Osamělý lyžař klikatě sjezduje ze zasněžené hory. 
Na fotografii je malý stůl a šest krásných modrých židlí. 
Mladé děti s makeupem klauna a červenými nosy
Kola zaparkovaná na chodníku, zatímco vozidla parkují na silnici. 
černobílý obrázek lidí, kteří se koupou ve vodě a za nimi je vodopád. 
Týmy hrají na hřišti zápas rugby
Nevěsta hází kytici skupině žen za ní. 
Cyklista ujíždí od skupiny na dlouhé úseku silnice. 
Několik lidí zastavuje, aby se podívali na portrét v umělecké galerii. 
Bílé labutě plují na velkém jezeře.
Odpalovač skáče na metu, zatímco zatímco za ním pospíchá další hráč.
Vysoké hory vedle dobře udržované silnice. 
několik elektrických drátů nebo vozík na překonání řeky s velkými kameny po stranách.
Malý potok ve sněhu uprostřed dvou velkých skal
Žena čeká na vyhození míčku při baseballu
Skalnatá římsa vyčnívající nad vodu. 
Ulice je plná lidí a aut. 
Červenomodré ruské kolo před věží s hodinami.
Vypadá to, že spřežení clydesdalských koní táhne červený vůz se dvěma muži v bílých košilích a zelených čepicích a kalhotách. 
Chlapec skateboarduje na betonu na otevřeném prostranství ve městě s divadlem v pozadí. 
Tři kachny v řadě plavou ve vodě. 
Krásný les obklopený borovicemi a spoustou sněhu
Žena s tetováním na břiše ukazuje své břicho buldokovi. 
Pár leží pod malým stromem, zatímco ostatní sedí nebo chodí okolo. 
Dva lakrosoví hráči hrají zápas.
Tři muži ve sportovním oděvu běží po překážkové dráze
Roztleskávačka na basketbalovém hřišti uprostřed salta vzad. 
Lyžař projíždí okolo stop několika dalších lyžařů, kteří se vydali po sjezdovce. 
Mělká vodní plocha se stálezelenými stromy na každé straně a horami v dálce. 
Výjev ze softballového zápasu, žena v červeném tričku nadhazuje jiné ženě v červeném, která chytá, osoba v modrobílém odpaluje a vrchní rozhodčí vše sleduje. 
Žena dělá výskok s roztaženýma nohama.
Mnohá auta jedou po klikatící se silnici. 
pár plyšových zvířat, medvěd a sob, přivázaných na větvi stromu
Dva muži běží po trávníku a honí fotbalový míč. 
Baseballový tým si plácá s hráčem, který přichází. 
Muž sedí na kyblíku před dodávkou. 
Malá vodní hladina obklopena stálezelenými stromy s majestátním pohořím v pozadí. 
Spousta zelených stromů a vysokých hor. 
Žena v černém kabátu odchází od davu, který se shromažďuje před vlakem. 
Západ slunce v přístavu se zakotvenými loděmi a s majákem v pozadí. 
Kovboj padá z jančícího koně, zatímco jej lidé v pozadí sledují. 
Fotografie betonové přehrady s vodou tekoucí skrz ni. 
Dva chlapci hrají fotbal, ten v červeném právě kopl do balonu. 
Muž na motocyklu uprostřed výskoku. 
Velké písečné duny se táhnou daleko ke tmavým horám v pozadí
Žena v oranžovém tričku a černých šortkách prochází po štěrkové cestě v lese.
Hráč baseballu, který má na sobě červenobílý dres Grizzly, hází míček. 
Rodiče doprovází několik dětí, které si hrají na atrakci napodobující bungee-jumping. 
Západ slunce na pláži u jezera, s jedním člunem poblíž. 
Divoká kachna plave po hladině. 
Obrázek chatky v lese za svitu hvězd a měsíce. 
Velká skupina, oblečená v černých tričkách, hraje na bubny.
Jasně modré dveře jsou vchodem do bílé budovy. 
Dvě srny vedle sochy, na které se dívá pes
Fotografie nádherné labutě uprostřed lesa
Ženy tančí v barevných sukních a šatech.
Dvě hráčky fotbalu, které se snaží kopnout do míče. 
Velký pes jde po pláži podél dřevěných kmenů, do kterých naráží vlny
Proudící řeka s modrozelenou vodou. 
Hráč kope míč jinému, zatímco jej sledují spoluhráči. 
Cesta směřující k mostu v lese.
Hokejový hráč v modrozlatém dresu odpaluje puk, zatímco zelenobílý jej pronásleduje. 
Skupina žen v černočervených svršcích předvádí choreografii na pódiu.
Dva hokejové týmy, kteří hrají na ledě zápas.
Malý ptáček sedí na větvičce vedle drátu elektrického napětí. 
Malá holčička v bílém tričku jde po štěrkové cestě. 
Muž, který jede po silnici na vysokém jízdním kole. 
Dítě v pyžamu, které si hraje na písku se svou mámou
Béžový most, který se klene přes hladinu, s velkým stálezeleným stromem v popředí. 
Malebný podzimní rybník v prostředí s modrou oblohou s řídkými mraky v pozadí
Obrázek vodní hladiny s horami a mraky v pozadí. 
Obří džungle s několika domy na konci
Červené sportovní auto s číslem 8 jede po silnici. 
Pes, který si hraje se svým míčkem uprostřed pole
Surfař surfuje na vlně na pláži
Bílý pes s černými skvrnami běží dolů z kopečka. 
tři ženy a jeden muž závodí na dráze
Chlapec v šortkách a v kšiltovce skateboarduje,
Muž v bílém tričku závodí v hlíně s autem na dálkové ovládání. 
Skupina lidí, kteří jdou v metru
Černý pes na vodítku, který se válí ve špíně.
Muž skáče do vzduchu v sedící pozici se zkříženýma nohama, aby to vypadalo, jako že sedí na hoře v pozadí. 
Můra sedí na květině uprostřed zeleného trávníku. 
Pták se koupe ve vodě a rákosu. 
Motýl sedí na tenkém zeleném listu. 
Tři hráči fotbalu uprostřed hry. 
krásná krajina s velkým lesem
Na cestě mezi stromy je vidět stín člověka. 
Lidé, kteří jedou po ulici na velmi vysokých kolech. 
Rodiče a tři malé děti na chodníku ve velkém městě.
Malý hrad na skalní římse nad hladinou vody. 
dva cyklisté jedou dolů po dlouhém schodišti
Spousta lidí, kteří sedí na trávě v parku pro veřejnost. 
Dvě vysoké věže uprostřed vodního valu
Žena v barevném tancuje se dvěma obručemi okolo ní
Muž drží meč a seká ovoce na stole. 
fotka krásných růží uprostřed leda
Siluety dvou mužů a tří žen u jezera s městem v pozadí
Děti stojí na ulici oblečeny do kostýmů tmavé barvy ve tvaru krabic. 
Člověk, který pluje na řece se silným proudem. 
deset tanečníků v maskáčích, vestách a kravatách, předvádí taneční vystoupení
pitbul a malý pes, kteří se na sebe dívají přes drátěný plot
Čtyři tanečnice, které tancují na jevišti v bílých sukních. 
Několik cyklistů přejíždí po mostě na cyklostezce přes řeku.
Modrozelené jezero v horách za jasného dne. 
Muž v červeném dresu, černých šortkách a černých legínách skáče do vzduchu pro malý míček. 
Kluk v converskách, džínách a mikině s kapucí, spí na sedadle v metru. 
Třída absolventů vyhazuje do vzduchu své klobouky uprostřed zeleného pole
Sjezdovka je pokryta sněhem a zelenými borovicemi. 
Čtyři ženy v černých trikotech tancují v kruhu. 
Pes skáče do vody, aby našel míček
Dřevěná ohrada pro hospodářská zvířata stojí uprostřed zeleného pole s řídkým porostem vysokých zelených stromů v dálce. 
Cestující jdou po nástupišti poté, co vystoupili z metra. 
Žena sedí u stolu a mračí se na muže. 
Hrad na zeleném kopci obklopený stromy. 
Lidé ve žlutém raftu plují po řece se strmými břehy pokryté zelenými stromy a s horami v dálce. 
pták s jasně žlutou náprsenkou sedí na stromě.
Muž v červeném, který hraje fotbal, míjí muže v bílém, který se jej snaží složit. 
Malebný obraz malého mostu přes mělký potok za jasného dne. 
Dívka s košíčkem v růžových holinách, která jde lesem. 
Mlha nad městem v dálce.
Muž si čte knihu a vedle má nápoj
Desítky cyklistů projíždějí okolo velké budovy na břehu jezera. 
Strom stojí na poli se západem slunce v dálce. 
Dva týmy veslařů soutěží v lodích, které jsou ozdobené plastikami draků. 
Dva mladí chlapci bez trička, kteří si hrají na trávníku se zavlažovačem. 
Banner s tvářemi dvou žen, jedna z nich má začerněný obličej. 
Bílý pták letí u stromů. 
Černoch se opírá o zeď na straně chodníku
Pes s límcem na hlavě skáče pro míček. 
Obrázek dřevěné lavičky stojící v lese. 
Veverka, která sedí na větvi stromu a škrábe se. 
Člověk, který se opaluje na velkém betonovém kvádru poblíž modré hladiny. 
Černobílá fotografie ženy, která sedí na stoličce a opírá se o budovu. 
Strom se zelenými listy a další s červenými listy a modrou oblohou v pozadí. 
Muž sedí na koni, který jí trávu. 
Dva muži sedí na lavičce a čtou si. 
Stezka pro pěší v lese u potoka. 
Mladý muž bez trička stojí na chodníku a kouří cigaretu. 
Muž oblečen do sportovního oblečení trénuje svého psa na venkovním parku pro psy. 
město v noci, které svítí uprostřed tmavých zalesněných hor
Zpěvák na koncertě s publikem, který jej povzbuzuje
Auta, která projíždí kopcovitou silnicí s horami pokrytými stromy v dálce. 
Kopcovitá krajina se stromy a trávou v popředí. 
Výhled na řeku a skalní římsu během dne. 
Výjev 2 lidí na řece v kanoi s horami v pozadí. 
Hnědobílý pes plave ve vodě s dlouhým klackem v hubě.
Stará budova na kopci vedle oceánu, která se rozpadá. 
Malá holčička, která mačká rybu, je oblečená v růžové a má modrý pruhovaný a puntíkovaný klobouk se šňůrkami. 
Nádherná krajina se vzrostlými stromy v dálce a s velkou řekou
Mladá dívka s košíčkem, která stojí v lese vedle vyvráceného stromu. 
Větší počet bílých labutí, které plavou ve vodě. 
Muž s brýlemi a batohem na vlakovém nádraží 
Jezero vedle lesa za slunného dne. 
Dívka, která hraje fotbal, sklouzla na metu, zatímco ji vyautovala jiná hráčka. 
Červený fotbalista se snaží kopnout do míče, bílý fotbalista jej blokuje. 
V zahradě se světle růžovými květinami sedí malý bílý pes, který se dívá do dálky. 
Pes běží přes dvorek s modrooranžovou hračkou v puse.
Batole ve vlněné čepičce, které se drží kovového zábradlí na vrcholu útesu s výhledem na oceán. 
Kopcovitá krajina se stromy pod zataženou oblohou.
ohniště s hořícím ohněm a za ním je jezero obklopeno borovicemi.
Skupina hudebníků hraje venku, zatímco je pozoruje dětské publikum. 
Chlapec venku žongluje s fotbalovým míčem. 
Hasičské auto je zaparkované na ulici.
Černé závodní auto s číslem 28 na trati
sluneční paprsky prosvítají skrz borovicový les, v pozadí je mýtina, malé jezírko a piknikový stůl.  
Muž si fotí ženu, která pózuje u vody. 
Obrázek piknikového prostředí se skládací kempingovou židlí pokrytou červenou látkou s potiskem Kanady. 
Muž drží létající talíř a černobílý pes jej přeskakuje. 
Děti stojí a mají na hlavách bílé masky, na kterých jsou připevněny barevné stužky. 
Čtyři drsní fotbalisté na fotbalovém hřišti, kteří se navzájem sráží, jeden padá zády na zem. 
Černobílý pes s létajícím talířem v hubě skáče přes mužova záda.
Žena se dvěma malými psy, jedním úplně mokrým, sedí v červeném kajaku. 
Dva velcí černí psi běží přes travnatý dvorek. 
3 stará závodní auta v  záběru, ale pozadí je rozostřené. 
Tři lidé stojí na okraji útesu a dívají se dolů na vodu. 
Vlak s otevřenou zadní částí na kolejích ve venkovském prostředí. 
nádherný kontrast dvou barev horniny, bílé nalevo a načervenalého pískovce napravo
Závodní auto, ze kterého se kouří, a směřuje ke srážce.
Obrázek velkého psa, který stojí na několika dřevěných schodech. 
Muž, který pracuje na chodníku s pilou, způsobuje jiskření. 
Velké bílé betonové schody se stromy okolo a smutným mužem, který sedí s hlavou v dlaních. 
Pohled na lehce zřícenou stavbu z písku 
Žena na břehu vody, která drží červený pruhovaný ručník. 
Dva lidé zápasí v bahně, několik lidí v pozadí se tím baví
Nějací muži hrají frisbee, zatímco jeden z nich skáče do vzduchu. 
Kluk skáče podél chodníku, zatímco jdou chodci okolo.
Kaňon s několika stromy na úpatí
Barevné potápěčské ploutve vyrovnané na kamenitém břehu pláže.
Velký motýl odpočívá na kleci plné kousků melounu. 
Bruslař ve fialovém předvádí trik blízko ledu. 
jezevec stojí na trávě na pařezu
Had maskovaný na kamenité zemi
Žena kráčí bosa po rozlehlé písčité půdě. 
Fotografie zblízka, která zachycuje velikou včelu na zeleném listu 
Žena zabalená do kožichu odpočívá ve sněhu. 
Dva mladí muži v barevných plavkách, kteří se drží gumového raftu, protože jsou taženi člunem. 
Mořský pták letí nad hladinou, v pozadí je molo.
Skupina cyklistů jedoucích po horské cestě.
Mladá dívka, oblečená převážně v růžovém, sedí neslušně na soše v parku za polojasného dne. 
Fotka nádherného západu slunce nad palmami
Záběr zblízka na tečkovaného motýla na zeleném listu. 
Fotograf s batohem na zádech je připraven udělat snímek. 
Tygr sleduje svou kořist ve vyprahlé krajině. 
Mladý muž předvádí triky na skateboardu na ulici ve městě
Žena poté, co nadhodila míček jiné ženě, které jej odpaluje. 
Obrázek srnce v poli, který se na někoho dívá. 
Vodopád proudí do potoka uprostřed lesa.
Německý ovčák jde po poli v přírodě
Obrázek dívky, která jede na koni před davem lidí. 
Muž s knírem sedí u betonové zdi. 
Žena a její děti stojí na chodníku, když je fotí.
Atletka skáče na závodišti do vzduchu. 
Středně velký bílý kůň stojí na skalní římse s výhledem na pole či prérie. 
Obrázek skupiny tanečníků, kteří vystupují na pódiu. 
Na břehu vody je přístaviště s mnoha kajaky. 
Auto letí ve vzduchu během jízdy po prachové cestě.
Skupina dívek, které tleskají a tančí, zatímco je pozorují lidé sedící u stolu. 
Socha muže na koni na ranči
Dítě sedí u stolu v restauraci a jí z talíře.
Fotografie muže se svým povozem a s roztomilou chatkou v pozadí
Člověk v šedivých šortkách se kutálí do bláta.
Několik lidí a hnědý pes, kteří se radují z vody a písečné pláže. 
sup pózuje na vrchu větve mrtvého stromu a roztahuje křídla a za ním je modrá obloha.
Dva lidé jdou po cestě podél strmých kopců.
Kajakáři závodí na řece mezi oranžovými míči.
Chlapec v kajaku pádluje na rychle se pohybující vodě poblíž oranžového balonu. 
Jelen stojí venku na travnatém území. 
Žena a její tři děti jdou po cihlovém chodníku před budovou. 
Muž s plnovousem sedí na schodu před budovou. 
Muž a žena při konverzaci v kavárně. 
Dva vodní lyžaři s padáky na vodě.
Čtyři cyklisté přejíždí během závodu přes koleje. 
Srnec stojí v trávě vedle značky slepé ulice. 
Několik lidí v kajacích, kteří jedou zrádným úsekem bílého vodního toku. 
žena v neoprenu v zeleném kajaku na řece
Černobílá fotka cesty v lese.
noční snímek hvězdné oblohy s kameny v popředí
Žena sedí u zdi s hrníčkem mezi nohama. 
stíny vysokých stromů na modré obloze a řídké mraky při východu slunce
Několik dětí předvádí při hodině taneční choreografii
Vodopád s velkými skalami vedle něj
Kůň skáče přes zábradlí při soutěži ve skocích. 
Dva muži běží po fotbalovém hřišti.
Zpěvačka si odhazuje vlasy dozadu, zatímco za ní na pódiu stojí kytarista. 
Dvojitá duha nad zelenou pastvinou. 
Jezdec na koni skáče přes překážku na trati
Divoké květiny kvetou u jezera, s horou v dálce. 
Bílý pes a blonďatá paní si hrají v bazénu. 
Fotka s efektem sépie, na které jsou zasněžené hory a lidé, co prochází.
Tohle je obrázek venkovní scény s horou v pozadí a několika stromy a lavičkou v popředí.
Ještěrka pluje kolem větví a řas. 
Starý modrý náklaďák zaparkovaný u starobylého čerpacího stojanu. 
Modrá obloha a hnědé hory zdobí přírodní krajinu
Loď uprostřed velkého jezera obklopeného lesy.
Motokrosový jezdec, na kterého je zaostřeno,  předvádí letecký kousek. 
Skupina mužů hraje baseball před publikem.
Skupina dětí a žena stojí s rukama zvednutýma do vzduchu. 
Skupina cyklistů závodí ze strmého kopce. 
Černobílá fotka úbočí kopce.
Muž s pruhovanou helmou padá z motorky. 
Skupina lidí na sportovní akci drží malé deštníky. 
skupina mužů, kteří jdou s obtěžkaným koněm po cestě lemované stromy. 
sopka nebo kráter s kupou sněhu vevnitř a na pozadí je jezero.
Pastvinová brána leží na prašné cestě. 
Černobílá fotografie rušného venkovního prostoru s procházejícími lidmi a ženami, které se usmívají. 
Spousta polen byla umělecky rozestavěna.
Malá budka s otevřenými dveřmi na dvoře domu
starý dřevěný most s horou pokrytou borovicemi za ním.
Přívoz čeká u dlouhého mola, s městem v pozadí, při západu slunce. 
Bílý kůň stojí před červenou chatou
Tábořiště a auto z jiné doby uprostřed ničeho. 
Obrázek černé kočky, která sedí na vrchu klády a škrábe se.
Povoz stojí na dvoře, okolo si hrají děti a v dálce je červená stodola. 
Osamělý povoz, který je zaparkován na trávníku u stodoly.
muž v černém oblečení předvádí trik na skateboardu podél betonové zdi
Člověk stojí na dřevěném mostě přes řeku 
Obraz lesa v pozadí a jezera v popředí. 
Fotografie muže s velkým vousem. 
Žena ve výskoku uprostřed ulice obklopené budovami. 
Malý chlapec a holčička, kteří si hrají venku, drží mezi sebou provaz. 
Dva staří muži, kteří se spolu smějí, zatímco sedí na nějakých schodech. 
Muž, který sedí jinému muži na ramenou uprostřed moře lidí. 
Muži ve vagonu metra.
Paraglidista za sebou zanechává spršku vody, když se zvedá z hladiny.  
Postarší muž hraje na strunný nástroj a je zobrazen černobíle. 
Žlutý pes běží po trávníku, na kterém je míč. 
Švýcarské letadlo se připravuje na vzlet pod růžovou oblohou. 
Fotografie, na které jsou zachyceny oválné dráty
Několik lidí v kiltech na zeleném poli hraje na dudy.
Žena, která drží nějaké knihy, stojí před starou budovou určenou k demolici. 
Skupina mužů při závodu v kanoích
pár nohou se dvěma páry bot na obou stranách.
Tramvaj číslo 2, která přepravuje lidi po dlouhých schodech. 
Pohled zblízka na kytaru se strunami
Člověk v šedém tričku jede na surfovém prkně.  
Pes na ulici na ručníku vedle motorky
Muž v červeném tričku jede na skateboardu po zábradlí. 
Sněžná sova sedí na větvi a zírá do dálky. 
Žena u svého stánku se sladkostmi, který nabízí jahody v čokoládě, zatímco si lidé prohlíží její zboží. 
Stará žena oblečená do kožené bundy a do oblečení pro mnohem mladší osobu.  
Muž stojí uprostřed kamenité cesty
Lidé jdou chodbou vedle metra.
Žena a černý pes na surfovém prkně pádlují v bazénu s modrou vodou a poblíž nich plave malý chlapec. 
Detail včely na růžových květech. 
Hodiny v popředí ukazují 6:51, zatímco pozadí zaplňuje vysoký mrakodrap. 
Tropická pláž s kameny, pískem a vlnami.
Obrázek řeky a budovy, která vypadá jako čínská. 
Krásný západ slunce na moři s mostem v pozadí 
Jeden muž, který chytá míček a další, v červeném, ve skluzu na metu.
Muž a žena sedí společně na zelené lavičce v parku. 
Černý pes vylézá z bazénu
Hnědá ještěrka sedí na suchém listí. 
Lidé, kteří jdou po chodníku vedle pláže, 
Muž s černou taškou jde bosý přes rybníček ve městě. 
velké bouřkové mraky, ze kterých prší a mezi nimi malá duha nad rozlehlými pláněmi 
Žena s růžovou helmou a batohem jede na kole po městě
Muži hrají na hřišti fotbal
Motýl se posadil na několika malinách.
Muž si utírá nos, když se dívá do výlohy obchodu. 
Skalní útes v poušti za několika zelenými stromy. 
Nákladní vůz s vybavením zaparkovaným před oficiálně vypadající budovou. 
Fotbalista s číslem 8 chytá míč a fotbalista s číslem 44 se jej snaží ubránit. 
Dívka v modrém vršku a černých kalhotách sedí na schodech. 
Dva mladí muži prochází lesem po kamenité cestě. 
Černobílá fotografie mostu přes vodu v husté mlze.
řada bílých a červených domů s trojúhelníkovou střechou, které se nachází poblíž venkovního prostoru se židlemi a stoly
Palmy před vodní hladinou a ruská kola v pozadí. 
Žena s batohem jí v restauraci zmrzlinový pohár. 
Noční pohled na město na břehu řeky
Muž v červeném saku fouká na závodní dráze do trubky.
Žongléři jsou zaneprázdněni házením kuželek jeden druhému. 
Skupina malých dětí, které se smějí a tancují. 
Ruka drží bílý květináč, ve kterém roste rostlina.  
Chobotnice v tašce v bílé krabici. 
Tři lidé na špinavých kolech jedou bahnitou tratí a způsobují, že bahno létá na fotografa. 
Pohled z přední sedačky auta, které jede po zahnuté silnici při západu slunce. 
Husté stromy uprostřed zamlžené vodní plochy.
Jeden fotbalista, který drží ve vzduchu svého spoluhráče, zatímco stojí za koncovou čárou. 
Ohňostroj je v polo odpalu zatímco ohňostrojová hvězda padá na pozadí dolů.
Velrybí ocas mizí ve vodě, zatímco jej sledují lidé na škuneru. 
Široký pohled na jinou galaxii nebo sektor vesmíru.
Horské jezero pod modrou oblohou s nízko položenými mraky.
Molo vedle silnice a několik malých budov
Obrázek 3 typů objektivů fotoaparátu a z jednoho je udělán držák na rostliny v květináči.
Žena drží před obličejem ruku v rukavici, když stojí na plošině.
Mladá blonďatá dívka v červené košili stojí uvnitř kostela a intenzivně pozoruje množství zapálených bílých svíček s rukou zdviženou k jedné z nich. 
Pět koní a žokejů, kteří se účastní závodu. 
Pohled na modrý oceán s plovoucí lodí a zelenými stromy a horami podél pobřeží. 
Padlý strom v řece v popředí malebného obrazu hor za polojasného dne. 
Molo v jezeře, které je obklopené stromy a kopci.
Krásná krajina u vodopádu uprostřed lesa
Žena ve fialovočerveném stojí pod stromem. 
Banda malých dětí, které cvičí.
Pohled na ohňostroje a jezero v noci
Snímek ležící dámy, která se natahuje směrem k fotoaparátu. 
Obrázek veverky sedící na něčí tašce. 
Veverka, která stojí na dřevěném povrchu, něco jí. 
Větve stromu vyčnívající ze zamlžené růžovooranžové hladiny.
Černobílohnědý pes s červeným šátkem, který běží a stříká z něj voda.
Muž s červeným kloboukem sedí vedle ženy v červených šatech. 
Dvě děti jedou na svých kolech po oplocené cestě.
Auto přijíždí po ulici při západu slunce
Načernalá architektonická stavba ze šedého kamene zahrnuje schody a malou vodní fontánu. 
Černobílá fotografie mlhavého dne se zakrnělými stromy na poli. 
Velké kameny u řeky, s horami a stromy za nimi. 
Dva lidé jdou po poli se stromy a se žlutými listy na zemi.
Jezero obklopené sněhem pokrytými horami pod zamračenou oblohou. 
Žena v bílém, která se dívá skrze výlohu obchodu. 
Dvě ženy sedí před zrcadlem.
Dlouhé molo na pláži při západu slunce
Žena s vlasy do tváře se zeleným nápisem v pozadí. 
Muž v helmě se světlem stojí u budovy. 
Žena je oblečena do žlutého jako její hračka pikachu vedle ní. 
obrázek velké haly s nádhernou architekturou
Několik lidí jde okolo staré budovy s klenutými chodbami. 
Výjev chodníku mezi dřevěnými budovami s osobou v dáli. 
Svítící město v noci u řeky.
Tento obrázek je pohled shora na bazén a lidská obydlí.
Ostružiny vypadají, že jsou zralé, zatímco listy na podzim mění barvu. 
Černobílý obrázek dvou žen, které stojí na úpatí venkovních betonových schodů. 
veliká pláž s lidmi pod slunečníky v pozadí a člověkem, který se sprchuje, v popředí
Zelená baseballová výsledková tabule se skóre 2-0.
Cihlový příbytek s jedním malým oknem a satelitní parabolou na dvorku. 
Obrázek žlutočerveného letounu zaparkovaného na pláži. 
Lidé, kteří jdou po hliněné cestě, míjí strom. 
Muž v masce a v duhové paruce stojí na rušné silnici. 
Černobílá fotografie ženy, která závodí na svém koni. 
Pohled zblízka na konec oranžového pádla, které drží muž na písečné pláži. 
Lidé na ulici, dívka v modrém svetru, která nese tašku
Toto je snímek zdi, na které je růžový a modrý obrázek. 
Obrázek běžících vlků namalovaných na zdi. 
stín zvonice na cihlové budově, která se odráží i v okně
Západ slunce na jezeře se stromy okolo jezera.
Skupina stromů se zlatými listy, které se odráží v jezeře. 
Hodně oken mnoha barev, se svíčkami v jejich blízkosti. 
Muž sedí na židli a maluje na dveře garáže znak obchodu. 
Záběr zblízka na pravou žabku. 
Fotografie krásného moře s pěkným mostem uprostřed
Tři lidé, kteří jdou po městském nádvoří. 
keramická soška psa v popředí a tří černochů v oranžových kloboucích v pozadí
Žena s kloboukem z peří si fotí selfie a žena v modrém se na ni dívá
Tvář ženy je pomalovaná jako klaun a má na sobě vrstvy barevného oblečení
Stroj, který pracuje na zavodněném poli.
Slunce zapadá za molem na pláži. 
Strop toho, co vypadá jako vlakové nádraží, je zalit sluncem z velkých oken.
Černobílý obrázek tří lidí, nejspíše vysokoškoláků, kteří stojí a prohlíží si knihy. 
Skupiny lidí před historickou budovou s nedalekou fontánou. 
Dáma s červenou kabelkou, která si fotí dámu v bílých šatech a s hnědou kabelkou.
Muž a žena pózují u Eiffelovy věže.
Mladý chlapec se odráží na koloběžce. 
Želva leze na větev, která plave ve vodě
Pohled na silnici vinoucí se lesem na straně útesu. 
Žena s krátkými černými vlasy, brýlemi a zelenočervenočerném svetru, která si prohlíží nějaké pohlednice u venkovního stánku. 
Dva muži sedí a dívají se do poznámkového bloku
Dvě mladé ženy, jedna s velkým batohem, se dívají na řeku přes kovové zábradlí. 
Blonďatá žena s obrácenou kšiltovkou posedává a ukazuje znamení míru. 
Černobílá fotografie postaršího Asiata v davu. 
Žena si podpírá rukou tvář, zatímco se kouká z okna nad balkonem vyzdobeným vlajkami. 
Bazén poblíž několikapatrové vysoké budovy je pokryt velkou modrou krycí plachtou. 
Barevné graffiti pokrývá zeď podél zahnuté silnice. 
dvě dámy jdou po chodníku a jedna z nich se dívá do fotoaparátu.
Dívka má na sobě modré plavky a modrý puntíkovaný klobouk proti slunci. 
Stavby starých domků různých barev a lidé před nimi
Obrázek člověka ve stanu, který kempuje na travnaté ploše. 
Pohled na město zpoza několika kovových trubek.
Žlutočervené hasičské letadlo vypouští vodu.
Pohled zblízka na starého muže, který jde po chodníku. 
Tři dobré stíhačky vytvářejí formaci ve vzduchu.
Muž stojí sám v černobílé chodbě. 
Muž v červeném tričku a červené kšiltovce hází baseballový míček. 
Člověk plní dávkovačem láhev džusu. 
Muž jde před stěnou s graffiti
Skupina pěti tanečnic v černých úborech, které jsou zachyceny uprostřed výskoku na jevišti. 
Zelené pastviny přechází do stromů, co obklopují hrad.
Žena v červeném drží americkou vlajku a dvě Trumpovy volební cedule.
Krásný výjev louky a krajiny na farmě
Člověk nastupuje do letadla na asfaltu. 
Mladá dívka se protahuje před rozlehlou vodní hladinou. 
Černobílý obrázek zádě jednomotorového letadla nad vodou. 
Prázdná chodba s několika vchody do dalších místností a s dveřmi na konci 
lidská pyramida před sochou
Obrázek stromu a zatažené oblohy.
Krásná krajina s velkou řekou a borovicemi
Dva červené sedany zaparkované na trávníku. 
Hráčka baseballu tvrdě odpaluje pálkou
Chodníček na pláži lemovaný palmami a vlajkami. 
Pohled na město je tvořen velkými budovami různých velikostí a několik lidí kráčí po ulicích. 
Městská ulice s několika lidmi, co jsou nebo jedou na kole.
Druhý hráč na metě klubu Chicago Cubs se připravuje na odehrání míčku zatímco se nadhazovač napřahuje.
Dívka drží slunečnici.
Detailní záběr slunečnice, trávy a oblázků poblíž. 
Černobílý obrázek muže a ženy, kteří se nahlas smějí, muž si zakrývá tvář rukou. 
Vysoká budova se světelnými reklamami na Bud Light, Toshibu a TDK.
Velký jeden stojí uprostřed pole.
Černobílá fotografie psa na kmeni uprostřed lesa
Žlutočerný motýl sedí na větvi stromu s široce roztaženými křídly. 
Muž, který má červenou šálu, řídí motorku. 
Červená květina položená na skleněném stole venku. 
Zaparkovaný krásný model starého auta.
Vodní hladina za soumraku v popředí a osvětlená cesta na kopci v dálce. 
Červený pták na větvi stromu
Muž a žena na rohu obchodu, kteří používají své mobilní telefony
Puma sedí na kamenech s červenými listy, které jsou na nich a po okolí napadané. 
Pohled zezdola na muže a ženu v objetí u kostela obklopeného zahradou. 
Několik zelených rév roste na mřížové konstrukci.
Auta jsou zaparkovaná na trávníku vedle dvoupatrového domu. 
Bílý sedan a stříbrný sedan jsou zaparkovány u zdí pokryté graffiti, na které jsou dva hnědí brouci držící světle růžové květiny.
Žena s tmavými vlasy má na sobě bílý měkký klobouk a koženou bundu. 
Starobylá historická budova září v zapadajícím slunci. 
Drak s vlajkou Lone Star v Texasu, který uvízl na stromě. 
Kaňon se zelenými stromy a prašnými stezkami na dně, zatímco na něj zprava svítí slunce. 
Krajina se stromy a svítícím sluncem v dáli
Horná krajina a zelené pastviny
Rostlina kukuřice roste na malé ploše trávy u silnice.
seskupení mincí ležících na modrém pozadí
Dva dřevěné stolky, na nichž jsou láhve alkoholu. 
Duhová světla zvýrazněná kouřem nad hudebním koncertem.
Velké tryskové letadlo ve vzduchu se spuštěným podvozkem.
Muž ve žluté vestě tlačí vozík vedle vlaku.
Muž stojí u moře a fotí si západ slunce
Pár stojí společně před ciferníkem. 
Žena, která stojí před uměleckým dílem v muzeu, fotografuje
Lidé jsou během dne roztroušeni na pláži.
pohled přes síť na vstřelený fotbalový míč do brány
Roh budovy, kde vidíte muže, který fotografuje
Černobílý záběr muže, který sedí a dává si cigaretu a sklenici Pepsi
Muž na motocyklu jede po cestě bez asfaltu
Malá holčička v růžovém tričku jí něco lžící z misky. 
Ruka nad vodou a nějaké hory v pozadí.
Osoba běží na trávníku před nakloněnou budovou. 
Městská ulice se zaparkovanými náklaďáky u kraje. 
Malý chlapec jde po cestě obklopené vodou.
Obrázek západu slunce skrze stromy a mlhu
Postarší pár se z dřevěné terasy dívá na horské scenérie. 
Různé typy lodí na okraji města s lidmi okolo
Ulice dlážděná dlažebními kostkami se štukovanými budovami na každé straně. 
osamělý fotbalista s číslem 2 na dresu běží po hřišti
Bílý maják, který se tyčí na zamračené modré obloze. 
Několik zajímavě vypadajících budov, které se nachází na pozadí rušné ulice s mnoha vozidly.
Fotbalista v bílém dresu letí do vzduchu poté, co mu fotbalista v černém podkopává nohu. 
tři skleničky s vínem stojí na římse
člun, který plachtí po hladině za zamračeného počasí
Skupina vysokých budov je zobrazena černobíle. 
Červený vlak na železničních kolejích. 
Strom bez listů v popředí a v pozadí jsou stromy s barevnými listy. 
Dva cyklisté jedou v noci po silnici. 
Skupina cyklistů čekají na noční jízdu na kole
Toto je obrázek ženy, která drží kolo a běží přes pole.
Osoba v cyklistickém tlačí kolo do kopce. 
Fotografie velkého nákupního centra ve městě
Malý hnědý pes v růžovém svetru se plazí z velké látkové jahody. 
Prázdná autobusová zastávka s poloprázdným odpadkovým košem.
město při západu slunce, velká oranžová budova v pravém zadním rohu.
Kniha v cizím jazyce leží na křesle vedle dalších publikací. 
černobílý snímek muže, co jde a nese žebřík
Muž v kovbojské uniformě na bílém koni a s vlající vlajkou Denver Broncos
Bílý pes a černý pes si hrají na písku
Stříbrné auto stojí před jasně růžovým přívěsem. 
Fialová květina, která vyhrála 3.místo v soutěži.
Fotografie krásného oblačného města v velkými mraky
Žena odpočívá na své kabelce, knihou si zakrývá obličej. 
bagr na bahnité řece s těžkými stroji těžícími uhlí z půdy v pozadí. 
Bílá a šedá socha stojí u vchodu do budovy. 
strom se žloutnoucími listy za malou kůlnou
Fotka krásného zasněženého horského hřebenu s jezerem okolo.
Zdá se, že se řada městských domů naklání směrem do ulice. 
Pták, který sedí na starém rozcestníku. 
Uvnitř malého dřevěného plotu je stavba.
Velký útes se zelení na vrchu vedle oceánu.
Jasně modrá obloha s mraky nad železničními kolejemi a budovami. 
Horské jezero pod zamračenou oblohou, s komerčními budovami v popředí. 
Obrázek kostry muže a ženy, kteří sedí u stolu a "jedí" jídlo. 
Výjev moderně vypadající budovy s cihlovou cestou pro pěší a několika malými stromky. 
Pohled na městskou ulici, která vede skrze dvě řady budov a auta, která lemují silnici. 
blonďatá dívka v modrém tričku sedí u stromu
Staré auto v poušti proděravěné kulkami.
Veverka sbírá oříšky na travnatém pásu.
Muž vaří jídlo ve stánku, u kterého stojí žena v červené bundě. 
Černobílá fotografie několika židlí u zdi
Pohled na řidítka jízdního kola, které jede po dlouhé špinavé cestě
Dvě ženy, které se venku na ulici dívají do mapy. 
Šipka ukazuje na muže, co stojí na pruhované podlaze.
Skupina lidí, kteří se baví a připravují se v šatnách
Velmi krásná žena pózuje v lese na fotografii
Velké budovy pod modrou oblohou s rozptýlenými mraky. 
Dvě ženy veslují v kanoi po klidné hladině s městem v pozadí. 
Obrázek zdi, na které jsou nakresleny pivní plechovky. 
Žena zpívá do mikrofonu v zakouřeném pokoji. 
Muž na závodě v oranžovém tričku a s potítkem na hlavě.
Siluety dvou mužů, kteří stoupají nahoru ven po jezdících schodech. 
Člověk sedí na pódiu a někdo v pozadí jej sleduje. 
Pohled ve výšce očí na předky několika starožitných automobilů. 
Černobílý obrázek vlaku na kolejích
Skupina lidí se drží za ruce a za nohy.
Usmívající se mladá atraktivní žena v kšiltovce sedí na kraji silnice. 
Slunce vychází nad zamlženým městem.
Špinavá cesta přes les s listy měnícími barvu. 
Mnoho hvězd na noční obloze vedle stromu a skalního útvaru. 
Akční fotka horské dráhy, která jede vedle vysokých útesů a vodopádu
Vinice ve vinoucích se kopcích mají nad sebou tmavě šedá mračna. 
Sportovní auto s číslem 20 na dveřích zaparkované před kamennou budovou. 
Dvě dívky se smějí, když prochází na ulici okolo několika obchodů
Jezero v popředí malebného obrazu, který obsahuje i hory v pozadí. 
Muž a žena spolu mluví, když stojí vedle dunkin donuts.
Stará žena v černozlatém kabátu uprostřed zimy.
Chlapec se dívá z okna přeplněného vlaku. 
Žena venku s cigaretou v ústech a muž, který jde v pozadí. 
Muž a žena s hlavami u sebe při důvěrné konverzaci. 
Žena a muž, kteří se v noci drží za ruce na pláži, a dívají se na hvězdami pokrytou oblohu. 
