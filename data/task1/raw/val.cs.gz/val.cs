Skupina mužů nakládá bavlnu na náklaďák.
Muž spí na gauči v zeleném pokoji.
Chlapec má na sobě sluchátka a sedí ženě na ramenou.
Dva muži rozdělávají modrý rybářský stan na zamrzlém jezeře.
Plešatící muž má na sobě červenou záchrannou vestu a sedí na malé loďce.
Dáma v červeném kabátě drží modravou kabelku pravděpodobně z Asie a skáče do vzduchu kvůli snímku.
Hnědý pes běží za černým psem.
Malý chlapec v dresu Giants odpaluje baseballovou pálkou příchozí míč.
Muž telefonuje v přeplněné kanceláři.
Usmívající se žena v broskvové topu drží horské kolo.
Malé dítě stojí samo na rozeklané skále.
Osoba na sněžném skútru uprostřed skoku.
Tři malé děti stojí okolo bílomodrého sudu.
Žena sedí u vystavených sušených květin na venkovním trhu.
Žena hraje píseň na housle.
Tři lidé jedou na dvou terénních motorkách a jedné čtyřkolce v suché trávě.
Polonahý muž spí venku na židli.
Skupina lidí na parkovišti stojí před chatrčí.
Mladá žena vyrábí koberečky v deštném pralese.
Tři holky se ksichtí a jedna pije, když stojí na rušné ulici.
Muž v černém tričku stojí nad davem v rušném baru.
Žena a muž jsou přes dřevěný provazový most, který má vedle sebe výstražnou ceduli.
Muž v sukni skáče a do toho žongluje s noži.
Asiatka v zeleném klobouku a zástěře servíruje nápoje na tácu.
Dělníci stojí na nějakém stroji.
Dva psi s oranžovou hračkou ve vysoké trávě.
Roztomilé mimino se směje na další dítě.
Tři muži jdou po silnici v horách.
Člověk parasailuje na velkou vodní plochou.
Bagr jede hlínou při stavbě opěrné zdi.
Holčička běhá v parku.
Člověk přechází silnici a vyhýbá se vylité barvě.
Dítě si hraje na hřišti, visí z tyčí.
Člověk má na sobě červené tričko s dlouhým rukávem, leží na zdi před lampou velmi neobvyklým způsobem.
Skupina lidí se shromáždila okolo muže v obleku a malého kluka.
Žena sedí v tmavém baru.
Lidé jdou po chodníku a prochází venkovním trhem.
Muž s modrým batohem si čte noviny, když čeká na metro.
Velký hnědý pes strká čumák před rozstřikovač.
Blonďatý chlapec v modrém tričku stojí a usmívá se před výrobkem ze zelené nylonové látky.
Malý bělošský chlapec zametá podlahu terasy velkým koštětem.
Osoba se chystá hodit zelenou bowlingovou kouli po dráze.
Skupina hraje rock návštěvníkům baru.
Postarší muž se prochází se psem na červeném vodítku.
Muž řídí červené staromódní závodní auto.
Mladí dospělí v červených, žlutých a černých tričkách v řadě předvádí své číslo.
Mladý chlapec hází kámen do stojaté vody.
Dvě ženy s krátkými vlasy jsou otočené k sobě a ta blonďatá něco říká.
Postava v důmyslném kostýmu před výrazně zdobenou stavbou.
Pes jde malým potom s hadrem v tlamě.
Tři malí psi u něčeho čuchají.
Dva muži pádlují na kajaku v řece se zelenými stromy na obou březích.
Dvě holky jdou po ulici.
Skupina dětí sedí vzadu v dodávce a spolu se dívají na knihu.
Lidé na pláži si prohlížejí obraz srdce namalovaný na obloze.
Dívka sedí pohodlně na veřejném místě, čte si a udržuje knihu otevřenou rukou, na které má prstýnek s motýlem.
Muž má oběd v restauraci.
Muž v obleku a brýlích má nějaký předmět v rukou.
Muž v černém neoprenu surfuje na vlně.
Žena s růžovou kabelkou sedí na lavičce.
Tři ženy se usmívají a sedí.
Červené letadlo přelétává nad lodí a zanechává při tom růžovou kouřovou stopu.
Muž při sportovním lezení šplhá na skálu.
Dva stavební dělníci pomáhají nakládat náklaďák na městském staveništi.
Žena v barevném oblečení prochází kolem bílé dodávky s kanystry.
Žena v modrém klobou a žluté sukni skáče u lilií.
Muž ve zlatém oblečení stojí u svého starého kola.
Mimino se dívá na listy na větvi stromu.
Uklízeč se chystá vytírat stanici vlaku.
Dva malí černí kluci si hrají s láhvemi s umělé hmoty a náramně se baví.
Na semaforu svítí zelená a lidé se dívají na motorky.
Dva lidé šplhají na skálu po provaze.
Muž a žena rybaří na pláži.
Dítě dělá salto, když skáče na trampolíně.
Děti jedou na řetízkovém kolotoči
Dva lidé drží vzhůru nohama obří glóbus s průměrem asi čtyři stopy a dítě vypadá, že skáče přes Antarktidu.
Dva muži z armády hrají baseball.
Žena v černých šatech tlačí vozík s termoskami dlážděném chodníku.
Policista zastavuje auto na kraji silnice.
Muž stojí na molu vedle lodi na klidném jezeře.
Skupina skotských důstojníků na přehlídce.
Žena a dítě spolu sedí v rámu dveří u šedého a muž jde okolo.
Osamocený hasič pomáhá zkrotit veliký oheň.
Osoba ve fialovém tričku maluje na zeď obraz ženy.
Malá dívka leží na podlaze a její mladší sestra dělá, že je zdravotní sestřička.
Mladší a starší žena v tradičních šatech u kolovrátku, tři lidé v moderních šatech jsou od pasu dolů zobrazeni v pozadí.
Žena jde hlubokým sněhem ze strmého kopce.
Řidič FedExu poslouchá dělníka v zelené helmě, zatímco se nakládá vybavení.
Hnědý pes má na sobě černý obojek.
Hnědobílý pes běží dolů po žlutomodré rampě.
Dítě se chystá číst knihu.
Starší Japonec se pokouší opravit malý červenošedý stroj.
Malé dítě a žena stojí vedle kohouta v kleci.
Dítě převlečené za Spidermana zvoní na zvonek u dveří.
Muž v hnědém drží světelný meč.
Mladá žena stojí a zpívá do mikrofonu, zatímco muž za ní drží kytaru.
Dvě děti hrabou díry v hlíně.
Hodně těchto lehátek je prázdných a leží na nich jen hrstka lidí, kteří si užívají sluníčka.
Nějací muži sedí na lodi u pláže s naskládanými kládami a klacky.
Mladý muž nese něco ve velkém černém igelitovém pytli na odpadky.
Starší muž s nadváhou obrací palačinku při přípravě snídaně.
Muž ve žlutém obleku na pódiu s piánem a další muž hrají na basu.
Několik lidí stojí u stromů za úsvitu.
Hnědý pes kouše velký kus dřeva.
Turista pózuje ve vyprahlé horské krajině.
Skupina dětí si hraje ve vodě pod mostem.
Žena se směje vedle muže, který se také směje a drží cukrovou vatu.
Dvě ženy stojí před třídou dětí a mluví o knížce.
Dvě brunetky hovoří ve třídě plné blonďatých dětí.
Člověk, který má na sobě čepici a šálu, se dívá doprava.
Dva lidé jdou přes ulici.
Starý muž drží jednoho, zatímco další jeho pes mu šplhá do klína.
Tři děti se dívají na muže, který hraje na pódiu na kytaru.
Chlapec si bere kolík od dívky uprostřed závodu.
Modrý jeep jede do hluboké, bahnité vody.
Dáma s černým kloboukem fotí a padá sníh.
Muž sedí na zemi a hraje na kytaru.
Pes šlape do mělké vody ve skalnatých horách.
Mladá Asiatka skáče do vzduchu v části města, kde je hodně lidí.
Tři muži hrají na pódiu.
Čtyři lidé protestují proti tomu, jak Equinox zachází s mladými dělníky.
Muž dělá hamburgery na černém grilu.
Muž v kšiltovce se opírá o slabou tyč.
Malý chlapec ve žlutém tričku visí na kruhu a okolo jsou ostatní děti.
Malé dítě jí ovoce a pije sklenici džusu.
Jeden muž a dvě ženy v šortkách jdou po ulici.
Dva pudli běží sněhem.
Malá zrzavá holka má na sobě oblek Spidermana a jede na hračce koně.
Muž v bílé loďce na rybníku.
Lyžaři před chatou.
Lidé jsou fotografováni při horolezení nebo horské turistice.
Několik lidí plave ve vodě.
Ženy v plavkách hrají za slunného dne plážový volejbal.
Muž a žena sedí naproti sobě u stolu v restauraci.
Matka a dvě děti pózují a dělají vtipné obličeje.
Zlatý retrívr plave ve vodě s červenou hračkou v hubě.
Čtyři muži stojí u žlutého auta.
Skupina mužů, žen a dětí v kloboucích se baví na pláži.
Malý kluk v dupačkách leze po hnědé podlaze.
Malá holčička dává dar armádě spásy vedle vstupu do obchodu, kde jsou plastové nádoby.
Žlutý pes nese míč v tlamě na pláži.
Muž v červeném triku a dvě děti stojí před starou budovou.
Muž se dívá na ženu, když jsou na baru.
Kapela hraje na venkovním pódiu u řeky.
Dvě ženy se usmívají na společenské události.
Žena má na sobě růžové tričku a muž v pruhovaném svetru ji ukazuje nějakou práci s jehlicí.
Dítě sedící na skále.
Muž sedí na židli s pivem v rukou a opéká si něco k jídlu na dřevěné tyči.
Policista v uniformě má sluchátko.
Muž v hasičském oblečení přechází ulici v blízkosti bílého autobusu a červeného nákladního auta.
Černobílý pes plave v čisté vodě.
Hudební skupina hraje na pódiu při koncertě.
Tři lidé hrají na hudební nástroje a další člověk vypadá, že zpívá.
Muž hraje na klávesy a zpívá do mikrofonu.
Malý chlapec skáče do vody.
Žena si čte pohlednici, sedí na konci gauče a další žena stojí vedle ní a drží sklenici s pitím.
Dělníci na stavbě tvrdě pracují.
Muž se holí a sedí na pláži u oceánu.
Blonďatá žena v modrém triku rozbaluje čepici.
Dva muži si povídají za varhany a osamocená žena stojí po jejich pravici.
Mladý blonďatý muž mluví do mikrofonu.
Hotelový zřízenec v plášti tlačí náklad zavazadel.
Pres se krčí mezi rostlinami a dívá se do foťáku.
Hudební skupina vystupuje na pódiu před davem lidí.
Tři psi si hrají ve sněhu.
Muž a žena stojí u stromu a hovoří spolu.
Pes skáče za žlutočerným míčem.
Starší žena v šedočerveném svetru vaří pokrm.
Žena v kabátu je před domem a sněží.
Žena nese další ženu na zádech, mají na sobě cvičební úbory.
Dítě stojí vedle kočárku a drží meč.
Chlápek s kudrnatými vlasy skateboarduje po rampě se žlutými písmeny.
Muž kutálí kulatý stůl po podlaze.
Skupina lidí ve člunu na moři.
Muž ve žluté košili stojí na chodníku a něco měří.
Žena v modré košili a džínách vyhazuje něco do popelnice.
Žena v masce dominy drsnými vlasy je na večírku.
Osoba parasailuje na hřebenu vlny.
Muži v modrých uniformách sedí v autobuse.
Auto ATV se snaží dostat z díry.
Muž sráží dalšího, když hrají fotbal.
Fotbalový hráč v červeno-bílém hovoří s trenérem.
Dvě dívky sedí u zdi a dívají se na zápas.
Trenér OU má na hlavě sluneční brýle v průběhu fotbalového zápasu.
Fotbalový tým má na sobě červená trička a červené helmy.
Kluk v černém oblečení dělá hvězdu na pláži.
Pózují na fotku.
Muž v zeleném tričku dává pusu batoleti, když sleduje běžce na trati.
Pět členů kapely hraje píseň.
Tři ženy sedí na zemi dece s dítětem a baví se.
Muž s chlapcem sedí u oltáře a drží zvonky.
Muž ve slunečních brýlích pomáhá dítěti ve slunečních brýlích sjet dolů skluzavce.
Pes běží trávou k fotografovi.
Dívka s dlouhým copem je připravená hodit míč další hráčce na hřišti.
Dva muži zápasí na žlutomodré podlaze.
Dívka v červenomodrém dresu a modrých šortkách je připravena k hodu míčem.
Sedící muž pracuje rukama.
Hnědý pes běží po pláži a nese klacek.
Osoba vesluje na vodě.
Muž v červenobílé pruhované košili sedí na stoličce u stánku s párky v rohlíku.
Muž fotí bílé a žluté tulipány.
Dva muži ve fezech diskutují na venkovním trhu.
Muž a hoch si hrají se psem při západu slunce na pláži.
Horkovzdušný balón přistává, muž ve stínu je v pozadí.
Ten muž má na sobě čepici nebo klobouk.
Ženě malují na obličej černé čáry a třpytky.
Batole v džínové čepici si hraje na pneumatice.
Dav lidí stojí na ulici před řadou bílých stanů.
Dav lidí prochází parkem.
Žena s tmavými vlasy má na sobě modrou blůzu a sluneční brýle drží transparent a malá holčička se zapletenými vlasy píše na transparent.
Množství asijských dětí dělá vláček pod vietnamskou cedulí.
Kovboj jezdí v rodeu na koni, který vykopává nohama.
Ženich a nevěsta při svém novomanželském polibku.
Dva záchranáři podkládají vlak.
Muž pracuje na železnici v železniční stanici.
Pár dělníků, míchají beton v trakařích, staví nebo opravují zeď, zeď je ještě vlhká.
Kapela hrající na chodníku.
Muži v oranžových oblecích sledů stroj, jak hrabe vedle něčeho, co vypadá jako koleje metra.
Mladí dospělí v neformálním oblečení jdou po trávě.
Velký hnědý pes běží mělkou vodou.
Muž a ženy jdou přes prázdnou ulici.
Muž nabalený do chladného počasí stojí v koši a pracuje na elektrických drátech.
Dvě děti ve žlutých kabátcích si hrají v blátě.
Několik lidí jede na horské dráze hlavou dolů.
Žena sedí s malým chlapcem na křesle.
Skupina lidí stojí přibližně v řadě na dlážděné podlaze.
Malá holka plave v bazénu.
Kluk v oranžovém tričku se směje a kluk v modrém tričku se na něj dívá.
Malé dívka stojí venku v louži.
Malá blonďatá dívka drží sendvič.
Čtyři lidé se snaží spravit kolo v parku
Promáčený hnědý pes vylézá z vody.
Pres běží přes trávu s míčem v tlamě.
Skupina lidí čeká za zábranou a dívá se doprava.
Dítě, které má na sobě červenou mikinu, visí hlavou dolů ze stromu.
Obsluha hry na pouti si bere peníze od dvou soutěžících.
Kluk se směje do foťáku ve skupině sedících dětí.
Dvě děti bez triček sedí na kraji fontány.
Muž si natahuje mikinu, když má kajak u nohou.
Starý muž jde s deskami v ruce.
Nezaujatá mladá žena a starší muž stojí u baru.
Mladý blonďatý chlapec skáče z postele na postel.
Malé dítě máchá červenou baseballovou pálkou.
Muž mluví do mobilu před sportovním obchodem.
Dvě maminky poslouchají malé dítě.
Žena v modrém tričku hraje na hudební nástroj.
Toto je rušná křižovat ve velkém městě v noci.
Muž sedí v mělké vodě vedle velké kamenné tváře.
Pár turistů si dává přestávku, aby se vyfotili.
Čtyři lidé ve stylu goth jdou po ulici se stromy v pozadí
4 lidé jsou připoutaní před jízdou v zábavním parku
Chlapec předvádí trik z kovové tyče na skateboardu.
Muž na pláži staví hrad z písku.
Velký hnědý pes honí malého hnědého psa.
Muži v bílých úborech zdvihají ruce.
Žena hází frisbee psovi a za ní běží baseballista v dresu.
Černý pes stojí v trávě a má v hubě plastovou věc.
Loď s lidmi a jejich věcmi je na vodě.
Skupina závodních silničních cyklistů se naklání v zatáčce.
Tři lidé sedí venku u stolu, o který jsou opřena umělecká díla.
Bílá žena a černý muž jsou po ulici.
Muž v bílém tričku maluje uprostřed silnice vydlážděné kameny.
Hnědo-černo-bílý pes štěká nahoru na strom.
Muž s modročerveně pomalovaným obličejem pózuje spolu se ženou.
Dva chlapci hrají hru s kuličkami.
Dva muži čekají na zadním sedadle v autě a řidič si sedá na sedadlo řidiče.
Chlapec se houpe na houpačce.
Černoch se dívá na druhého, který si hraje pod vodopádem.
Osoba s červeným batohem na výletě.
Asijský dodavatel ovoce a zeleniny a jeho výběr banánů, pomerančů, melounů a dalšího na jeho loďce.
Velký dav stojí s velkými budovami v pozadí.
Tři ženy s tmavými klobouky zahalené do tmavých šátků spolu mluví na dlážděné ulici a u nich sedí pes.
Muž v bílém si dělá kebab.
Osoba v neonově růžové paruce a žlutém tričku se dívá přes pláž.
Muž se dívá na ženu, která kouří na chodníku.
Muž v černém tričku, hnědých kapsáčích drží lopatu nad hlavou.
Muž olizující tvář ženy s brýlemi.
Dítě jde před dalším.
Malý chlapec v pozadí dělá králičí uši dívce, která stojí před ním.
Mimino v růžovém fleecovém oblečku leží v suchém listí a směje se.
Detail ženy s krátkými červenými vlasy.
Fotbalista v zeleném dresu běží z hřiště.
Holka vede svého psa přes překážku.
Několik dětí sedí ve třídě na barevném koberečku a hlásí se.
Námořník stojí nahoře na nástupním můstku do velké lodi.
Středně velký pes skáče, aby chytil malý látkový létající talíř.
Muž v šedém tričku odpočívá.
Černý pes skáče vodou, zatímco drží klacek v tlamě.
Dva černí psi běží vedle zpevněné cesty, každý po jedné straně.
Čtyři lidé v neformálním oblečení stojí venku a drží pytle na odpadky.
Lidé a velbloudi odpočívají v poušti.
Čtyři psi si hrají v kruhu a jeden černý pes jde pryč.
Muž v armádní uniformě mluví do mikrofonu.
Skupina asiatů na výstavě aut zírají a fotí si nové auto.
Plavec plave v bazénu.
Žena v bílém triku si uvnitř domu hoví na gauči.
Muž vedle dvou mladých dívek dává pokyn rukou.
Dívka v bílém triku ve tmavém pokoji fouká do bublifuku.
Kluci a holky z nějakého východního národa se smějí na poli.
Dítě v oranžovém tričku skáče z balíků slámy a ostatní děti se dívají.
Kluk dělá triky na skateboardu.
Muž se natahuje, aby pracoval s kabely nad stolem.
Batole sedí u stolu a svačí.
Čtyři děti s batůžku se otáčí čelem k foťáku, když jdou po vesnické ulici.
Muž s dredy si zacpává ucho aby slyšel telefonát.
Muž skládá velké měkké disky na hřídel v průmyslovém prostředí a další muž se dívá.
Pes na trávě se dívá nahoru.
Žena a malé dítě se baví při deskové hře.
4 děti sedí na římse a konverzují.
Malý hnědý pes uprostřed rostlin v květináči a popadaného listí.
Dva muži malují budovu na bílo a třetí jde okolo a telefonuje.
Nějací lidé se v kanceláři dívají na obrazovku počítače.
Dvě ženy si prohlížejí snímek ve fotoaparátu.
Blondýna v hnědém kovbojském klobouku dělá vulgární gesto do foťáku.
Bílohnědý pes běží po trávě.
Dospívající dívka čte knihu ve třídě, poznámky má na stole a vypadá znuděně.
Dvě malé dívky jdou listím.
Nevěsta upravuje svému ženichovi květinu na jeho saku a drží při tom kytici.
Žena dává oranžovou růži do knoflíkové dírky na klopě mužova saka.
Dvě ženy s kočárky jdou po ulici zapadané listím.
Čtyři ženy oblečené do směšných kostýmů.
Tato stará Asiatka odpočívá a ovívá se za zjevně velmi horkého dne.
Dívky v bikinách hrají beach volejbal.
Muž v brýlích a malá dívka v záchranné vestě plavou v bazénu.
Tři děti v hnědých tričkách a džínách skáčou venku, kde je na zemi listí.
Žena se soustředí na curling.
Osoba nese množství tašek.
Dítě poblíž modré plošiny, na které stojí barevné stvoření.
Mladík s přihlouplým výrazem stojí mezi bavícími se lidmi.
Dítě ve školní třídě po skončené výuce, možná.
Muž na wakeboardu ve vodě.
Dětí zírají z okna modré budovy s červenými okenicemi.
Muž s prošedivělými vlasy, s vousy a brýlemi v černém sedí na trávě.
Žena a její dvě děti jsou na pláži a žena skáče vysoko do vzduchu.
Pár mužů jde po městské ulici.
Chlápek dělá trik na kole v parku.
Muž ve jasně barevné bundě na lyže s dalšími na evropské ulici.
Žena ve žlutém triku a slunečními brýlemi jde po chodníku.
Dvě ženy se dívají na spoustu domů pod sebou.
Dva velcí psi dovádějí v trávě.
Lidé oblečení navrstveném oblečení se společně pohybují.
Skupina lidí jí v restauraci.
Žena v černém tričku vypadá, že jede nahoru po eskalátoru.
Místnost plná sedících a stojících dětí s osmi růžovými balonky zavěšenými u stropu.
Muž a žena společně pózují na dlážděné ulici.
Dva psi pobíhají a hrají si ve sněhu.
Malý pes skáče na ulici.
Muž v černém tričku hraje na sedmistrunnou baskytaru na pódiu.
Chlapec a starý muž s vycházkovou holí si povídají.
Dívka v bílém tričku, černých šortkách a čelence hraje volejbal.
Dva muži stojí na ulici, která je pokrytá graffiti.
Kluk v triku a šortkách drží sněhovou kouli a je otočen směrem k zasněžené hoře.
Muž visí, když plachtí na moři.
Dva husaři na koních oblečení v extravagantních kostýmech, každý držící šavli v pravé ruce a otěže v levé ruce.
Pes běží hlubokým sněhem.
Středně velká skupina lidí pózuje před foťákem.
Velký hnědobíle flekatý pes leží na bundě na ulici.
Dvě náctileté drží, která se ukazuje na tečku, a usmívající se.
Matka a syn jedou na bobech a smějí se.
Muž v černém tričku vaří podle kuchařky v neuklizené kuchyni.
Žena v bílém hraje na černou kytaru.
Snowboardista skáče ve vzduchu vedle lanovky.
Několik lidí stojí v místnosti a jí.
Muž v klobouku hraje na neobvyklý nástroj u výstupu z metra.
Týpek sjíždí parapet u větrného mlýna
Žena v bílém tričku a černých kalhotách tančí hula-hop a dívá se na ni velká skupina lidí.
Starší muž dělá rozhovor s druhým v závodním dresu.
Dva muži v červených úborech předvádějí bojová umění.
Malé dítě jede blátem na motorce.
Dítě v klobouku a bundě běhá venku na kamenném povrchu.
Dítě sedí v davu na ramenech svého otce.
Dva staří muži v kloboucích podřimují venku na sluníčku.
Dva hoši ve stanu se usmívají na fotografa.
Teple oblečená žena v černém klečí s malý světlehnědým psem před davem přihlížejících.
Dva muži chystají nějaké elektronické vybavení.
Žena, která nese tašku Trader Joe's grocery, usnula ve vlaku.
Cyklista dělá trik ve vzduchu.
Mladý muž v zelené mikině čte noviny na pláži.
Muž v zelené bundě se usmívá.
Muž šplhá na strmou skálu s jištěním.
Mladý muž jede přes ulici na podomácku vyrobeném kole.
Dva hnědí psi zápasí na travnatém kopci.
Člověk v dlouhém červeném kabátě jde před budovou.
Zahraniční žena sedí s hodně barevnou látkou.
Dva muži za plotem skáčou do vzduchu a drží basketbalový míč.
Muž s brýlemi u mikrofonu se dívá na papíry, které má v ruce.
Dítě v zeleném tričku druží u pusy červený balónek.
Muž s potetovanou paží něco smaží.
Čtyřčlenná skupina hraje živé vystoupení.
Skupina mladých asiatů běží maraton.
Muž táhne předměty na vozíku.
Tři velcí psi si užívají skotačení ve sněhu.
Pták letí přes vodu.
Skupina rodičů sedí na venkovním shromáždění.
Žluté auto uhání po sněhovém poli.
Skupina dětí si posedala a hraje hudební nástroje.
Skupina dospělých sedí u stolu a poslouchá prezentaci.
Žena oblečená v zeleném tričku čte prezentaci své třídě.
Mladí lidé jsou zapálení do hry.
Baseballisté v modrobílých dresech hrají baseball na hřišti.
Žena a dva chlapci se dívají na informační stanici.
Skupina lidí běží maraton pro dobročinnost.
Dvě ženy stojí s hůlkami ve hlubokém sněhu.
Lidé spolu stojí před sochou zvířete a všichni na sobě mají zimní oblečení.
Mladý lyžař se dívá do foťáku.
Dvě mladé dívky oblečené v růžovém pyžamu sedí na podlaze před velkými okny a hrají si s hracím domkem.
Žena a dítě jedou na velbloudovi u oceánu.
Muž s rukou na čele se směje v zaplněném baru.
Ulice je plná lidí v kabátech.
Dva muži v cizí zemi se smění, jeden stojí a druhý sedí se skříženýma nohama.
Malý hnědý pes běží v trávě.
Pouliční restaurace v noci.
Snowboardista dělá trik.
Asijská žena v doručovatelské uniformě strká do velké hromady balíků.
Žena v modré košili jede na kole.
Žena v bílem tenisovém dresu vyskakuje, aby trefila míček.
Mladá žena uvnitř cvičí na strunný nástroj.
Nevěsta a ženich se fotí a poblíž stojí dva muži.
Žena držící černo-bílého psa.
Chlapec v červeném tričku zkouší hrát na kytaru.
Mladá úřednice kontroluje nové emaily od klientů.
Tři straší ženy ve vánočně vyzdobeném obýváku a notebook VAIO jsou ve středu pozornosti.
Bílý chlupatý pes skáče a chytá hračku.
Matador v barevném oblečení jede na býkovi.
Děti se koupou ve vodě z obrovských sudů.
Světlehnědý pes skáče se žlutým míčkem v tlamě.
Skupina lidí v modrých tričkách na sportovní události.
Tenista ve žlutomodrém dresu a modrou čelenkou.
Dvě malá děvčata v modrých šatičkách se usmívají.
Malá dívka v růžové baletní sukénce zkouší tancovat se šátky.
Dva lidé běží na vrcholu hory.
Skupina žen tancují balijské tance v barevných kostýmech a makeupu.
Cyklista skáče v lese.
Několik lidí jde podél bílého plotu v cizí zemi.
Žena stojí na cihlové zdi a fotí.
Žena v bílých šortkách, žlutém tílku a bílých sandálech vypadá, že hází klackem.
Osoba jede na terénní motorce.
Malá asijská dívka sedící v černém kbelíku jí marshmallow a má na tváři široký úsměv.
Dva teriéři si hrají na dřevěné podlaze domu.
Batole s dudlíkem v červeném tričku se zahradní hadicí.
Náctiletý kluk na kole dělá triky.
Starý muž má na sobě černou bundu a dívá se na stůl.
Muž v modrém tričku jde vedle muže v červeném.
Žena vysí ze stromu na pruhu látky omotaném kolem nohy.
Malá bosá holčička s helmou jde po spadlém stromu pokrytém mechem.
Černý pes skáče přes pestrobarevnou překážku.
Chlapec v modrém, který hraje fotbal, se chystá kopnout do míče.
Skupina cyklistů se chystá na závod.
Chlápek utíká před černým býkem.
Kluk s čírem honí husu v parku.
Malý hnědobílý pes běží po chodníku.
Dvě děti dávají obličeje do obrazu rytíře a princezny.
Stíny dvou mužů na lanech.
Černý pudl si hraji s další psem a suchém hřišti.
Několik lidí si vychutnává cigarety u popelníku.
Bílý pes s hnědým flekem skáče ze břehu do vody.
Fotograf pořizuje snímek nápisu na dveřích.
Malá holčička v kostičkovaných šatech a velkým modrým míčem vedle plotu z drátěnky.
Muž trénuje box.
Skupina mladých lidí pózuje ve vzduchu na písčité pláži.
Žena drží housle.
Cestovatelé jsou na túře za velmi chladného dne.
Muž v šedém tričku dělá trik na skateboardu na schodech.
Tři muži jdou vedle stanu, na kterém je bilboard.
Malá holčička stojí na louce.
Chlapec v zeleno-žlutém dresu se učí boxovat.
Muž a žena hrají venku hru.
Malá holčička má na sobě šaty, sandály a běží po trávě.
Žena s fialovými vlasy a muž ve slavnostní uniformě.
Lidé tancují a tleskají.
Muž jde po ulici a zírá na kolemjdoucí pár.
Muž v bílém tričku a pruhovaných kraťasech hraje na varhany a pozoruje ho muž ve žlutém tričku.
Velká skupina lidí sleduje představení na pódiu.
Auto jede po prašné trati a zanechává za sebou oblak prachu.
Skupina lidí poslouchá muže, který mluví venku.
Vousatý plešatý muž v proužkované košili spočívá hlavou na rameni jiného muže.
Chlapec se chystá vykopnout míč na bránu.
Cyklista na kole jede po silnici kolem kamenů pokrytých sněhem.
Dlouhovlasý muž v oceánu pohazuje mokrými vlasy.
Chlapec a muž oblečení jako rodeoví klauni stojí v písku.
Malá holčička se směje a ukazuje palec vzhůru, když pózuje před želvou.
Muž v modrém jede na motorce po dráze.
Člověk se snaží na padáku při poklidném západu slunce.
Servírka stojí za přepážkou s koláči.
Dva cyklisté přejíždějí ulici v chladném kalifornském dni.
Skupina muzikantů nahrává hudbu.
Dva lidi hrají vodní volejbal v bazénu.
Kavárna na rohu s oválným obrazem na rohu budovy.
Chlapec zvedá druhého chlapce na zádech.
Žena používá velký foťák a stojí na ulici.
Žena má na sobě velký modročervený klobou.
Žena si barví tvář a chlapec s čírem jí drží zrcadlo.
Multikulturní skupina dospělých, muž s tetováním něco hází.
Muž v modré košili jede na jednokolce a u toho drží hořící pochodně.
Malé dítě si hraje s rozstřikovačem.
Čtyři děti si hrají před vchodem a jejich otec je pozoruje.
Muž drží nemluvně a opírá se při tom o budovu.
Žena se dvěma medailemi kolem krku ukazuje sedm prstů.
Dva muži zápasí při hře.
Dvě holčičky jedí koláč, jedna z nich má modrou polevu na obličeji.
Žena nandavá helmu malé holčičce.
Dav sleduje někoho ve svém středu.
Chlapec v parku si hraje se dvěma oranžovými míči.
Malá blonďatá holčička stojí na polštáři a usmívá se se zavřenýma očima.
Muž s kytarou zpívá do mikrofonu.
Muž s korálky Mardi Gras okolo krku drží tyč s transparentem
Muž v zeleném a žena v černém se protahují.
Muž si fotí jiného muže a jeho dva psy na travnatém pahorku.
Muž dělá nějaké veřejné představení s ohněm.
Velký černý pes běží podél plotu po trávě.
Motokrosař trochu letí vzduchem na skoku na závodním okruhu.
Žena jede na kole po silnici a zvedá při tom přední kolo.
Černý pes skáče nad vodou za frisbee, které plave poblíž lodi.
Muž v černé bundě a černé čepici hraje na trumpetu.
Muž v zeleném jede na snowboardu na lavičce.
Indický muž sedí venku u stolu v restauraci.
Tři muži v obleku dávají ruce k sobě.
Malý pes v oblečku stojí na zadních nohách, aby dosáhl na visící květiny.
Muž jede po schodech dolů na kole.
Muž s kbelíkem a holčička v klobou jsou na pláži.
Lidé jdou po městském chodníku před barem s grilem.
Velký pes skáče v kašně a opodál stojí muž v černém triku a vestě.
Muž na lodi oblečen v oranžových kalhotách drží provaz.
Dva muži venku za jasného slunečného dne se snaží chytit nějaké ryby na jezeře.
Muž stojí na lešení a barví zeď na červeno.
Prodavač sedí u vystavených skleniček na trhu v asijské zemi.
Dva lidé v bílých tričkách jdou po chodníku a mluví do svých telefonů.
Malá dívka se zeleným náhrdelníkem běží od sítě.
Umělec maluje venku.
Dvě asijské děti, chlapec a dívka, stojí na podlaze vedle stromu.
Lidé ve frontě se připravují nastoupit do autobusu.
Dva týmy, jeden v růžovém a jeden v bílém, hrají lakros na hřišti.
Žena ve žluté helmě sjíždí na laně.
Černý pes plave ve vodě s tenisákem v tlamě.
Tři muži jedou v tmavomodrém autě.
S vanou a vlajkami přidělanými na střeše je auto připravené ke startu rallye.
Muž v modré košili hraje na trubku.
Zámečník stojí ve čtvrti pro nižší-střední nebo nižší třídu, používá svářečku, kterou drží v pravé ruce, a v levé ruce drží ochranou masku.
Hodně lidí stojí u fontány pod modrobílým deštníkem.
Žena plete, aby se uživila ve své zemi.
Pouliční prodejce narovnává zboží na stole.
Tři muži stojí okolo vozíku poblíž nějakých motorek.
Bankovní úředník sedí za přepážkou.
Muž v červená bundě s kapucou a v bílé utěrce stojí před malbou na zdi.
Muž se dívá na jeden ze svých čtyř plochých monitorů.
Dva lidé jedou na kole na prašné cestě.
Malá asijská dívenka se špinavým obličejem nese polštář.
Dítě na břehu jezera ukazuje na něco na obloze.
Pár starších kluků hraje na kytary.
Muž v bílém tričku a khaki kalhotách klečí na spadlém kmenu stromu.
Dva chlapci připravují malou loď a dvě dívky se na dívají z pláže.
Starý muž ve středověkém oblečení drží sekeru a stojí na kopci.
Tři lidé jsou na pláži, sedí nebo klečí ve vodě.
Pohled skrz drátěnou mříž na muže ve žlutém, jak stojí u malé boudy.
Dítě váhá, jestli má kousnout do houby.
Dvě ženy v růžových tričkách a modrých džínách si povídají před obchodem s oblečením.
Jízdní policista na strakatém koni si obhlíží dav.
Velký černý pes hrabe hluboko do ve sněhu.
Muž fotí jezero s horami v pozadí.
Bruneta v modré zástěře dojí hnědé zvíře.
Lidé protestují proti věkové diskriminaci na demonstraci.
Dvě mladé dívky hrají basketbal, ta v bílém se snaží zaútočit a ta v červeném brání.
Dáma v bikinách dělá hvězdu na pláži.
Muž v hnědém tričku, šedé vestě a černé čepici hraje na basovou kytaru.
Žena s blonďatými vlasy pije ze sklenice.
Malý chlapec ležící na nemocničním lůžku má přikrytou nohu.
Dva muži ve středních letech s hudebním vybavením spolu mluví.
Pes má otevřenou tlamu, aby ukázal svoje ostré zuby.
Postarší indián a indiánka ve svém příbytku.
Muž leží v hromadě sněhu, která se navršila před vstupními dveřmi domu.
Malá holčička se natahuje, aby si pohladila jelena.
Žena s černými vlasy, který má na sobě černý top a červenou sukni někomu hrozí pěstí.
Muže tlačí na kolečkovém křesle po knihovně.
Dva psi si lehají do sněhu a mají otevřené tlamy.
Žena s milým obličejem vytírá podlahu ve svém obýváku.
Dva hokejisté jsou připraveni zahájit hru tak, že mezi ně rozhodčí hodí puk.
Běžci míjí kontrolní bod ve městě.
Skupina lidí tančí v klubu nebo na party v kostýmech.
Dvě děti připravují na vyjížďku na slonovi.
Adolescent v džínách a maskáčovém triku hraje na černou elektrickou kytaru.
Osoba oblečená ve žlutém kostýmu animované postavičky na veřejnosti.
Plavce v jezeře pozoruje chlapec, který sedí na zdi.
Dav lidí při městské oslavě s kouřem a ohňostroji.
Pes na vodítku se hrabe ve sněhu na venkově.
Skupina kempuje na pustém místě.
Pokladní v černém svetru počítá drobné.
Chlapec si nechává strojkem holit vlasy od jiného chlapce.
Obrázek teenagera, který holí hlavu svému bratrovi.
Turisté si fotí budovu v Číně.
Keramika a auta na parkovišti s mužem v modrém, který se opírá o předek svého auta.
Dva muži za kruhovým barem v místnosti plné lidí.
Muž a ženy čekají, až vlak zastaví.
Děti si povídají a učí se v hodině.
Muž zpívá do mikrofonu, k čemuž mu hraje kapela.
Zpěvák zpívá spolu s davem.
Postarší žena v modrém klobouku sedí na chodníku a krájí vedle sebe něco žlutého na prkénku.
Stavební dělník v černém tričku a džínách si nastavuje žebřík.
Servírka v bílém tričku servíruje hostům v restauraci.
Blonďatý muž v černé fleecové bundě tesá sochu.
Dívka soutěžící v gymnastice předvádí náročný cvik a ohromuje tím obecenstvo.
Umělec pracuje na ledové soše.
Muž v modré bundě jede na spřežení se dvěma psy.
Nějaká kapala nebo orchestr zkouší.
Dva lidé hrají hru čelem k sobě.
Několik dívek si hraje s moukou.
Malá holčička hraje na hudební nástroj a zpívá do mikrofonu.
Muž hraje Punchout Mika Tysona na počítači.
Muž, který vypadá, jako kdyby ho někdo uhodil, leží na zemi mezi odpadky.
Výjev s člověkem odklízejícím sníh a kolemjdoucími občany v zimním prostředí.
Skupina lidí v kostkovaných sukních, černých vestách a košilích s bílými límečky hrají na bubny.
Krasobruslařka v červeném procvičuje své pohybu.
Skupina lidí běžících maraton v zimě.
Žena a chlapec na pódiu se smějí a mají za sebou stany.
Muž v kabátu šéfkuchaře telefonu zatímco dva další muži v zástěrách se smějí.
Holčička jde přes malý potok.
Brunet v hnědém sáčku promlouvá k publiku na zábavném vystoupení.
Dvě děti tančí na tanečním recitálu.
Obrázek ženy a její muže a dítěte, kteří jsou po parkovišti.
Lynyrd Skynyrd na koncertu.
Muž a žena sedí na lavičce a sledují, jak okolo jede loď.
Městská ulice s mnoha čínskými znaky.
Několik lidí spolu tráví čas v místnosti.
Skupina muzikantů hraje hudbu na ulici.
Tento muž vypadá jako, kdyby se snažil o politické prohlášení na rušné ulici.
Dvě děti si hrají na venkovním hřišti.
Muž sedí na schodech u domovních dveří.
Muž v obleku telefonu a jde po rušné ulici.
Muž v bílé zástěře a kuchařské čepici prodává maso na rušné ulici.
Žena stojí a má no sobě žlutozelený šátek.
Postarší Asiatka má na sobě baret, sluneční brýle, žlutý šátek a kostkovaný kabát.
Lidé sedí mezi nějakými sloupy a nějaká osoba jde okolo.
Veterinář a veterinářka vyšetřují obrovského tygra, který leží na zemi.
Dva lidé se dívají na oblečení ve výloze.
Muž s batohem sedí na špinavé zemi a ukazuje na horizont.
Dva muži sedí u grilu, který se leskne.
Žena ve žluté bundě jde za dalšími dvěma ženami.
Muž v kabátě telefonuje na ulici.
Odraz chlapce na kole oblečeném v zeleném tričku ve výloze.
Malá holčička se dívá přes zeď.
Mladý muž si dává něco k snědku u stánku s donuty.
Starý muž sedí v tácem v klíně.
Afroameričan v klobouku, obleku a slunečních brýlích stojí u cihlové zdi.
Tři muži si povídají před starými schody na ulici.
Černí lidé nakupují v obchodě s potravinami.
Muž a dvě děti přechází ulici.
Muž v obleku kouří doutník, čte si noviny a jde po ulici.
Skupina lidí v bílém hraje na kytary.
Pes skáče, aby chytil oranžové frisbee.
Několik lidí stojí na zastávce metra.
Tři děti v kleci.
Dva lidé stojí před budovou.
Starší žena se růžovým deštníkem chrání před sluncem.
Hráč baseballu dělá skluz před chytačem.
Dvě ženy v modrých kostýmech sedí venku na dlažbě s betonovými a dlouhými skleněnými prvky v pozadí.
Dva muži kouří venku vně parku.
Muž v modrém tričku drží ceduli, která říká: "Ale no tak... co je teplejší než čaj."
Žena v zeleném jde rušnou ulicí.
Dvě ženy sedí na stříbrných sedačkách, zatímco čekají na vlak nebo na metro ve stanici.
Dav postávajících na startu maratonu.
Malý chlapec nese zeleno-bílo-červenou vlajku v doprovodu ženy.
Mnoho se lidí se shromáždilo, aby sledovalo dva muže, kteří hrají na nástroj a drží ceduli.
Muž v pruhovaném černobílém tričku fotografuje ženu u fontány.
Dva lidé na betonových lavičkách a debatují nad obědem.
Voják drží kameru a ukazuje dítěti film na kameře.
Muž tlačí křesla na rušné ulici.
Muž venku drží mikrofon a mluví na skupinu lidí .
Dva muži si povídají u zdi s graffiti.
Dívka s pomalovanou tváří v oranžovém svetru stojí se svým doprovodem.
Osoba stojí vedle dřevěného plotu s kvetoucími stromy opodál.
Fit mladá žena kickboxuje s červeným boxovacím pytlem v tělocvičně.
Pracovník stánku s limonádou otevírá krám.
Muž sedí v zářivě barevném zelenomodrém boxu a za ním visí na ulici reklama.
Zápas fotbalových juniorů, kde tři mladíci bojují o míč.
Muž drží na ramenou dítě a lidé chodí okolo něj.
Muž v zástěře stojí před jídle pod menu.
Fotka blondýny na ulici ve zlatém kabátě a růžové minisukni před policejní motorkou zezadu.
Několik účinkujících v bílém oblečení a vínových kloboucích jsou v řadách proti sobě.
Bílá blonďatá žena, která má modrou kabelku, jede na koloběžce.
Žena sedící na veřejné lavičce.
Skupina lidí sedí u stolu venku, pijí a povídají si.
Malá asijská holčička běží k foťáku po dlážděné ulici.
Žena a čtyři děti přecházejí rušnou ulici.
Ženy v domorodých kostýmech spolu zpívají.
Žena mluví k malé holčičce přes stolek.
Žena griluje chutně vypadající jídlo v parku.
Policista pacifikuje muže jehož ruka míří do vzduchu a ostatní policisté se dívají.
Muž v černém tričku zpívá do mikrofonu.
Dva mladí muži v džínách a teniskách přechází městskou ulici.
Dvě dívky se hrají na stromě se svým psem.
Mladá žena s kabelkou se usmívá před budovou.
Muž a žena jdou okolo vody k visutému mostu.
Tři ženy běží bosé po písku do vody.
Mimo sedí na modrém kabrioletu.
Dva muži se dívají na obrazovku notebooku, jeden píše a jeden ukazuje na obrazovku.
Barevný pochod vede muž s červenou vlajkou.
Muž v šedé čepici a tílku v černých kraťasech stojí na rukách.
Žena drží chlapce, když přechází ulici.
Na obrázku je odraz muže a ženy někde na letištním terminálu.
Muž šťastně zvedá promočenou ženu.
Muž s bílým páskem ve slunečních brýlích drží holku za ruku.
Muž jde po chodníku.
Muž v prostém olivovém oblečení se drží nad zemí rukama.
Fotografové připravují dokument.
Muž a žena v černém stojí blízko sebe na ulici.
Lidé se účastní J. P. Morgan Corporate Challenge.
Dívka a chlapec se líbají v sedě na dřevěné lavičce.
Muž v plaveckých brýlích opouští bazén po schůdkách.
Mladá žena oblečená v zelené a červené s mexickou vlajkou namalovanou na tváři.
Cyklista v helmě letí z rampy v lese.
Dvě ženy oblečené v bílém jdou po ulici na vysokých podpatcích.
Indický muž prochází na své cestě na modlitbu kolem chrámu.
Svalnatý černý muž v metru poslouchá ze sluchátek.
Dva muži sedící venku si povídají u cedule "rady zdarma."
Žena v červených šatech se zrzavými vlasy stojí před výrazným barevným domem.
Žena na kolečkových bruslích v přilnavém dresu.
Žena v černých šatech s chlupatými klapkami na uši jde po ulici.
Spoustu lidí v budově, někteří z nich vaří jídlo.
Lidé zkouší z místní pekárny na místním festivalu jídla.
Pohled na ulici, kterou lemují velké, čisté budovy.
Žena s modrými dredy sedí na straně silnice.
Muž ve dresu Denver Broncos a jeho přátelé mají pinkik u auta.
Ženu baví klaun na místním trhu.
Muž ve dlouhém modrém plášti vchází do staré kamenné budovy.
Dáma v zářivé růžové košili táhne vozík s horkým jídlem.
Osoba s dlouhými modrými vlasy stojí za davem lidí.
Skupina lidí na pláži se drží za ruce tak, že tvoří řadu, která se dívá do vody.
Muž v bílém triku hraje na ulici na housle.
Mnoho lidí jde po špinavé silnice, mají na sobě letní oblečení a je slunečný den.
Dva lidé ve spandexových oblecích sedí na židlích v hledišti.
Černý muž s kšiltovkou sedí v autobuse.
Pán vychází z veřejné prádelny.
Muž v obleku a kravatě v nóbl budově na pódiu.
Muž usnul na gauči.
Pět mužů, všichni v bílých pláštích, stojí u jehňat na oploceném prostranství
Dvě vodní vozítka, jedno červené a jedno bílé, hodně cákají ve vodě.
Skupina čtyř lidí se fotí z auta.
Lidé na párty na ulici.
Dvě mokré dívky a za nimi žena s deštníkem.
Žena v bílém drží pugét růží.
Mladá dívka v "pouličním oblečení" a botech předvádí u jezera baletní figuru.
Muž a žena stoupají po kamenném schodišti a dívají se na videokameru.
Čtyři muži oblečení v tričkách a šortkách se dívají oknem na ulici pod sebou.
Několik mužů stojících na alegorickém voze jedoucím davem lidí na ulici.
Neudržovaný zamračený starý muž s bílými vlasy před drátěnkovým plotem.
Muž bez trička dělá trik na skateboardu ve skateparku.
Muž se sluchátky na hlavě prochází kolem zdi s červeno-fialovými graffiti.
Dva muži v sombrerech v New Yorku.
Dáma ve fialovém svršku a bílé sukni se dívá na pochodující průvod.
Člověk jede na motorce z kopce po hliněném kopci.
Žena v žlutém s kočárkem a muž v modré košili s batohem jdou po rušné městské ulici.
Muž v obývacím pokoji uvažuje, co si má sbalit na výlet.
Afroamerická žena sedí u hnědého stolu, má na sobě fialové šaty, růžové boty a černé sluneční brýle.
Muž shrbený na židli na chodníku pozoruje ženu.
Dva muži, jeden prodává ovoce, druhý ovoce prohlíží a baví se s prodavačem.
Muž a žena se objímají na ulici.
Množství lidí v bílém spolu konverzují na stadionu.
Hodně lidí se shromáždilo, aby se podívalo na něco, co není na fotce.
Pár sedí na lavičce a povídá si, v pozadí žena venčí psa.
Dvě ženy v puntíkovaných šatech jdou po chodníku.
Skupina holek si hraje ve vodní fontáně na sluníčku.
Lidé provádí zahradní práce na místech okolo cesty.
Plešatící muž ve slunečních brýlích má na sobě zelené tričko a stojí před budovou.
Bosý chlapec s modrobílým pruhovaným ručníkem stojí na pláži.
Pár a dvě dívky se dívají přes průhledné zábradlí.
Lidé na farmářském trhu si vybírají zemědělské produkty.
Tatér aplikuje tetovací inkoust do kůže.
Žena stojí proti dvěma lidem ukazuje na oblohu.
Pár se prochází uličko v obchodě, který prodává kniho u umění a historii.
Muž se jmenovkou sedí na židli.
Muž v dálce u buddhistického kláštera.
Muž balancuje s kovovou koulí na ruce.
Černošský muž v bílém triku a černé kšiltovce sedí na obrubníku a píše zprávu.
Chlapec v černé košili nese modrý kyblík, když jde vedle muže v bílém.
Mladá tmavovlasá žena s červeným kšiltem drží otevřený deštník v davu lidí.
Muž drží malé dítě, které má batůžek na zádech.
Mladý muž připravuje koule na fialovém kulečníkovém stolu.
Dívky sedí s rukama v klíně.
Holka v černém tílku a kapsáčích vypadá, že tancuje s několika lidmi okolo.
Chlapec a dívka v černých kombinézách stojí proti holčice v růžové bundě a dospělí jsou v pozadí.
Muž a žena tlačí kočárky a jdou kolem lidí, kteří prodávají zboží ve stanech.
Žena v pruhovaných punčocháčích je vedena jako loutka na provázcích.
Stavební dělník v oranžové vestě pokládá dlažbu.
Asijská žena sedí venku u stánku na trhu.
Muž leží v místnosti a několik dní nic nejedl.
Návěs jede po červené dlážděné cestě.
Mladá žena s hnědými vlasy a tílku pořizuje snímek fotoaparátem.
Osoba leží na lavičce před vodní instalací.
Mladý usměvavý muž jde vedle pláže, má na sobě baseballovou čepici, modré tričko a džíny.
Skupina lidí mává člověku na balkóně.
Uniformovaný muž z armády trénuje německého ovčáka s ochranným rukávem.
Dítě na skejtovací rampě trénuje hustý pohyby.
Nějací muži na lodi vypadají, že něco probírají.
Muž v letecké čepici a brýlích sedí na silnici.
Lidé přecházejí ulici lemovanou stromy před budovou.
Muž v šedé košili odpočívá s hlavou na stole.
Muž v bílém triku a tmavých šortkách pracuje venku.
Žena v černých kalhotách se dívá na svůj mobil.
Mladá žena v růžovém tričku se při rodeu snaží chytit tele do lasa.
Rodina stojí venku za mračného dne.
Velice mladé dítě s barvou na těle a na obličeji sedí ve dřezu a hraje si s kohoutkem.
Děti se točí na skleněném kolotoči.
Muž a žena drží protestní cedule.
Žena pracuje o víkendu na své verandě.
Postarší pán v tmavomodrém sedí na lavičce na kraji ulice.
Žena fotí svým foťákem.
Starší muž v modrých džínách a hnědém kabátě odpočívá u oranžové budovy.
Muž s rukou na hlavě sleduje reklamu Bank of America.
Dvě ženy sedí v noci na lavičce před obchodem.
Muž v bílém tričku sedí na přepravce.
Starší tetováním a motorkářskými symboly tráví chvíli na ulici.
Muž sedí sám na pobřeží.
Starší muž sedí venku na lavičce před transparentem, na kterém je napsáno "Memoria Justicia Sin Olvido."
Muž na kole v šedé bundě veze listí.
Kluk s brýlemi v křiklavě žluté košili stojí na parkovišti.
Dva muži jsou po špinavé cestě.
Matka v modrém baretu a bodrých botách se svýma dvěma syny.
Dva psi si hrají s modrozeleným míčem.
Muž v zářivé mnohobarevné helmě sedí na motorce.
Muž dřepí u žluté zdi.
Tohle vypadá jako tržiště s několika stoly s vyskládaným zbožím.
Blonďatý chlapec v modrém tričku sedí se ženou v brýlích.
Muž v elegantní bílé košili hledí ženě do očí a rukou spočívá na zádech jejích černorůžových šatů.
Lidé si hrají za soumraku v kašně.
Čtyři kluci pózují zatímco jeden si odkládá pivo.
Dáma nese zboží na hlavě na frekventované ulici.
Pouliční umělec v oranžové kombinéze jede na vysoké jednokolce a dav lidí okolo se dívá.
Osoba na sedí židli čelem k davu lidí.
Muž čeká na příjezd vlaku na nástupišti.
Tři bílí muži v tričkách skáčou do vzduchu.
Zpěvák dělá stage dive.
Třída potápěčů se fotí během výuky.
Žena v pruhovaném tričku má založené ruce a stojí v obchodu s potravinami.
Nabourané auto s mnoha hasiči, kteří se snaží prostříhat do auta.
Několik lidí čeká na pokladu v obchodě, kde strop vypadá jako ve skladu.
Dvě dívky hrají volejbal, jedna z nich se chystá na smeč.
Starší muž vysypává něco z pytle do vody.
Šest lidí v tělocvičně opravuje kola.
Dva mladí asijští chlapci spolu trénují box.
Žena připravuje ingredince na polévku.
Dva muži v šortkách pracují na modrém kole.
Muž a žena si dávají šlofíka na provizorní lodi.
Muž v jakémsi pytli sjíždí z kopce pokrytého sněhem.
Muž a žena si užívají večeři na párty.
Voják národní gardy zpívá s dalšími vojáky národní gardy státní hymnu.
Dva mladiství jdou šikmou ulicí.
Žena v restauraci pije z kokosu brčkem.
Žena v modré uniformě stojí a dívá se dolů.
Muž v šortkách mluví s dalším mužem v modrých džínách před dřezem.
Muž krmí dítě v dětské stoličce.
Mladý cyklista v helmě a modrém oblečení skáče do vzduchu, když jede přes malé kopce.
Mimino s růžovou čepicí leží nahé a spí.
Dvě děti leží na břiše pod potrubím.
Dva muži si povídají vedle telefonní budky a opodál odpočívají dělníci.
Domorodá žena se věnuje řemeslné činnosti.
Děti honí míč, když hrají fotbal.
Dvě děti skákající venku na zastíněné červeno-modré trampolíně obklopené stromy.
Dva psi na louce se dívají létající talíř, který není vidět.
Bubeník a kytarista mají koncert v temném prostředí.
Trojice lidí pochoduje cestou plnou sněhu.
Skupina lidí vedle malé řeky uprostřed města.
Žena se dívá skrz dalekohled do lesů.
Malá blonďatá holčička v puntíkovaném triku "koupe" svého plyšáka ve dřezu.
Rozcuchaný mladý muž s kroužkem v nose si čistí zuby.
Lyžaři letí vzduchem, zatímco ostatní lyžaři jedu na vleku a dívají se.
Tři děvčata jedou na koních, záběr je na nejmladší z nich.
Rozměrnější žena si fouká vlasy fénem a šťastně se usmívá.
Kuchař v kuchyni zachází s nožem.
Muž stěhuje květiny a žena na něj ukazuje nějaké gesto.
Žena zpívá do mikrofonu a muž v pozadí hraje na bicí.
Muž s čepicí podává ulovenou rybu klukovi ve fialovém klobouku.
Dělník se drží stromu.
Několik lidí stojí kolem mísy, ve které jeden z nich manipuluje s hnědým objektem.
Mnich na kolečkových bruslích se slunečními brýle se modlí, než udělá nějaké tríčky.
Žena, která má na sobě sluneční brýle a modré tričko prodává mušle a dívá se na staršího muže v černé košili a čepici.
Starý muž vytírá podlahu a žena jde směrem od foťáku.
Muž s dredy si hraje s vlasy ženy, která sedí na židli na dlážděné ulici.
Muž pracuje na stavbě.
Muž uprostřed odehrávání červenobílomodrého volejbalového míče.
Muž stojí v pojízdném stánku s jídlem a dívá se okénkem ven.
Hráče baseballu s červenou helmou a bílými kalhotami honí chytač, když běží na domácí metu.
Muž v oranžovém úboru venku zametá.
Muž ve fialovém tričku pracuje v biologické laboratoři.
Muž vede dva malé poníky na procházku v parku.
Dvě ženy, jedna z Německa a jedna z Číny, zápasí na matraci na soutěži.
Muž a žena spí na lavičce.
Muž a žena sedí na zemi před zavazadly.
Obsluha rikši čeká na dalšího zákazníka.
Dvě dívky sedí u stolu a pracují na řemeslných projektech.
Muž běží ve sněhu za pomocí sněžnic.
Tanečník v červeném obleku skáče do vzduchu.
Muž sedí v zaparkované hygienické dodávce.
Vousatý muž v těžké bundě sedí v rohu s papírovým kelímkem.
Muž na skateboardu používá prázdný bazén jako rampu za velmi slunečného dne.
Muž ve velkém klobouku v křoví.
Detail dětské tváře jak jí modré, srdcovité lízátko.
Muž a žena pracují na výměně duše u kola.
Malý chlapec ukazuje svůj hnědozelený korálkový náhrdelník.
Muž v šedém tričku pracuje s měchem, aby rozfoukal oheň v cihlové peci v dřevěném přístřešku.
Žena strojí před stromy a směje se.
Někdo v asijském kostýmu sedí a drží meč.
Mladý hráč amerického fotbalu připravuje míč ke kopu.
Chlápek ve jasně zelené bundě s kapucí přechází silnici a dívá se na nehodu auto a kola.
Mladý muž se chystá kopnout do fotbalového míče.
Závodní běžkyně běží svůj první sprint v soutěži.
Dva muži, jeden v modrém a jeden v červeném, boxují.
Skupina přátel se rozvalila na zem a baví se spolu.
Stojící muž drží mikrofon před muže, který drží kytaru.
Dívka na kolečkových bruslích bruslí s ostatními.
Žena si v obchodě bere pytel ledu.
Dva motorkáři závodí a předhání se v zatáčce.
Muž stojí sám na chodníku a upracuje si čepici.
Beznohý muž jde s jiným mužem, který se přihlásil do maratonu.
Několik lidé se srazilo při fotbalovém zápase.
Dva lidé, jeden oblečený jako jeptiška a druhý v tričku Roger Smith, běží závod kolek diváků v zalesněné oblasti.
Tři muži na koních při závodu.
Muž tmavé pleti s bílými šortkami a černým tílkem obrací svůj skateboard na betonovém povrchu obklopeném výškovými budovami a palmami.
Muž, který má na sobě mikinu s kapucí sedí u fontány a dívá se na lidi ve městě.
Plavci stojí na různých úrovních velkého komplexu skokanských můstků v místnosti s mytologickými výjevy namalovanými na zdech.
Malý indický chlapec sedí a přemýšlí o své budoucnosti.
Chlapec s kapucí hází předmět do špinavého bazénu.
Muži v barevných kostýmech při představení.
Dva boxeři jsou připravení na souboj a publikum s očekáváním přihlíží.
Děti hrají sport na hřišti.
Umělkyně zpívá a hraje na kytaru před mikrofonem.
Chlapci soutěží v bojovém umění.
Skupina černochů v oranžových tričkách vystupuje před oploceným parkem.
Školní dívky v uniformách pochodují na přehlídce a hrají na nástroje, co vypadá jako flétna.
Muž plní drůbež přísadami z modré misky.
Kluk skáče z postele v karatistickém kopu.
Mimino v chodítku a stojící chlapec obklopeni hračkami.
Lidé shromáždění u stolu hrají hru Jenga.
Muž s plnovousem a postarší žena jí z jedné misky.
Mladý muž skateboarduje na betonové zdi.
Lidé jedou na loďce na jezeře se sluncem a mraky v dálce.
Dva muži v kimonu trénují bojové umění.
Chlapecká kapela a vůbec k sobě nepasují, měl by poslat poznámku.
Skupina jezdců v motokárách závodí na trati.
Člověk oblečený v zimním oblečení pózuje se sněhulákem, obklopený zasněženou krajinou.
Muž prezentuje před publikem.
Muž ve středním věku zavazuje koleno mladému hráči amerického fotbalu, jenž sedí na trenérském stolu.
Potetovaný muž v kombinéze drží mikrofon na pódiu.
Malá dívka si hraje s drobným elektrickým obvodem se třemi žárovkami a baterií.
Muž v modré helmě se na kole připojuje do provozu.
Hodně mladých dospělých soustředěně zírá do svých počítačů, když soutěží v počítačové hře.
Malý chlapec v zeleném žongluje na parkovišti.
Malá holčička v puntíkovaných šatech se otáčí na ženu v černých šatech.
Muž spravuje motor z lodi u vody.
Tenisový zápas, který se hraje uprostřed stadionu.
Dítě na snowboardu zastavuje.
Hraje se kopaná a dva muži se snaží dostihnout míč dříve než ten druhý.
Mladé ženy a děti ve vesnici, jedna z nich je otočená k fotografovi.
Batole v zeleném tričku si čistí zuby žlutým kartáčkem a maminka na něj dohlíží.
Muž na vozíku v červeném běžeckém oděvu nese pochodeň.
Syn a jeho rodiče se fotí v kostele.
Tři muži závodí v běhu přes překážky.
Dva muži pozorují dalšího, jak dokončuje práci s mokrým betonem.
Voják pozoruje horskou krajinu dalekohledem.
Skupina hochů závodí za sněžného dne.
Muž skáče přes švihadlo a dívá se na něj dav lidí.
Malý chlapec a dívka se společně smějí, když dívka ukazuje gesto rukou.
Dva muži z různých týmů honí fotbalový míč.
Cyklista ve žlutém tričku předvádí ve vzduchu neuvěřitelný tríček.
Dvě kickboxerky, jedna ve fialové sportovní podprsence, spolu bojují v aréně.
Dva muži na rychlých motorkách sviští zatáčkou závodního okruhu.
Dva muži brání dalšího muže, když hrají basketbal za soumraku.
Muž v jezdeckých botách a helmě jede na bílém koni a kůň skáče přes překážku.
Skupina mužů v kostýmech hraje na hudbení nástroje.
Muž a ženy procházejí přepravky plné desek nebo obrazů na prodej.
Závodní katamarán má zvednutý trup ve vodě.
Skupina námořníku jde s americkými vlajkami a dalšími vojenskými vlajkami.
Muž drží skleničku před fotografem.
Jeden muž hraje na kytaru na pódiu se světly v pozadí.
Čtyři děti se hrají s prázdnými kanystry.
Skupina dělníků poslouchá kolegovy instrukce.
Zednář řídící velký zelený traktor jede v průvodu po silnici.
Tři psi si hrají ve vodě.
Muž hraje na buben a malý kluk na svůj vlastní, malý buben.
Skupina dívek hraje hru na koních.
Muž se dívá na ženu, jak s úsměvem střílí z pistole na střelnici.
Vedoucí cyklista šlape jako o život, zatímco soupeřící země jsou těsně za ním.
Tým hráčů kopané v hloučku probírá vážné věci.
Skupina lidí ve fialových tričkách a světle hnědých kalhotách jdou stejným směrem.
Muž ve světlé košili hraje na trumpetu.
Chlápek s džínovými šortkami dělá ve skate parku triky na kole.
Matka a dcera mají na sobě kostýmy z Alenky v říší divů a pózují na fotku.
Malý chlapec vrtá díru do kusu dřeva.
Dva cyklické spolu závodí za špinavé dráze.
Někdo hází frisbee dívce, zatímco si o něj, zdá se, říká druhá dívka.
Ortodontista pracuje s pacientem a muž drží světlo.
Dva lidé jí hamburgery na venkovních židlích a třetí pije limonádu z plechovky.
Dva cyklisté jedou po ulici okolo lidí a povídají si.
Na bowlingové drží muž v černém tričku bowlingovou kouli a dívá se na dráhu.
Dva muži v černém oděvu s modrým a červeným motýlkem vystupují před lidmi.
Dva muži, jeden černý jeden bílý, stojí venku a hrají na kytary a zpívají do mikrofonů.
Kickboxer přistává kolenem do tváře protivníka.
Tři lidé běží závod na červené běžecké dráze.
Fotbalisté mají potíže dostat se přes pevnou linii.
Několik mužů se modlí, když stojí u stolu plného jídla.
Dvě indická děvčátka ve formálních kostýmech nadšeně předvádí rituální tanec.
Tři děti stojí u sebe u vysokého modrého dřevěného sloupu.
Skupina lidí běží.
Ženy jsou po pláži, nesou prkna a ploutve.
Chlapec sedí na skále a dívá se do údolí pod sebou.
Žena stojí na vysokém útesu na jedné noze a dívá se přes řeku.
Bruneta stojí na chodníku a dívá se na silnici.
Skupina tří přátel doma konverzuje.
Dva Číňané stojí u tabule.
Osoba s modrými džínami a červenou mikinou jde za roh cihlové zdi.
Rolníci se věnují zemědělství v průběhu dne.
Nějaký karneval, muž dělá cukrovou vatu.
Hodně policistů stojí před autobusem.
Starší bělovlasá žena se dívá své poklady a dívá se přes brýle.
Dva muži stojí ve venkovních telefonních budkách.
Dvě ženy v červeném oblečení a muž vycházející z mobilního WC.
