Muž v oranžovém klobouku na něco zírá.
Bostonský teriér běží po zářivě zelené trávě před bílým plotem.
Dívka v uniformě na karate, která předním kopem láme dřívko.
Pět lidí v zimních bundách a s helmami stojí ve sněhu, se zasněženými skútry v pozadí.
Lidé opravují střechu domu.
Muž ve světlém oblečení fotografuje skupinu mužů v tmavých oblecích a v kloboucích stojících okolo ženy oblečené v šatech bez ramínek.
Skupina lidí stojící před iglú.
Chlapec v červeném dresu se snaží, aby se nevyoutoval na domácí metě, zatímco se chytač snaží chytit míček.
Chlapec pracující na stavbě.
Muž ve vestě sedí na židli a drží časopisy.
Matka a její mladý syn užívající si krásný den venku.
Muži hrající volejbal, jeden hráč minul míč, ale ruce má stále ve vzduchu.
Žena, která drží misku s jídlem v kuchyni.
Muž sedící u stolu v jeho domě používá nářadí.
Tři lidi sedí v jeskyni.
Dívka v džínových šatech, která jde po kladině.
Blondýna drží ruku chlápka v písku.
Žena v šedém svetru a černé kšiltovce stojí ve frontě v obchodě.
Osoba v pruhovaném triku leze po horách.
Dva muži předstírají, že jsou sochy, zatímco se na ně dívají ženy.
Lidé stojící před budovou.
Teenager hraje na svoji trumpetu na utkání na hřišti.
Žena dělá salto na trampolíně na pláži.
Muž stojí u automatů s videohrami v baru.
Žena používá vrtačku, zatímco si ji další muž fotí.
Žena v růžovém svetr a zástěře, která čistí stůl houbičkou.
Muž řezající větve stromů.
Skupina asijských chlapců čeká až se jim ugriluje maso.
Ženy v národních krojích předvádějí domorodý život.
Jeden muž drží hlavu druhému muži a chystá se jej uhodit do obličeje.
Šest lidí jedoucích na horských kolech uprostřed džungle.
Dvě blonďaté dívky sedí na římse na přeplněném náměstí.
Dítě se cachtá ve vodě
Tři lidé sedí u piknikového stolu venku před budovou pomalovanou britskou vlajkou.
3 chlapci v plavkách stojí na molu.
Zaměstnanec podává ženě tašku zatímco ona si prohlíží ryby na ledě na pouličním trhu.
Krásná žena hraje na cembalo.
Venku před budovou stojí strážník v uniformě a dívá se na kameru zpoza plotu.
Mladá dáma hledí na pizzu.
Muž bez trička a v šortkách rybaří, zatímco stojí na nějakých kamenech.
Dívka v záchranné vestě pluje po vodě.
Muž v uniformě a muž v modré košili stojí před kamionem.
Lidé sedí uvnitř vlaku.
Dítě se v lese houpe a má nohy do vzduchu.
Muž v červeném tričku vchází do podniku.
Dva muži, kteří na sobě mají bermudové plavky, skáčou na přiměřeně zalidněné pláži.
Batole vaří s jinou osobou.
Otec a dvě děti před jejich domem pracují na zahradě a na příklad používají motyku a sázejí strom.
Muž vaří na sporáku jídlo.
Muž v džínách na pláži si hraje s červeným míčem.
Lidé, kteří jdou po chodníku vedle řady obchodů.
Wakeboarder předvádí salto během toho, co je vlečen ve velké rychlosti.
Velká skupina lidí zaplňuje ulici.
Muž na lanovce vedoucí do vody.
Žena v džínách jde kolem autobusu, na němž je vyobrazená reklama se ženou, která se dívá přes své sluneční brýle.
Muž v růžovém triku sedí na trávě a ve vzduch je balon.
Auto zaparkované na pláži.
Dva muži v černém ve městě
Muž ve žlutých kalhotách zvedá nahoru ruce.
Dva muži, kteří mají kšiltovky a vycházkové hole, se prochází u vody při západu slunce.
Roztlečkávačský tým předvádí sestavu na židlích.
Chlapec hraje dámu s dospělým, který není v záběru zatímco je pozoruje dívka.
Dav lidí se baví ve veřejném parku.
Muž, který sedí na lavičce, drží svého psa a dívá se na vodu.
Chlapec a jeho mladší bratr, kteří si spolu hrají na hřišti.
Žena v modrém nahlíží do kožené taštičky, sedí na lavičce za slunečného odpoledne, zatímco kolem ní prochází lidé a za ní projíždí limuzína.
Hnědý pes stojí na pískové pláži.
Žena sedí s košíkem oblečení a je obklopená oblečením.
Muž griluje vzadu na dvorku.
Žena zpívá v klubu s kytaristou za ní.
Kytarista, který vystupuje v nočním klubu s červenou kytarou.
Dítě sedí na zahradním lehátku se kouká na kameru.
Dvě ženy a tři muži se dívají na oceán.
Interpretka s houslemi hraje na ulici zatímco ji pozoruje žena s modrou kytarou.
Mladá dívka plave v bazénu.
Několik dětí se venku připravuje na bitvu v přetahování o lano.
Tři náctiletí dovádějí v metru.
Hnědý pes s jazykem visícím ven kráčí v trávě.
Lidé sedící na trávě mimo budovu, kteří odpočívají.
Muž bez trička zírá do dálky zatímco tři ženy procházejí okolo davu sedícího na zahrádce restaurace.
Dva chlapci nandávají ovoce na kolo.
Muž v černém tričku, čepici a džínách hraje na vzhůru nohama položený žlutý kbelík.
Mladá umělkyně maluje obraz ženy na zeď.
Dvě spoluhráčky týmu USA skáčou do vzduchu a u toho si plácají a kolem nich jsou dvě další spoluhráčky.
Muž míchá hrnec s tekutinou v této kuchyni.
Chlapec wakeboarduje na jezeře.
Muž, který pracuje u stánku s párky v rohlíku.
Velká skupina lidí různého věku a pohlaví sedí venku pohromadě.
Blonďatá žena nalévá drinky na baru.
Malé dítě v modrobílém tričku radostně drží hračku žlutého plastového aligátora.
Žena s růžovými vlasy oblečená v černém mluví s mužem.
Muž v japonském kuchařském oděvu připravuje jídlo pro dvě osoby.
Dívka přeskakuje přes řeku z kamene na kámen.
Dělník s krabicí nářadí klečí vedle dvou žen.
Starší muž otevírá svou náruč a vypadá zmateně.
Dítě v karate obleku trénuje jakýsi pohyb
Tři lidé ve stejně barevných vestách jsou venku.
Žena fotografuje dítě s růžovým kloboučkem, zatímco jej muž nese.
Skupina převážně asijských dětí sedících v kabinách na modrých židlích.
Malý chlapec ve fotbalovém dresu si brečí do dlaní.
Šťastná žena připravuje v kavárně občerstvení.
Dělník řídí těžké vybavení na stavbě.
Žena se rozebíhá po tom, co trefila míček v ženském softballe, chytačka se staví na nohy.
Muž v pracovní uniformě podává nástroj další osobě.
Skupina lidí leze v chladném počasí.
Horolezec v modré helmě, který se chystá slaňovat ze skály.
Muž dělá stojku na vršku zakulacené sochy.
Dítě sedí v restauraci a drží si papírovou masku před obličejem.
Hnědý pes brodící se v jezeru, aby aportoval klacek.
Matka učí své dva chlapce rybařit na skalnatém pobřeží u velmi modré vody.
Malé dítě se prochází vedle červených transparentů.
Dívka sedí s mladším chlapcem na ozdobeném kole, zatímco další dívka je fotografuje.
Černý pes aportuje balonek ve vodě.
Muž v bílých kalhotech a modrém tričku kope do žlutého boxovacího pytle.
Dva indičtí muži se účastní ceremonie.
Chlapec s odřeným nosem a popsanýma rukama stojí ve videopůjčovně.
Dvě siluety lidí při západu slunce pádlují na kánoi po oceánu.
Lidé stojí v přeplněném metru a skrze okno je vidět na peron.
Muž leze po zdi s ohněm v ruce
Dva hnědí psi běží sněhem.
Fotografie z pódia malé kapely účinkující pro divadelní publikum.
Dítě ve vánočním oblečku se dívá na kameru.
Muž sedí u monitoru od počítače.
Tato žena slyšela srandovní vtip a směje se.
Lidé uvnitř budovy, jeden z nich fotografuje.
Čtyři bílí psi s náhubky skáčou přes červenou zeď.
Žena v modrém triku drží dítě.
Dva lidé sedí na pruhovaných lehátkách ve vodě a u toho rybaří.
Stará žena pracuje na tkalcovském stavu a vyrábí látku.
Na popředí stojí chlapec a dívá se na lidi na náměstí.
Muž v modrém kabátu, který popadl mladého chlapce za rameno.
Tři hnědí psi skáčou na ženu v modrém.
Chlapec visí z okna projíždějícího taxi
Muž v šedém triku přeskakuje přes vrchol písečné duny v poušti.
Dítě ve žlutém tričku skáče nahoru a dolů.
Dělník ve žluté bundě je vyzdvižen vysoko nahoru k opravě budovy.
Muž v Brazílii neformálně promlouvá k mladým dospělým.
Spousta pivních píp na baru s vánočním osvětlením na stropě.
Muž se slaňuje dolů z útesu nad oceánem.
Muž v černím kráčí ke svému náklaďáku ve sněhu.
Foxteriér skáče po míčku.
Policistka v čepici a tmavě modré uniformě se usmívá a má na sobě sluneční brýle před obchodem.
Rodina na procházce v parku.
Muž v zelené helmě a žluté bezpečnostní vestě se mračí.
Dítě s růžovými provázky na hlavě tancuje a je obklopeno konfetami a balonky.
Pes se spláclým čumákem něco čuchá na břehu řeky.
Muž připravuje místní stánek k dennímu obchodu.
Muž v červeném tričku se chystá jíst tacos.
Mladá žena v bílém drží tenisovou raketu
Chlapec v červeném tričku kope do písku díru žlutou lopatkou.
Individuum v růžové bundě nečinně sedí na dřevěné lavičce.
Muž v bílé košili se dívá ven z okna s kovovou konstrukcí.
Žena drží malou bílou sošku.
Šest dětí bez triček si hrají v přírodní vodě a cákají kolem sebe.
Dva lidé jedou na kolech přes horskou krajinu.
Dívka skákající přes švihadlo na chodníku vedle garáží.
Muž mající na sobě oranžové tričko a helmu.
Malý chlapec si hraje s plastovými kostičkami, auty a zvířátky a pozorně na něj dohlíží dospělá osoba.
Malá dívka otevírá vánoční dárek.
Žena v modrém nastavuje fotoaparát před dalšími dvěma ženami.
Malá dívka odpočívá na pohodlné sedačce.
Hnědočerný pes běžící po lesní cestě.
Dva psi si hrají u stromu.
Námořník kráčí po schodech, má na sobě černý kabát a kalhoty a fotoaparát je zaměřený na psa
Dva muži v zeleném připravují jídlo v restauraci.
Muž oblečený v černé kůži a kovbojském klobouku prochází okolo renesančního festivalu.
Pes běhá venku se žlutou hračkou.
Pes v pokrývce utíká sněhem.
Rodina si hraje na pláži se svým psem.
Žena a dítě se objímají a dítě ochutnává, co udělali.
Dva muži a žena stojí venku.
Skupina mužů táhne z vody loď za pomocí kmenů.
Muž pije ze sklenice na víno zatímco si čte noviny.
Muž v černém hraje na piano.
Mladý chlapec oblečený v modrém dresu a žlutých šortkách hraje fotbal.
Muž stojí na kamenné konstrukci a ruce má roztažené jako pták.
Pes pije vodu venku na trávníku.
Dvě ženy v tílkách se dívají na kameru.
Muž sedí na holičském křesle a je připraven k holení.
Dítě v zelených botách si hraje v bahnité louži.
Muž používá motorovou pilu k nařezání dřeva.
Muž sedící u piknikového stolu, na kterém je tác a upité pivo.
Chlapec v černém triku a modrých džínách drží červenou baseballovou pálku.
Muž, který má tmavě hnědé vlasy, vousy, brýle a na sobě hawajskou košili sedí na trávě.
Psi utíkají po závodní dráze.
Osvětlovač s klanovými tetováními míří reflektorem přes balkon.
Dva němečtí ovčáci na sebe vrčí.
Toto je skupina postávajících lidí na jakési události.
Hnědobílý pes chytá hračku.
Muž s bílými vlasy hraje na akordeon mezi budovami.
Žena s hnědými vlasy sedí na lavičce před kavárnou.
Muž vedle cyklistické stezky hraje na panovu flétnu.
Dvě děti balancují na kládě a drží lano.
Muž na motorce předvádí trik na závodní dráze.
Mladá žena s fialovou látkou zakrývající její obličej odpočívá na dřevěném mole.
Žena v hnědém tričku sedí na zářivé červené lavičce.
Pes kráčí po kmeni přes malou řeku.
Mladý muž má na sobě bílé tričko a zelenočerní kraťasy a stojí na patníku.
Skupina lidí je celá schovaná pod deštníky.
Muž inzeruje obrovskou cedulí přidělanou na kolo.
Muž hází klacek do vody zatímco ho pozorují dva psi.
Skupina starších hrají na hudební nástroje pod stanem u vody.
Pohled na přeplněnou ulici.
Mladá blonďatá žena drží bílý provaz za slunečného dne.
Dva lidé v modrých tričkách stojí venku s megafonem.
Černý pes, který se noří do bazénu.
Kovboj jede na hřbetu divokého koně během soutěže.
Pracovníci na železniční trati provádějí údržbu kolejiště.
Dělník v oranžové vestě používá lopatu.
Dva stavebníci o něčem diskutují na stavbě.
Tři muži jdou nahoru do kopce.
Asiatka v květovaných svatebních šatech pózuje na mostě poblíž jejích družiček.
Mladý muž ladí svou kytaru v kuchyni.
Tři chlapci si hrají s houbami a kyblíky s vodou.
Tři dělníci opravují chodník.
Lidé chladící se v lese vedle kanoí.
Sbor je shromážděn v kostele.
Skupina mladých náctiletých v noci skáče a na kameru dělají vtipné pózy.
Dva chlápci na kajacích na potoce, jeden oranžový, druhý modrý.
Dva dělníci roztírají cement po cihlách budovy.
Dáma v načervenalém svetru a džínách sedí s rukama na levém koleni
Dva účinkující rádoby bojují před diváky, kteří je pozorně sledují.
Voják odpočívá a čeká na letišti.
Muž ve žlutém kabátě se snaží rozdělat oheň a chlapec v parce přihlíží.
Muž a chlapec na skalnaté pláži.
Žena na lodi jménem El Corazon spouští do vody černé závaží.
Chlapec sedí a dívá se skrze mikroskop.
Malá bosá holčička v růžových šatech skáče po venku.
Mnoho lidí sedí venku okolo stanu.
Mladík s černým tričkem s nápisem "Asian Pacific 2007" hraje sedíc na bubny.
Muž prodávající předměty poblíž cesty vedoucí k velké hoře kaňonu.
Dívka ve žlutém se směje dívce v oranžovém, zatímco je pozoruje dívka v modrém.
Pes, který skáče přes venkovní překážku.
Pes s černým obojkem se válí v hlíně a uschlém listí.
Dva hnědí psi si hrají drsným způsobem.
Muž s knírem a bradkou drží obří pánev, ze které šlehají plameny.
Muž mající na sobě dobové oblečení zvoní zvoncem.
Muž v černé košili rybaří na skalnatém pobřeží.
Dva psi se k sobě tulí čumáky.
Dva lidé se zastavují k rozhovoru na chodníku a kolem projíždí auto.
Číňan, který sedí a čeká na zákazníky.
Zaparkovaná auta a za nimi školní autobus.
Dvě ženy mají na sobě obdobná trička a kráčí doleva.
Malé dítě má na sobě oranžovou záchrannou vestu a vesluje na modrém kajaku po vodě.
Lidé, kteří jdou po cestě v parku plném stromů.
Tři mladí lidé si povídají v davu lidí a ta žena vypadá rozrušeně.
Žena a dítě před vchodovými dveřmi jejich malebného domova.
Černý muž a jeho dva bílí kamarádi si k sobě dávají blízko hlavy.
Dívka v maskáčích sedí na střeše Hummera.
Světle hnědý pes běží nahoru.
Chlapec pózuje s velkým zeleným hmyzem na nose.
Plešatý muž, který předvádí, jak vysoko vyskočí jeho černohnědý pes.
Dav na rušné třídě za bílého dne.
Anglický chrt s košíkem ve žlutočerném běží po závodní dráze.
Muž má na sobě sandále a sedí na chodníku u tašek.
Muž a žena sedí u plotu a povídají si.
Dítě si prohlíží kávovary uvnitř obchodu.
Muž pije ze žlutého kelímku a kolem jsou lidé během rušné události
Chlapec se opírá o auto s květinami na kapotě.
Žena v květovaných šatech mluví před dodávkou s dítětem.
Muž během jeho svatebního dne.
Mladá žena v černém triku a džínách zametá.
Žena v klobouku leze po útesu poblíž velké masy vody.
Velký černý pudl běžící po trávníku s hračkou v tlamě.
Chlapec v šortkách dělá trik na skateboardu.
Malý chlapec oblečený v červených kalhotách stojí na ulici.
Žena textuje na mobilu a je obklopena deštníky.
Osm mužů hrajících na nástroje na podiu, s kytaristou, který je zvýrazněn světly.
Muž v oranžovém obleku a ladící helmě pomáhá s modrou hadicí
Muž a dvě dívky se chlubí rybou zatímco drží rybářské pruty před vodním útvarem.
Muž v červeném triku sledující psa na agility dráze.
Chlapec mající na sobě červenobílé plavecké bermudy skáče pozadu do krásného bazénu.
Asijská žena si přišpendluje vlasy dozadu.
Starší žena a malé dítě v růžovém si hrají s pestrobarevnými kostkami.
Malý černý pes skáče přes branky
Hnědovlasý muž v zelené košili hraje venku na trumpetu.
Muž mluví do telefonu s nohama nahoru.
Skupina dětí sedí na modré matraci zatímco jedí z misek.
Černý chlapec sedí v písku.
Malý pes pronásleduje dva velké psy hrající si na poli.
Lidé sedí v kruhu před velkou budovou.
Jeden pes, který skáče pro softballový míček, zatímco druhý jej sleduje.
Blonďaté dítě se houpe na houpačce.
Jeden muž a dvě ženy diskutují u bílého vína
Asiat vaří jídlo venku.
Hnědý pes chytá zelený létající talíř.
Fanoušci povzbuzují během toho, co kapela hraje píseň.
Malý chlapec stojí u písečné sochy pyramidy.
Tři mladé děti se procházejí po travnaté zahradě.
Muž tluče na umělecké dílo posazené na vozíku.
Muž na kole jede po hoře.
Chlapec v modrobílých holínkách běží po hlíně.
Žena v oranžové bundě sedí na lavičce.
Muž předvádějící trik na skateboardu.
Muž v obleku na bojové umění ve výskoku.
Žena na chodníku prodává pytlíky ovoce.
Dva fotbalové týmy na hřišti.
Dítě v modrém tričku skákající z lavičky.
Brankář ve žlutém poli chrání bránu.
Skupina mladých lidí pije panáky v mexickém prostředí.
Mladý muž jede na skateboardu po růžovém zábradlí.
Malý chlapec skáče z palandy na menší postel.
Dva lidé na sobě mají zvláštní kostýmy mimozemšťanů, jeden modrý, jeden fialový a stojí na silnici.
Muž běží v modrém triku, na kterém je přilepené číslo.
Asijská pracovnice v továrně pózuje na kameru.
Muž který vypadá, jako když běží maraton, zvedá nahoru oba palce.
Basketbaloví hráči střílí na bránu během hry.
Hráč amerického fotbalu má na sobě oranžový dres, usmívá se a drží míč.
Dva sjezdoví skateboardisté vybírají zatáčku, zatímco je ostatní sledují.
Družstvo v bílozlatém na kraji hřiště na americký fotbal.
Malá dívka tlačí svou koloběžku po travnaté ploše obehnané stromy.
Skupina asijských dětí oblečených v bílých tričkách a čepicích předvádí zatímco se na ně dav kouká.
Chodci jdoucí po ulici se dívají na dítě v kartonové krabici.
Hnědý pes běží po písečné pláži.
Dva muži ve vojenských uniformách stojí vedle ženy.
Dalajláma během recepece, na kterou si účastnici přinesli karafiáty, slunečníky a modlitební praporky.
Cyklista skáče na překážku.
Pár sedící na bílých zahradních židlích se usmívá na kameru.
Mladé děti jedou v malém vláčku.
Surfař v modrých plavkách jedoucí na vlnách.
Chlapec skáče na svého bratra fotbalistu.
Dva mladí muži opačných fotbalových týmů soupeří o balon na fotbalovém hřišti.
Lidé kráčí po dlážděném svahu obklopeném čínskými prodavači.
Malý chlapec v bílých kalhotech skáče z gauče.
Chlapec v oranžovém tričku vysypává z pytlíku lego.
Žena má na sobě hnědé sandály, modré džíny a bílé triko a drží dítě pod stromem.
Tři lidé se usmívají a drží cedule s politickými nápisy.
Strážník stojí na silnici vedle auta.
Dva muži v čepicích.
Chlapec ve vzduchu se snaží kopnout do fotbalového míče
Mladý chlapec v modré čepici má skloněnou hlavu.
Zrzavý muž s dredy sedí a hraje na akustickou kytaru.
Muži, který jí sendvič, s jeho dcerou na klíně.
Afroamerické dítě drží něco, na co jsou ostatní na té fotce pyšni.
Žena řídí dav lidí za pomocí megafonu.
Diváci v převlecích se koukají na policistu v uniformě, který řeční a muž v obleku drží mísu s ovocem.
Dav v baru.
Dívka v bílém a dívka v zeleném jdou okolo modré myčky na auta.
Muž používá elektronické vybavení.
Osoba surfující skrze lámající se vlnu oceánu.
Voják něco vyšetřuje.
Nevěsta a ženich se líbají pod nevěstiným závojem.
Pořádková policie stojí v pozadí zatímco mladý muž s červeným šátkem zakrývajícím obličej kráčí.
Černobílý pes skáče přes překážky na soutěži
Žena mající na sobě svetr si čte doma knihu.
Několik náctiletých se dívá přes zábradlí v tmavé místnosti.
Muž v bílém triku právě leze na skálu.
Náctiletý chlapec se protahuje v kuchyni a je mu vidět kus břicha.
Lidé drží různé druhy paliček na buben nad různými druhy bubnů.
Tři farmáři sklízí rýži na rýžovém poli.
Dvě ženy a muž se koukají na knihu.
Nohy tří dětí zobrazeny kousek od nepořádku způsobeným stříkacími party špagetami ve spreji.
Kuchař pózuje na kameru zatímco vaří.
Mnoho lidí na ulici protestuje proti užívání uhlí v elektrárnách.
Teenager skáče z kopce na kole.
Malá holčička běží po pobřeží.
Bílá kachna ve vodě mává křídly.
Zdá se, že dva muži konverzují, stojí za zády ke kamionu a před jakýmsi kovovým předmětem, zatímco čtyři lidé stojí kolem nich.
Žena v růžové sukni drží miminko.
Hokejový hráč ve žlutém dresu chrání bránu.
Muž jde okolo velkého nápisu E.S.E. Electronics.
Tři chlapci mají na sobě zelené košile a světle hnědé kalhoty a pózují na vrchu klouzačky.
Muž tancuje se psem mezi nohama.
Bílý pes běží v mělké vodě.
Oregonští bubeníci kráčí s kapelou.
Skupina dětí si hraje na oploceném dvorku a dospělý se na ně dívá.
Skupina žen spolu hraje na hudební nástroje.
Malá dívka ve fialových kostkovaných šatech leží na podlaze a pláče.
Muž se šedivějícími vlasy si holí vousy.
Dva černí psi, jedno černé štěňátko a bílý pes ve sněhu.
Muž v basketbalovém dresu Miami skáče do střelby.
Žena sedí venku před domem s modrými dveřmi a užívá si vzduchu.
Děti sedí na mužovi v kostýmu banána.
Šedobílý pes skáče přes stojatou vodu v písku.
Dav lidí shromážděn za deště okolo vodní fontány v parku.
Několik starších mužů, někteří v tradičních pokrývkách hlavy se scházejí na rohu ulice.
Mladý pes vypadající jako Lassie je ve sněhu.
Fotbalový hráč mající na sobě zlatý dres blokuje balon hráči soupeřícího týmu.
Žena v černém triku plete z fialové příze.
Čtyři ženy asijského rodu na sobě mají zlaté šaty při baletění na špičkách.
Osoba hraje na jedinečný nástroj.
Žena v černém sportovním oblečení s číslem 1103 na dresu běží přes trávu.
Dítě na běžkách má na sobě číslo 93.
Starší muž a malá dívka spolu začínají stavět puzzle.
Filmový štáb natáčí mladého afrického chlapce ve žlutém tričku.
Osvětlený most s cyklistou a auty.
Muž na býkovi v býčí ohradě.
Chlapec skáče, aby strefil tenisový míček se svou raketou.
Děti lezou na zeď a dva další lidé na ně koukají.
Lidé procházející se po univerzitním kampus s palmami v pozadí.
Malá dívka nakopává předmět na hodině karate.
Dva muži se snaží vyhoupnout z vody nahoru na chodník udělaný z pneumatik.
Dva muži dělají breakdance a dav se na ně dívá.
Profesionálně oblečená žena stojí u stupínku a debatuje či diskutuje o něčem důležitém.
Žena leží na pohovce a směje se.
Prachová podlaha je zametána jednou bílou a jednou černou ženou.
Jelen skáče přes plot.
Tři psi si spolu hrají venku na poli.
Dvě malé děti jsou na písku.
Usmívající se malý chlapeček si hraje v listí poblíž kachen.
Tito čtyři lidé stojí venku se třemi psy.
Průvodce ukazuje směrem k dalším atrakcím při návštěvě májských trosek.
Dívka má na sobě tričko s nápisem "radio" a má otevřenou pusu
Skupina kmene plní vodní kanystry v poušti.
Muž stojící na ulici.
Hejno ptáků letí pryč se žrádlem v zobácích.
Dva muži jedou na vozíku taženém mulou přes zemědělskou půdu.
Dva lidé stojí na vrcholu hory.
Mladá dívka se baví tím, že dělá anděla ve sněhu.
Tři muži smějící se na kameru ukazují svoje svaly.
Osoba píše na tabuli v prázdné třídě.
Muž v černé košili sedí u stolu s před sebou otevřeným Apple laptopem.
Čtyři lidé relaxují na travnatém vršku s výhledem na skalnaté údolí.
Chlapec na skateboardu skáče do vzduchu podél kolejiště.
Muž v oranžové košili hrající tenis.
Pes v červeném obojku cení zuby na psa v modrém obojku.
Chlapec si venku užívá letní den.
Dělník v oranžovém obleku klečí a prohlíží nějaké strojní zařízení.
Muži v kovbojských kloboucích stojí okolo rodea.
Dva psi ve sněhu a jeden z nich má něco v hubě.
Zaměstnanec si dává pauzu od práce a pije nápoj
Béžový pes běží za bílým psem, který drží žlutou hračku.
Hokejový hráč v bílém dresu s holí
Muž má na sobě bílé triko a zlaté hodinky a ovládá desku s plošnými spoji.
Černý kůň strká hlavu skrze plot, aby dosáhl na trávu.
Feťák závislý na cracku předstírá, že si zahřívá ruce, ale doopravdy kouří crack.
Dva chlápci a žena se smějí.
Dítě se naklání přes výstavku s modrým a žlutým plastem, zatímco dospělý přihlíží.
Černobílý pes běžící pro vyfouknutý balon ve sněhu.
Malá dívka stojí vedlé světlé kočky na kuchyňské lince.
Dvě děti si hrají na hřišti.
Tenisový hráč v zeleně pruhovaném tričku si drží ruku před pusou.
Chlapec v červených plavkách si hraje ve vodě.
Dítě mající na sobě červenou bundu a čepici drží velký kus sněhu.
Dva strážníci v oranžových vestách stojí venku před bílým stanem s diváky.
Dva lidé stojí na zemi vedle stromu.
Dva muži sedí a povídají si poblíž kamenné budovy.
Hnědovlasé dítě s brýlemi drží blonďaté dítě v červeném svetru a žlutých botách.
Černobílý pes si hraje s bílým míčkem.
Dva lidé se líbají na chodníku před limuzínou, zatímco okolo chodí lidé.
Žena hraje volejbal.
Dva velcí psi se rvou na hliněném poli.
Hnědý pes skáče přes překážku.
Muž v pruhovaném triku kouří cigaretu na ulici
Malá holčička na svém klíně drží malého chlapce.
Muž se snaží jet na velmi rozzuřeném býkovi během krásného sobotního odpoledne.
Děti bojují, aby zvítězily v přetahování lanem.
Cyklista na horském kole se naklání do zatáčky na hliněné stezce.
Dva lidé a kráva uvázaná u domu.
Mladý chlapec se učí jízdě na kole se svým tátou.
Chlapec v červeném tričku a černých šortkách zametá příjezdovou cestu.
Africká rodina stojí před provizorními domy.
Muž hrající na nástroj vedle stromu.
Dvě ženy se přes stůl drží za ruce a usmívají se na kameru.
Funící hnědý pes jdoucí po trávě.
Baseballová hráčka v černém triku právě vyoutovala hráčku v bílém triku.
Žena drží obrovský šek pro Kids Food Basket.
Dva psi, z čeho jeden s tenisovým míčkem v puse, běží skrze vysokou trávu.
Dva dospělí a dvě děti sedí na lavičce v parku.
Žena na travnatém poli fouká na pampelišku.
Muž prodává brambory skupině lidí.
Lidé na ulici se shromažďují, aby si poslechli akordeon.
Muž sedí na lavičce a poslouchá svůj iPod
Starý muž v metru má na sobě teplé oblečení a čte si noviny.
Starší muž v brýlích připravuje maso.
Muž předvádějící trik na kole stojí na pedálech zatímco to kolo stojí na zadním kole.
Muž je na pláži a staví písečné sochy.
Několik lidí v parku jí u piknikového stolu
Dvě ženy jsou přivázané ke stromu během jakési stavební práce.
Kovboj, který se při rodeu snaží překonat 8 vteřin.
Pes skáče přes ohnivou překážku.
Žena s nadváhou s dlouhými černými vlasy a v růžovém tričku s cedulkou se jménem si nanáší rtěnku.
Muž opravuje kolo malé holčičce.
Dvě dívky v nadýchaných sukních tančí před nějakými hudebníky na ulici.
Světlý pes si nese klacek podél vody.
Dívka ve svetru blokuje sluneční paprsky.
Probíhá rockový koncert.
Tři ženy v jasných barvách s ozdobnými pokrývkami na hlavách drží kartičky s milostnými zprávami.
Hnědý pes hrabe v hlíně.
Malý chlapec v bílém pruhovaném triku a čelence drží tenisovou raketu.
Dva psi běžící od fotoaparátu směrem do lesa.
Dívka si hraje v kašně zcela oblečená.
Tři mladí zápasníci sumo stojí a poslouchají uvaděče
Dva turisté zkoumají kládu u lesní cesty.
Tři hráči soupeřícího týmu sundávají protihráče k zemi.
Dva chlapci přecházejí silnici zatímco si kopou do červeného fotbalového míče.
Muž má jiného muže položeného na zádech.
Bílý pes na horském svahu se za něčím mimo záběr otáčí, obloha v pozadí.
Chlapec na skateboardu skáče na rampě
Dlouhovlasý muzikant hraje na piano.
Tři sportovci drží kytice na stupni vítězů.
Dva holohlaví transvestité v červených šatech
Malý chlapeček věší na věšák.
Malá dívka v růžovém se drží tyče.
Muž v zeleném skáče se svou motorkou přes několik motorek.
Žena hrající si s dvěma mladými chlapci v parku
Čtyři lidé hrají na pláži fotbal.
Dvě náctileté dívky se objímají, jedna má na sobě helmu a za nimi jsou na pozadí cyklisté.
Dva středně velcí psi běží sněhem.
Žena stojí na zelené ploše, drží bílého psa a ukazuje na hnědého psa.
Stůl plný obrázků v rámečcích na venkovním trhu.
Dva lidi sedí u venkovního stolu naproti zdi a dělají obličeje.
Dva chlápci s piercingy v bradavkách se usmívají.
Dítě leží na béžovém koberečku a směje se.
Muž a žena jsou do sebe zavěšeni, sedí a jsou vyšňoření.
Dvě ženy zápasí v bahně v dětském bazénku.
Chlápek v bílém triku kráčí s nápojem v ruce.
Silueta dvou lidí u jezera odrážející barevnou oblohu.
Několik lidí ve formálním oblečení sedí u stolu.
Dvě dívky (jedna oblečená v modrém, a ta druhá v růžovém) proti sobě závodí na kolečkových bruslích.
Čtyři lidé sedí na hromadě kamenů.
Skupina lidí dělá triky na motorkách.
Cyklista v závodním obleku jede přes zalesněnou plochu.
Muž v zeleném tričku kráčí po pláži a nese si tenisky.
Několik mužů stojí okolo starodávného závodního auta
Dva muži pracují pod kapotou bílého závodního auta.
Děti skáčou z hrany bazénu do vody.
Muž padá z hrany zídky.
Žena v pruhovaném oblečení na kole.
Dívka oblečená v černém pózuje na kameru.
Muž v šortkách stojící u vody.
Čtyři černoši sedí na schodech kostela.
Jeřáb operuje uprostřed hromady sutin.
Gymnastka v červenobílém je v půlce otočky na bradlech.
Starší žena v zeleném svetru vybírá zeleninu.
Dva muži vyrábí produkty v dílně s nářadím.
Učitelka v bílém a holčička ve žlutém si hrají se stavebními kostkami.
Mladé dítě spící ve své posteli s otevřenou knihou na hrudi.
Žena jí na trávě za krásného dne.
Muž kráčí po dlážděné cestě vedoucí podél budov namalovaných na světlehnědo s červenými okapy.
Žena s kloboukem dělá chléb.
Osamocená žena používá velký primitivní hmoždíř a palici, aby rozdrtila rostlinný materiál, zatímco stojí v poli strnisek.
Karatista vystupuje před dvěma rozhodčími.
Muž ve formálním oblečení hraje na piano na chodníku ve městě.
Postarší muž sedící na židli jí svačinu.
Žena v bílé košili pracuje za barem v kavárně.
Muž v pracovním oděvu stojí na zadní části nákladního vozu.
Dvě děti se přes malý plot dívají na koně.
Okno pomalované nějakým vzorem.
Žena v zářivém růžovém kabátě dělá grimasu na ženu ve fialovém kabátě, zatímco stojí před obchodem s názvem Vitamin Shoppe.
Kovboj si obmotová paži obinadlem.
Muž ve žluté košili a muž v tmavém modrém tričku si povídají.
Tři asijské děti sedí na gauči a za nimi visí tapiserie.
Dívka v červeném triku skáče, aby se trefila do tenisového míčku.
Muž pózující na kameru u zeleného jeřábu.
Usmívající se muž si připíjí lahví v restauraci s další osobou.
Muž nakládá pečené preclíky do nákladního vozu.
Muž v černé bundě hrající na veřejnosti na kytaru.
Taneční skupina účinkuje na průvodu v Číně.
Muž stojí na skalnatému útesu a shlíží na vodní hladinu.
Policejní strážník se kouká na ženu, jak vystupuje z autobusu.
Dva policisté ve střední letech v noci dohlížejí na parkoviště.
Dva muži v modrých košilích pozorují fotbalový zápas.
Skupina mužů v modrých uniformách stojí pohromadě.
Mladá žena na pláži praktikuje jógu.
Velký dav lidí stojí rozprostřen v parku a pár lidí hraje na nástroje.
Muž s kloboukem z balónků vyrábí zvířata z balónků.
Muž griluje maso na venkovním grilu.
Dva muži prodávají ovoce na ovocném trhu.
Hnědovlasá žena v bílých bikinách nalévá nápoj do mužova kelímku.
Chlapec ve slunečních brýlích běží za trhem.
Ruce v rukavicích drží něco, co se zdá býti nadrozměrně velkým hřebíkem na kmeni.
Muž v kostkované košili předvádí pár černých rukavic.
Dva muži na plastových židlích sedí u vchodu.
Mladá dívka v červených šatech má černý kovbojský klobouk.
Muž v červenobílém fotbalovém dresu stojí za autovou čarou se žluto-modrým fotbalovým balonem.
Lidé skáčou na provaze přes horskou puklinu.
Lidé se dívají na probíhající účastníky maratonu.
Lidé u laptopů sedící před velkým oknem.
Disk žokej je zaneprázdněný při práci a svítí na něj světla.
Muž v rukavicích nese kukuřici přes pole.
Fotografie zrcadlového odrazu kavárny.
Muslimská žena drží balónky na islámské události
Žena sedí v prostoru ohraničeném klecí s kočkou a dvěma králíky.
Žena sedí u cihlové zdi uvnitř budovy.
Tři mladé ženy jsou k sobě otočené čelem a sedí na červených nóbl křeslech.
Žena v modré košili prochází vesnicí.
Šest dětí sedí na schodech se zápisničky a pastelkami.
Tmavý pes, který si na břehu hraje s klackem.
Dva psi hravě okusují třetího psa, který vyplazuje jazyk.
Dítě je na motorce a směje se.
6 lidí se shromáždilo u velké večeře.
Santa Klaus fotografován na prázdninové mediální události.
Organizace Válečné rodiny pochoduje New Yorkem za deštivého dne.
Žena v modré helmě a červených kalhotách jede na motorce.
Několik mužů v oblecích na bojové umění předvádí společně nějaké pohyby.
Mladá žena a muž oblečeni ve válečných kostýmech mávají holemi a v pozadí skupina lidí.
Muž v uniformě kráčí po silnici se dvěma auty a stromem.
Mladá žena leze na skálu
Starší muž ve světle modré bundě opravuje auto na kraji silnice.
Lidé se dívají na několik barevných papírků rozmístěných po stole.
Muž, který zpívá do mikrofonu a hraje na kytaru.
Dva muži sedící v restauraci.
Dvě ženy v trenkách běží po pláži podél vody.
Stavební dělníci diskutují podél kolejí.
Pohled na pěší zónu zachycující muže v černé zástěře a bílé kšiltovce, který stojí uprostřed záběru.
Skupina lidí si hraje na objektu.
Malá dívka v modrém outfitu leze na ulici na kovové zábradlí.
Skupina mužů sedí a povídají si za nějakým zeleným ovocem.
Chlápek ve žlutém outfitu stojí ve stanu u mikrofonu.
Hnědý pes s fialovým létajícím talířem v hubě.
Vypadá to jako muž trénující bojová umění poblíž nějaké bahnité vody.
Žena s nápojem a žena s mobilním telefonem.
Dítě v červené bundě mává rukou ve vzduchu, zatímco leží ve sněhu vedle červených plastových saní.
Žena sedí vedle své kabelky a kouká se na psy v parku.
Tři muži stojí na pódiu, jeden má na sobě klauní makeup a drží kytaru.
Žena zpracovává tekutinu z rostlin ve kmenové vesnici
Žena v červených šatech tančí s mužem v obleku.
Dva malí psi pronásledují většího psa s tenisákem.
Muž s přerostlou bradkou a v baseballové čepici sedí v parku na lavičce.
Africký kmen stojí v zahradě a na pozadí les.
Mladá dívka se snaží kartáčovat kozu.
Asiaté sedí v restauraci se žlutými židlemi.
Malá holčička jí sušenku usazena v jídelní židličce a má na sobě bryndák.
Šedovlasý muž s černými rukavicemi seká trávník.
Žena, která si čte knihu, zatímco sedí v řadě červených židlí.
Dítě tleská zatímco je na ženiných ramenech.
Rodina, která jde po chodníku skrze sníh, zatímco muž sedí na straně s papírovým kelímkem.
Kočka sedí na vrchu cedule obchodu.
Muž v růžovém tričku a černém kabátě s nasazenými sluchátky.
Mladý muž se chystá hodit míčem na americký fotbal.
Chlapec a dívka jdou dolů po točitém chodníku.
Žena s růžovými vlasy dřepí na chodníku a drží růžové psy.
Muž v obleku držící nápoj v kelímku jde po chodníku vedle autobusu městské hromadné dopravy.
Muž skáče a za sebou má skalnatý útvar.
Osoba v červené bundě a černých kalhotách drží duhovou stuhu.
Žena pokládající ruku na osobu, která sedí na invalidním vozíku.
Muž v bílé zástěře vaří něco na pánvi s vajíčky pro ženu ve světle hnědém kabátě.
Žena s mobilním telefonem a sluchátky čeká na přechodu.
Skupina mužů kráčí dolů ulicí.
Cesta vedle zajímavého místa s mnoha sloupky.
Skupina lidí v černém stojí na molu poblíž dlouhé konstrukce.
Muž nesoucí několik beden piva.
Muž ve středních letech sedí a hraje na akordeon.
Dívka se zelenou páskou na ruce, gumičkami a náušnicích ve vlasech stojí venku.
Malá dívka v růžovém tričku je na pláži a běží vstříc oceánu.
Skateboardista v černém triku a džínách skejtuje po městě.
Muž v bundě si fotografuje velkou budovu.
Lidé za postranní čárou během fotbalového zápasu.
Na této fotografii je čtyřčlenná rodina běžící přes rušnou ulici ve městě.
Skupina lidí kráčí na slunci.
Na ulici s dopravními světly je několik lidí, včetně muže v hnědém kabátu a slunečních brýlí, který má ruku na obličeji.
Nějaké květiny rostou u okna.
Tento hráč v modré helmě byl na pálce, právě dokončil odpal během baseballového zápasu.
Žena ve zlatém kabátě spěchá na metro.
Lidé sedí na lavičkách pod řadou stromů před budovou.
Muž v obleku sedí na autobusové zastávce.
Afroameričan obklopený prázdnými vzhůru otočenými bílými kýbly a tmavě zabarvenými bednami se vyjadřuje za pomocí zprávy, která je napsaná rukou na kartonu.
Mladá brunetka něco jí a pije.
Muž v obleku a klobouku hraje na ulici na kytaru.
Žena v červené vestě pracuje na počítači.
Lidé stojí okolo kadidla a vanou si kouř do obličeje.
Muž se dívá do zrcadla, aby si uvázal kravatu.
Několik lidí hraje hudbu, zatímco šťastný dav sedí a poslouchá .
Dva mladí muži jedoucí na velmi malém koňském povozu plném brambor.
Žena v šatech jdoucí dolu ulicí podél staveniště.
Zaměstnankyně obchodu žádá zákazníka, který si kupuje alkohol, aby jí ukázal občanský průkaz.
Muž se slunečními brýlemi řídí stavební vůz a sype štěrk na zem.
Dítě si hraje s hračkami a kouká se na černobílou kočku.
Náctiletá dívka si nese lesem kytaru.
Muž s batohem kráčí po ulici.
Dva muži konverzují před obchodem se suvenýry v Římě.
Žena v černém něco drží ve své puse.
Skupina lidí sedí venku okolo malého krátkého stolečku.
Muž skáče se svým kolem nad rampu.
Žena má na sobě černé tílko a náhrdelník s křížem a zírá do dáli s brzy zapadajícím sluncem.
Tři malé dívky spolu kráčí po chodníku.
Žena s dlouhými vlasy je na promoci.
Muž jede na po silnici na skateboardu, zatímco jiný muž ho pozoruje z chodníku.
Muž v černé kožené bundě stojí před nápisem.
Muž a žena spolu venku zpívají píseň.
Malá dívka s blonďatými kudrnatými vlasy v bílém svršku leží na trávě a drží květinový stonek.
Mladý ženský fotbalový tým v zelených dresech provádí protahovací cvičení.
Žena sehrává dramatickou scénu na veřejnosti za žlutou policejní páskou.
Muž se krčí při domácích pracích, zatímco se holubi procházejí na pozadí.
Skupina mužů stojí na poli s černými míčky.
Rušný den pro občany na místním městském soudě.
Muž s cigaretou v puse si připravuje talíř s jídlem.
Dvě skupiny plavců se brodí.
Lidé sedí na lavičce na městském náměstí s různými předměty zahrnujícími také poblíž stojící lampu a figurínu.
Dělníci stojí kolem díry a drží kbelík.
Muž bez trička v černých kraťasech stojí na skalnatém pobřeží vedle velké masy vody.
Strážný je během služby na obhlídce.
Lidé hrající kulečník - jeden muž má na sobě modrou košili a ty ostatní jsou ženy, ale jejich hlavy nejsou v záběru.
Lidé stojí před sochou obklopenou vodou.
Žena se dívá na mluvícího muže s překříženýma rukama.
Muž ve středním věku s bílými šortkami a v žabkách se rozhlíží po ulici.
Dva muži oblečení v tmavě oranžových hábitech stojí poblíž zrcadlící se sochy.
Dva lidé si užívají na své lodi.
Muž a žena stojí na ulici ve městě.
Hasiči vycházejí ze stanice metra.
Čtyři muži z nichž tři mají na sobě modlitební pokrývky hlavy sedí na modroolivovězelené vzorované podložce.
Toto je velká skupina lidí sedících venku na lavičkách.
Muž v červeném tričku jde kolem tyrkysovobíle kostkovaného stravovacího zařízení, které se nazývá "32 De Neude."
Lékaři provádějí jakýsi druh operace.
Starší muž s cigaretou v ústech a baseballovou čepicí kontroluje svůj fotoaparát.
Malý orchestr hraje s před sebou otevřeným houslovým futrálem
Muž v červeném obleku tančí se ženou.
Dva lidé se dívají na noční osvětlené město.
Dva motokrosaři mají na sobě plnou ochrannou výstroj, jeden z nich ve vzduchu po výskoku a druhý dívající se na svou motorku.
Několik mužů oblečených do oranžova se shromažďuje na venkovní společenskou akci.
Dvě mladé dívky kráčí po chodníku před cihlovou budovou se standartami.
Dva jedinci lezoucí po strmé hoře.
Dítě leží na zemi vedle kočárku.
Pes škemrá u muže a ženy.
Mnoho lidí na trhu se dívá na rozličné věci.
Dva mladí muži hrají na pódiu na elektrické kytary.
Potetovaný muž, který lije pivo z láhve do úst mladého muže.
Dva lidé stojí u nafukovacích hraček a košů.
Čtyři lidé jedou na kolech po cyklistické stezce poblíž rušné silnice.
Žena v růžové košili má na sobě brýle.
Žena v červeném triku zvedá paži k davu pod ní.
Chlapec v bílých šortkách skáče do jezera nebo do řeky.
Malá dívka kouká dalekohledem na pláž.
Několik dělníků v oranžových bezpečnostních vestách kope dírů do země.
Osoba v kapuci stojí před chátrající budovou.
Dělníci stávkují proti PM Construction Services.
Muž jede na běžícím koni a za ním několik mužů dělá to samé.
Afroameričan kráčí po ulici.
Dvě jeptišky pózují na kameru.
Žena se zářivými sluchátky si píše do zápisníku.
Žena v zeleném tričku s potiskem mluví do mobilního telefonu.
Malé africké dítě nese na zádech mladší dítě.
Skupina lidí sedí na židlích.
Člověk s šátkem na hlavě stojí na ulici před jeho věcmi.
Orientální osoba v červeném triku a černých kalhotách dřepí u kabelky na chodníku.
Černý a hnědý pes s balonem.
Muž v černé bundě držící model letadélka
Muž na poli a ve výhledu letadlo.
Muž v obleku a kravatě a žena se zavazadlem se přidávají k ostatním čekajícím v londýnském metru.
Dítě jde po chodníku s pár americkými vlajkami.
Černý pes běží po zelené trávě a v hubě má hračku.
Orientální cestovatel čeká, až na něj přijde řada ve směnárně.
Pes se otáčí na trávě, aby chytil letící míček.
Skupina studentů sedí a poslouchá přednášející.
Lidé, kteří jedou v noci po ulici na skútrech.
Velké šedivé molo u moře a na něm chlápek na kole.
Muž v oranžovém triku, blonďatý chlapec a další lidé jedou na vláčku s nápisem Pullman.
Mladý muž a žena u velké kovové sochy
Loď s červenobílomodrými plachtami kotví u mola.
Muž v černé čepici fotografuje na rušné ulici.
Muž stojí na rušné ulici a zírá s nakloněnou hlavou.
Žena v černém má na ramenou malou holčičku ve žlutých šatech.
Skupina lidí na ulici ladící nástroje.
Spadlému motorkáři na hlíně pomáhá další motorkář.
Tři lidé kráčí po horské stezce a jedna z žen se dívá na kameru.
Několik asijských mužů v černých oděvech na jakési stanici.
Žena v červené sukni kráčí po ulici a na pozadí jsou graffiti.
Sportovní gymnastka v modro-růžovém dresu předvádí sestavu se stuhou.
Lidé se chladí ve fontáně, žena v bílých šatech sedí na jejím kraji a pozoruje dění.
Muž sedí na lavičce pod velkým stromem.
Tři muži v červenobílých proužkovaných tričkách, bílých kalhotech a černých kloboucích drží vlajky.
Lidé obdivující výtvarné dílo.
Rušné asijské obchodní centrum s papírovými lampiony a nákupčími.
Tito lidé lezou po schodech na horu vedoucí k hoře
Malé dítě v modrém outfitu se dívá na stromy v dálce.
Lidé se dívají na dětské hračky v obchodě.
Muž v klobouku hraje na ulici na bubny.
Chlapec stojí se třemi dívkami.
Muž, který se směje a má na sobě batoh, drží pěsti před chlapcem v brýlích.
Čtyři muži jsou venku a dívají se dolů ze zeleného mostu.
Žena polehává na osušce před lidmi, kteří si užívají v modré vodě.
Dospělý australský ovčák běží za štěnětem australského ovčáka.
Nakupující a milovníci jídla jsou zachyceni v ruchu města.
Afroameričan protestuje proti nezákonnému sexu.
Policajt na motorce čeká na světlech, až padne zelená.
Skupina mužů sedí okolo stolu.
Skupina obchodníků z vyšší třídy včetně starších mužů pijí v parku.
Žena se baví s kamarádkou, zatímco venčí psa za slunečného dne.
Mladý muž v šedočerném triku a bílé čelence
Dva lidé jedou na motorce vedle mnoha dalších jezdců.
Dvě ženy ve vojenských uniformách stojí s ostatními vojáky ve formaci.
Tři dívky se usmívají na fotografii.
Žena v brýlích s černými obroučkami a ve žluté mikině vypadá zmateně během toho, co sedí na světlehnědé lavičce.
Zrzavý mladý muž pije vodu z pítka ve tvaru ženy.
Dva muži a žena kráčejí po ulici.
Muž ve středních letech se zrzavými vlasy a brýlemi drží kojence.
Malý chlapec v červené kšiltovce jede na koni.
Dva chlapci si hrají na chodníku.
Malá holčička v černých plavkách drží na pláži lopatičku.
Starý muž v klobouku a saku, který sedí na pohovce a spí.
Dva chlapci se dívají nahoru na oblohu a mávají pažemi a mají na sobě oblečení, ve kterém jim bude teplo.
Mladý pár sedí na chodníku a odpočívají spolu.
Dřepící mladík má na sobě košili a kravatu a ukazuje gesto míru.
Tři lidé sedí venku u stolu v baru Gelati Tabacchi.
Chlapec v černém triku a s červenými náramky visí vzhůru nohama, zatímco se na něj ostatní lidé dívají.
Muž před pestrobarevnou malbou na zdi.
Mladý muž jde s jiným mladým mužem, který se dívá na tři dívky, které kolem nich zrovna prošly
Muž zastřihává palmu vevnitř kavárny v patio stylu.
Pět lidí jde nahoru po schodech a vede je žena v růžovém triku a hnědé sukni.
Skupina lidí na venkovním ovocném trhu
Dva chlapci jedí venku na zahrádce oběd z McDonaldu a jsou obklopeni mnoha lidmi.
Žena, která má na sobě džínovou bundu, jde po chodníku
Muž řídí vozidlo na čtyřech kolech s čtyřmi pasažéry vpředu a mužem sedícím bokem vzadu.
Muž v tyrkysovém triku čte noviny.
Chlapec v kočárku má na sobě zelené triko a drží knihu.
Dvě děti sedí vedle sebe a jedí dobrotu.
Lidé, kteří jedou na kole po ulici a všichni mají helmy.
Dav lidí a všichni jedou na kolech.
Muž sedící na desce s koly je tažen norou.
Muž na kole šlape skrze klenutý průchod.
Barevně oblečený mladý muž s viditelnými poškozeními na tváři sedí a kouří cigaretu.
Dva muži v oblecích pod deštníkem a před graffiti.
Starý hubený muž má na sobě špinavé bílé triko a jede na kole po silnici
Muž na koňském hřbetu se snaží chytit do lasa mladého býčka.
Kovboj jedoucí na koni se pokouší do lasa chytit býčka.
Dva cyklisté v helmách jedou kolem prázdných polí.
Muž se ohýbá a vytahuje něco z tašky.
Muž na elektrickém vozíku se jede podívat na areál parku.
Osoba s tetováními se dívá na fotografii na digitálním fotoaparátu nebo mobilu.
Muž v černém triku a džínách stojí na chodníku a kouká se na kameru.
Chlapec a dívka spolu stojí na chodníku a dívají se na nějaký předmět.
Několik lidí v modrých zákrscích a jedna osoba v sukni a černé blůze.
Žena a pes sedí na bílé lavičce poblíž pláže.
Dvě ženy kráčí po hlíně před velkou budovou.
Skupina mužů a dítě v bílém triku stojí na silnici.
Žena oblečená celá v černém si nese po chodníku černou kabelku
Skupina mužů sedících u stolu se baví.
Malba na zdi na straně budovy.
Asiat má na sobě rukavice a pracuje u stánku s jídlem.
Žena sedící u stolu při práci na svém přenosném počítači.
Osoba dívající se na počítač na stole s mobilem a krabicí.
Muž sedící na židli kouká na procházející lidi.
Dva lidé v kloboucích stojí na poli a pečují o sklizeň.
Skok do výšky v Barceloně.
Muž v jezdeckých botách a kovbojském klobouku sedí na koni, který skáče a diváci sedí na tribuně.
Dvě malé dívky sedí na silnici a pojídají kukuřici.
Tři děti ve fotbalových uniformách dvou různých týmů hrají fotbal na fotbalovém hřišti, zatímco další hráč a dospělý stojí v pozadí.
Malé dítě se špinavou pusou je drženo starou ženou.
Muž s brýlemi se kouká na kameru zatímco jiný muž v modrém triku se na něco soustředěně kouká.
Dva lidé sedí pod stromem a sbírají zelenou zeleninu.
Mladý chlapec má na sobě modrou čepici, dívá se do dalekohledu, zatímco jiný chlapec ho pozoruje.
3 muži vaří v malé kuchyni.
Malá dívka má na sobě šedou kombinézu a lyžuje na zasněžené hoře.
Skupina vesnických žen shromážděna u tance
Muž a žena třídí prádlo v latexových rukavicích.
Mladá dívka sedící na dřevěné židli.
Dva pracovníci svářejí tyče plotu na rušné předměstské ulici.
Dlouhovlasý mladý muž skateboarduje na zábradlí během zamračeného dne.
Dva muži odklízejí lopatami sníh z cesty na venkovním tržišti.
Muž v bílé košili hraje na bílou kytaru.
Mladá dívka ukazuje kamarádkám fotoaparát na jedno použití.
Malý chlapec, který skáče z mola do jezera.
Žena se zelenou rouškou u zubaře vypadá velmi nešťastně.
Muž v oranžové bundě a modré čepici leze na zasněžené hoře.
Malá dívka s blonďatými vlasy si hraje a cáká v kaluži s bahnem.
Dítě jede na kole uličkou s graffiti.
Gymnastka je hodnocena na soutěži.
Lidé kráčí ulicí, kde je pouliční prodavač.
Muž oblečený v tradičním oděvu stojí vedle své muly, která také vypadá oblečeně.
Dvě děti si hrají na kole.
Dva muži soupeřících týmů hrají na hřišti fotbal.
Muž skáče a pózuje pro fotografa ležícího na zemi.
Dívka pije vodu z pítka.
Jeskyňář nalézá vodu během své túry.
Muž v laboratorním kabátu se dívá do mikroskopu.
Blonďatá dívka spí na hnědém gauči.
Muž zametá chodník před zděnou budovou uprostřed dne.
Tři muži vaří v kuchyni.
Muž na lešení před domem se směje a pózuje pro fotografa.
Dvě dívky v šortkách se drží za ruce v bazénu.
Čtyři asijské děti sedí na lavičce a mávájí a usmívají se na kameru.
Děti jedou na kolech v nějakém chudém státě.
Malý chlapec v šéfkuchařské čepici a zástěře řeže klobásy v kuchyni.
Toto je klaun na základní škole.
Kapitán lodi se usmívá a drží kormidlo své dřevěné lodi.
Žlutý buldozer přesouvá hlínu.
Žena v červené košili jede na úplně bílém koni, který cválá podél stromů.
Žena sedící na velmi velkém kameni, usmívající se na kameru, se stromy v pozadí.
Tři muži mající na sobě zářivé kostýmy, paruky a bláznivé brýle vyrážejí do ulic.
Dívka si hraje v malém bazénku.
Dvě děti, chlapec ve žlutém triu a dívka v modrobílo pruhovaném, se houpou.
Muž hází rybářskou síť do zálivu.
Muž mající na sobě šedé tričko, modré džíny, neonovou zelenou bezpečnostní vestu stojí na železniční koleji a na pozadí je bílé nákladní auto a bílá budova.
Dva dělníci pokládají kus kovu přes trámy.
Na pódiu je kapela, která je oblečená do modrého.
Rocker bez trika zpívá do mikrofonu a hraje přitom na bicí.
Vidím muže, který vyndavá věci z nákupního košíku, aby jej mohli zkontrolovat.
Muž s holí je na procházce.
Žena v bílém triku cvičí na eliptickém trenažéru.
Dívka s maskou se nosí na mužových ramenech a jdou po zaplněném chodníku.
Dvě dívky, jedna starší v černém a druhá mladší v bílém předvádějí ten samý baletní pohyb před dekorací z balonků.
Několik žen předvádí tanec před budovou.
Plešatý muž kráčí po chodníku dolů a při tom hovoří na mobilu.
Žena si hraje s prstovými maňásky zatímco dítě v kostýmu prochází okolo.
Skupina lidí pozoruje mladé muže, kteří hrají na bubny ze kbelíků sloužících jako hudební nástroje.
Dívka s normálními a improvizovanými chrániči na kolečkových bruslích.
Malé bílé auto je na vlakových kolejích a možná bylo, možná nebylo zasaženo vlakem za ním.
Dva rockeři zpívají a hrají na tmavém pódiu.
Dívka v kšiltovce, bílém tričku a modrých šortkách stojí v potoce s kameny na dně a kolem jsou hory a lesy.
Dva muži hrají na kytaru před velkým publikem.
Skupina lidí tancuje se svými drahými polovičkami před tímto obrovským domem.
Žena a pes prodávají výrobky na schodech staré budovy.
Žena a dva muži, kteří jsou profesionálně oblečeni, se baví.
Skupina mužů v červenočerných bundách čeká na motorkách.
Muž oblečený v bílém dresu s číslem 3 hraje fotbal.
Muž prodává malé občerstvení na sportovní události.
Dva muži ze zeleného týmu se snaží obrat členy černého týmu o balon během rugbyového zápasu.
Děti soutěží o držení fotbalového balonu.
Osoba v modrém je momentálně jedinou osobou házející svou kouli na bowlingové dráze.
Několik fotbalových hráčů na hřišti v akci.
Mladý muž sedí na skateboardu, drží mobil a pózuje na eskalátoru.
Dáma oblečené v modrém běží maraton.
Tato kapela se připravuje na vystoupení v kostele před diváky.
Hráč číslo 8 týmu Iowa State odstrkuje rukama hráče Texasu AM, který se ho snaží sundat dolů.
Dva hráči curlingu zametají led před kamenem a malý dav je pozoruje.
Muži hrají fotbal na bahnitém hřišti.
Basketbalový hráč v bílém je v podřepu zatímco hráč v červeném jde proti němu.
Lidé kráčí pod obloukem ve staře vypadajícím městě.
Dvě závodní auta, jedno červené a druhé modré, jedou vedle sebe po závodní dráze, zatímco je pozoruje několik diváků.
Hráč amerického fotbalu v bílém dresu drží balon.
Velmi mladý chlapec se kouká dopředu, zatímco se zakusuje do malého předmětu.
Žena a dítě jdou po ulici.
Hokejový zápas se hraje se spoustou lidí, kteří jej sledují.
Tři ženy skáčou na balonech po trávě.
Afroamerický chlapec v modrých šortkách, černočerveném tričku a bílých teniskách hraje tenis.
Muž a žena v bílých trikách se navzájem objímají.
Muž, který promlouvá k rodině, zatímco drží jakési snímací zařízení, se usmívá a snaží se být milý.
Malý chlapeček v zeleném tričku leží na břiše na bílé posteli.
Freestylový cyklista se zastavuje, aby si odpočinul a na pozadí je západ slunce.
Žena lyžuje v zasněžené oblasti a má na sobě teplé oblečení.
Čtyři dívky a jedna dáma se učí ručním pracím.
Muž v černobílopruhovaném se snaží zastavit koně.
Muž skenuje obrázek, který mu dává žena v modré košili.
Zrzavá žena je po krk ponořená v kalné modré vodě.
Dva malí hoši pózují se štěňátkem na rodinné fotografii.
Čtyři děti trénují karate zatímco se dva dospělí dívají.
Muž polehává na červené pohovce v showroomu s nábytkem.
Skupina lidí povídajících si u stolů.
Dva žokeji, jeden v červenomodro kostkovaném a ten druhý v oranžovohnědém proti sobě závodí a pozadí je rozmazané.
Červené auto je napřed dvou aut v pozadí.
Velký býk útočí na muže svými rohy v rodeu, je kousek od něj a rodeo klaun běží na pomoc.
Muž bez trička kráčí ke žlutému kajaku.
Chlapec na střelnici míří a střílí.
Dva týmy chlapců hrají fotbal v písku.
Dítě v modrém a dítě v bílém stojí na krátké betonové zídce u potoka.
Žena kreslí květinový motiv na hliněnou vázu.
Lidé se procházejí po rušné třídě v cizí zemi.
Pravoruký nadhazovač z týmu Saints nadhazuje.
Dva muži, jeden v černobílém a druhý v červeném, hrají plážový volejbal.
Muž stojící na lodi drží jakousi síťovinu.
Surfař, který spadl ze surfařského prkna do oceánu při snaze sjet vlnu.
Technik připravující vzorek v laboratoři.
Fotbalisté skáčou do vzduchu, aby odrazili balon svými hlavami.
Dva chlapci hrají proti sobě fotbal.
Starší osoba přechází silnici s deštníkem v ruce.
Skupina běžců běží směrem k identickým mrakodrapům.
Skateboardista jede nahoru po betonové zídce a téměř padá u předvádění triku.
Lidé hrají utkání v bazénu.
Chlápek davá pusu jinému chlápkovi
Muž se podepisuje malému chlapci do knihy.
Mladý muž v modrém triku sjíždí zábradlí na skateboardu v městské části.
Asiat sedí na kolejích s bednami buráků.
Britský muž oblečený do vojenské uniformy mává svým kloboukem a za ním stojí lidé a koukají se na vodní kanál.
Dvě auta jedou po závodní dráze.
Muž v černobílém dresu drží žluté lyžařské hole a připravuje se k odjezdu.
Dva lidé leží a líbají se na trávě.
Velmi malé dítě v denimové kšiltovce jí zelené jablko.
Hráči amerického fotbalu běží za balonem.
Muž v černé bundě, kostkovaném klobouku a pruhovaných kalhotách hraje na pódiu na elektrickou kytaru a na pozadí je zpěvák a další kytarista.
Muž skáče přes zátarasu pryč od býka.
Žena v modrém triku a bílých šortkách hraje tenis.
Muž hraje na pohřeb na koncertu
Muž nese na ramenou velký náklad kovových trámů přes sklad dřeva.
Žena s kamerou hází svému hnědému psovi létající talíř, aby ho chytil.
Je tam obrys muže a ženy, kteří pozorují táborák nebo jinak velký hořící dřevěný objekt.
Dvě dívky si namáčejí ruce ve fontáně a kolem nich chodí lidé.
Mokré, usmívající se dítě bez trička pózuje se zdviženýma rukama.
Dva muži, jeden v bílém a druhý v modrém, zápasí.
Žena v červených bikinách skáče, aby odpálila míč na plážovém volejbale.
Zrzavé pruhované koťátko kouše blondýnu do nosu
Žena má na sobě žlutou zástěru a odklápí poklici z velkého hrnce.
Dvě děti přecházejí říčku po kamenném můstku.
Dvě afroameričanky jedou na mopedu ulicí, která se zdá být ve velmi ucpané oblasti velkého města.
Dva chlapci před automatem na limonádu.
Cyklista v černém, jede na horském kole dolu po prachové stezce.
Žena s tetováními si fotí na mobil obraz.
Žena, téměř celá v černém oblečení a s bílou helmou, jede na kole, v pozadí jsou rozmazané stromy.
Tým cyklistů zatáčí zatímco jim fandí poblíž stojící diváci a fotografují si je.
Čtyři hráči amerického fotbalu napadají za deště hráče soupeřova týmu hrajícího v bílém.
Běžec se rve o yardy zatímco ho dva hráči sundavají k zemi.
Basketbalista v bílém dresu s číslem 55 brání hráče v černém dresu s číslem 10.
Muž venku hovoří do telefonu.
Závodní baseballoví hráči se během All Star utkání dívají na soupeře na pálce.
Motokrosař jede v podzimním lese do nakloněné zatáčky.
3 basketbaloví hráči soupeří o balon, z nichž ten v červeném dresu se snaží vzít balon tomu v bílém dresu.
Chlapec, který se popadá za nohu, když skáče do vzduchu.
Dvě děti s pruhovanými svetry a černými kalhotami se perou poblíž prolézaček.
Muž se slunečními brýlemi jede na koloběžce.
Malý chlapec mající na sobě korunovační insignii drží pálku za hlavou a před ním je postavený baseballový míček.
Šest mužů sedí v poli plodin a vedle nich bedýnky.
Hnědý pes zvedá větvičku z kamenného povrchu.
Toto je muž oblečený ve žlutém a drží opratě hnědého koně
Muž v bílé košili a zástěře čtvrtí ptáka.
Hispánská žena používá venkovní wok k vaření.
Maratonší běžci závodí po ulici ve městě a okolo stojí lidé.
Asijská žena má na sobě klobouk proti slunci a jede na kole.
Několik dětí si venku hraje s hlínou u dvou stromů.
Starší muž hraje video hry.
Dívka na břehu pláže s horami v dáli.
